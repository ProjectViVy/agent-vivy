package memory

import (
 "context"
 "testing"
 "agent-vivy/internal/config"
 "github.com/ProjectViVy/agent-vivy/bml"
 gm "github.com/ProjectViVy/laputa/garden/memory"
 "github.com/ProjectViVy/laputa/laputa/evolution"
)

func TestIssue58ReviewExpansionRejectsNegativeBudget(t *testing.T) {
 ctx := context.Background()
 svc, err := Open(ctx, config.Config{Storage: config.Storage{DataDir: t.TempDir()}})
 if err != nil { t.Fatal(err) }
 t.Cleanup(func(){ _ = svc.Close() })
 owner := bml.OwnershipBinding{SubjectID:"review-subject", DomainID:"review-domain", ScopeKind:"personal", DestinationID:"bml"}
 backend, err := NewBoundBackend(svc, owner)
 if err != nil { t.Fatal(err) }
 scope := evolution.Scope{SubjectID:owner.SubjectID,Kind:evolution.ScopePersonal}
 receipt, err := backend.Mutate(ctx,gm.AuthorizedMutation{Scope:scope,DestinationID:owner.DestinationID,OperationID:"review-budget-create",PayloadDigest:"review-digest",Operation:evolution.MutationCreate,RecordID:"review-budget-record",ExpectedAbsent:true,Body:"retained body",Inference:evolution.InferenceObserved})
 if err != nil { t.Fatal(err) }
 defer func(){ if value:=recover();value!=nil {t.Errorf("negative expansion budget must return an error, got panic: %v",value)} }()
 if _, err := backend.Expand(ctx,gm.AuthorizedExpansion{Scopes:[]evolution.Scope{scope},CardID:"review-budget-record",ExpectedRevision:receipt.Revision,BudgetChars:-1});err==nil {t.Fatal("negative expansion budget accepted")}
}
