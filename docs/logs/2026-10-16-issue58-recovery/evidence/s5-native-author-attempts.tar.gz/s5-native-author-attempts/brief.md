# S5 recovery implementation brief

Implement approved S5 in dependency order after root supplies accepted S3/S4 pins.
Read S5.md, current revision3 C5, root AGENTS.md, BML native contracts and relevant
skills before editing. Do not redesign product or create another memory engine.
GPT-6.1 Sol High, one source writer, no subagents. Root integrates, reviews and
publishes. Human commit identity and toolchain/local-only test rules match S4 brief.

## First native capability increment

Garden memory.Backend already defines Search/Expand/Mutate/MutationStatus/Health/
Close; Config.Backends injects selected scope-bound implementations. Do not expand
that public contract. BML is the existing nested ./bml module; its Home/Store owns
one database and existing canonical CRUD/FTS/visibility. Adapter must reuse these
native results, not copy ranking or reconstruct an old mutation from current row.

Native durable operation/digest/outcome must commit in the SAME existing SQLite
Store.putInner transaction as record CAS/tombstone/FTS/counters. Wrapping Home CRUD
and then writing receipt is prohibited dual write. Existing memory_apply_journal
is unused compatibility schema, not an API to revive with fake proposals. Extend
minimal native Store/Home API and actual durable lookup; only then advertise
MutationLookup. Keep native IDs, revisions, sources/provenance and outcomes.
Scoped operation/destination binding is exact; replay precedes current-record
preconditions, returns immutable actual outcome even after update/tombstone/reopen.
Changed payload or cross-scope/destination must fail, never overwrite or disclose.

BML schemaVersion currently1 exact-match and migrate.go is offline JSON import,
not a database upgrade runner. Own bounded native schema evolution with real
fresh/legacy/read-only/backup fixtures and rollback-on-failure tests. Do not run a
migration against tenant data or introduce core migration046. Preserve original
ProfileID legacy scope; trusted C1 organism subject is separate. Unknown old record
mapping is unavailable, not implicitly promoted. Read-only/native unsupported
capabilities stay explicit. Home owns lifecycle/L1 invalidation. Adapter Close
must not close a shared service it does not own twice.

Verify native conformance plus actual CRUD/CAS/search/export, receipt replay after
update/tombstone/restart, digest mismatch, same/different operation concurrency,
commit failure atomicity, exact scope/destination isolation. Garden's memorytest
suite is necessary but not sufficient. Root expects independent review before
integrated activation.

## Composition closure increment

Default Recipe selects both vivy/memory-bml-sync run.completed ingest and cognitive
capture; they must never project the same LIFE run. Reuse ObserverHost durable
receipts/cursor. Select exactly one receipt-aware subject projection provider;
repair/seal retained C2 before projection, deterministic native historical record
with exact original references, ack only the actual durable native result. Failed
projection/index keeps cursor/evidence, retried terminal seals/projects once. No
new scheduler/transcript store/second synchronous write transaction. Cardinality
must be checked at composition, never silently pick between two writers.

Exclude old BML completion and cognitive capture by persisted run policy, not
session heuristic/current UI state. v3 owner rejects legacy Pulse/Work/Fold/ring
writers under all policies. Existing committed legacy receipts remain readable;
pending v3-incompatible deliveries become truthful policy-skipped receipts rather
than fabricated memory writes or permanent retry loops. Untouched legacy v1/v2
still reads/writes under existing policy; ordinary Coding/native tools/context
remain functional. Preserve WORLD/worker/Notebook privacy, nonempty-legacy block,
no-reflection path. No LIFE sidebar, selector, conversion or source hard deletion.

S4 sources consumes a bounded runtime Service exact C2 reader and shared host
receipt codec; no Module/UI parser or live reconstruction of old correction refs.
Index lag/tombstone cannot erase retained core originals. Complete Recap loaded
revision/activation status, historical source expansion, archive/reference flows,
ToolHost/UI/headless parity; no fake ActionHost success. Readonly source expansion
rechecks current singleton/whole domain and exact run/view/source grants/digests.

Regenerate metadata/assembly through SDK. Run focused native/Module/App/Host tests,
SDK verify, staged UI typecheck/test/build and real backend Playwright with disposable
config/data roots using supported split dev loop. Root controls fixed-candidate
full just ci/default+DIVA memory-loop/Windows/race gates. Distinguish local HTTP
adapter proof from live model quality; no PostgreSQL DSN = SKIP, #66 absent = not
installed acceptance. Keep all RED/compile/failure/interrupted logs and commands.

Write report.md+logs alongside brief with exact source SHA/tree, BML native schema
change/upgrade limits, source/native capability evidence, single-sink status, passes/
failures/skips/unrun gates. Commit coherent checkpoints without root docs, no reset/
clean or lost evidence. Root pushes verified exact remote trees and draft PR.

## Root read-only seam audit (after3e130, no S5 source edits)

- BML Home.ConfigDir/DatabasePath are already exposed. Service currently stores only
  Home, and memory.Open returns process-global Active before checking config root.
  An injected Garden backend must prove it belongs to this App's normalized data
  root and not silently reuse another App's Home; foreign-root open must deny or
  remain unavailable. Close is shared Home ownership, not per-backend ownership.
- Home.machineScope is TenantID="local", WorkspaceID="machine-memory-home";
  it has no ProfileID/subject. Existing Record.Scope only has those fields and
  optional SessionID. New bound backend operations need durable explicit full
  ownership binding; do not treat every old local-machine row as diva's personal
  scope or derive it from the new Recap subject. Legacy unknown mapping must stay
  unavailable. Current factory legacy scope is SubjectID="diva", personal,
  WorkspaceID=""; destination currently mentle and must be deliberately changed
  for the selected BML binding. Garden backend map is keyed by EncodeScope.
- Store.putInner already owns record/store CAS, supersedes, FTS, counters and
  tx.Commit at its end. Native immutable receipt belongs before that same Commit;
  failure must roll back all. Replaying a receipt must precede revalidation of
  stale record/store preconditions, but never precede request/scoped identity
  validation. Home's returned L1 revision refresh must use the actual result.
- Garden runtimecore.BackendFor can lazily create Mentle for other profile scopes.
  Verify non-selected/missing scoped BML bindings cannot silently fall back through
  any human/ingest/evolution call path; follow the already supported Config ID /
  Destination and consumer checks, no new Garden public API unless truly needed.
- DIVA script VCS environment: Go1.26.4 vcsGit recognizes .git directory only.
  Detached worktree Go test works but go list/run main packages can discover the
  unrelated unusable parent metadata. Root's clean local shared clone exact3e130
  runs the unmodified script; no buildvcs=false/test assertion relaxation used.

Additional concrete App lifecycle evidence at fixed94bff801: memory.Open is called
at app.go344 after storage lease and memoryOwned=true is local construction cleanup;
it is reset near1578. App.CloseContext calls process-global memory.Close
unconditionally near1718, even for an App whose Generation omits memory-bml.
Therefore merely checking injected backend root is insufficient: an unrelated
no-memory App close can close another App's active Home. Keep the existing one
registry, but bind/open/close ownership to this composition's actual Service (or
fail competing ownership explicitly) and test foreign-root Open + failed/no-memory
App construction/close cannot expose or close a live foreign Home. Same-root second
App storage lease rejection still must not close the first owner's resources.
This is the bounded BML injection/lifecycle fix, not permission for a global service
registry redesign. Native backend.Close must not independently close shared Home.

Recipe audit: default selects memory-bml/sync/tools plus diva-cognitive; diva selects
diva-cognitive + diva-memory and NO memory-bml. Existing DIVA MemoryLoop/recall gates
pass fixed3e with their Mentle composition. Select/inject BML from the actual sealed
Assembly's selected memory module and this App-owned handle, never from ambient
Active()!=nil. A DIVA/no-BML composition must not accidentally bind another App's
BML registry or silently swap backend. Keep separate installed DIVA qualification.
Use the existing internal FactoryInput seam for any bounded injection needed;
Garden Config.Backends/BackendID/DestinationID already provide the public boundary.

Privacy integration check: legacy BML contextsource.Provider.Query uses global
Service.Recall/Home machine visibility and runs for ordinary/worker compositions.
New LIFE historical projections MUST NOT become visible there merely because they
share the native database/FTS. Explicit durable scope binding must constrain both
read/search/export and mutation, not only receipt lookup. Test a real projected
LIFE secret through actual ordinary Coding/worker ContextHost/model request: no
implicit LIFE material. Preserve old Coding recall for its own unchanged legacy
records. Conversely bound LIFE/authorized human source expansion uses exact granted
scope. Do not solve this by treating every machine-local historical row as safe.

## Gated first source release: native v3 legacy-consumer compatibility

This section is a prepared implementation boundary, NOT a release by itself.
Wait for root's explicit follow-up after S4 fixed7ab14d5 original probes,
normal regression and Issue58 race complete. Until then do not mutate Laputa.

The first released increment is only the actual native C5 compatibility gap in
prep.md. Create independent branch feat/issue-58-recovery-native-20261016 from
clean bb57e93; ordinarily merge latest mainf44ba00 without reset/rebase, preserving
both histories. Record merge SHA/tree and verify no .go source changes from the
merge. Re-read applicable updated AGENTS and ADR0018. Do not alter Vivy source or
activate any unpublished sibling implementation via pin/replace. Root docs and
Git index remain root-owned; keep producer source commits in Laputa only.

Use one owner/parser, existing ReadRecap with trusted runtime RecapBinding and
existing ingestions.activity_json. Positive valid v3 revision is policy evidence;
raw schema prefix, generic unavailable, live unknown, malformed/foreign chain,
revision zero and IO failure are not. ReadRecap may perform its native same-byte
recovery publication. Preserve authority/history/archive content and logical
revision/coverage; do not disable native durability recovery.

Existing applied receipts retain their actual IDs/revision. Native owner-only
archive lookup may return exact complete archived entries with explicit
Revision=0 meaning no current legacy head revision; do not use C1 revision as a
legacy append result. Garden may recover Before.Revision+1 only from a complete
valid original persisted Before plus exact positive pair evidence. Missing,
partial or conflicting evidence is not a negative result. Keep old unknown
status/Before/source/effect metadata and separately close the incompatible legacy
consumer with an explicit durable policy disposition. No fake applied/negative,
new receipt store, scheduler or C1 coverage movement.

All Start/drain retry, HighWatermark and ArchiveSession predicates must agree on
strict valid policy closure. ArchiveSession must avoid calling the denied legacy
FoldSession under positively verified v3; no-op policy close is not a claimed
fold/capsule. Old writers continue to reject v3 without mutation under all paths.
Include real Start/restart/one-second worker interval, valid and invalid closure,
unknown/old-positive evidence, storage failure, native v1/v2 and Windows-specific
recovery fixtures from prep.md. Tests begin RED and preserve every attempt. Use
existing local-only runner and exact native module dependencies; no credentials
or external HTTP calls. Final root stage must execute actual native Windows tests,
not label cross-compile as a run. There is no existing native GitHub workflow;
root owns bounded final Vivy Windows integration wiring if needed.

Commit coherent producer tests/fix with English docs and human identity. Stop
source after focused native normal/race checks and report full candidate SHA/tree,
merge parents, all modified files, exact commands/outcomes/source hashes. Root
owns independent Astra review, one consolidated author TDD fix if findings,
unchanged reviewer-probe reruns, remote native branch/draft PR publication and
exact new module/lock/sum pin. Only after explicit native producer acceptance/pin
may the BML native receipt/schema and Vivy consumer implementation lane resume.
