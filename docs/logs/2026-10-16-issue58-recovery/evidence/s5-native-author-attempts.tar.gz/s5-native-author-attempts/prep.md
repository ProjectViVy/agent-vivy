# S5 read-only preparation

Status: source lane is NOT released. No source, test, plan, generated file, or
root evidence was edited; no test/build was started. This is inspection evidence,
not acceptance. S4 remains pending independent review.

Inspected Vivy HEAD `168393b0a70d2406de01c2307091c3c4c67fce3c`, tree
`372d9ff3f2e66eadb60310877616a83107d5d3d0`; Laputa checkout HEAD
`bb57e93a61cfb41460524d00a557a3a9f2cce1e7` (also the root go.mod pin).
Read the recovery brief completely, root AGENTS, S5, authoritative revision-3
design C4/C5, BML README/native Store/Home/search/record/maintenance surfaces,
Garden Backend contract/conformance and existing composition/capture code.
Loaded executing-plans and TDD; read relevant vivy-plugin, vivy-kernel-ci and
vivy-eino guidance. Mandatory architecture documents and any newly touched
subsystem instructions remain to be read before implementation, after release.

## Concrete implementation order

1. Native schema evolution and ownership binding, then atomic native operations.
2. Home-bound native search/export/mutation/lookup and legacy visibility exclusion.
3. BML Garden adapter conformance, then App-owned lifecycle and sealed selection.
4. Runtime receipt-aware subject projection and persisted-policy legacy exclusion.
5. Exact historical source reader/shared receipt codec and actual loaded status.
6. Generated metadata/Assembly, focused real-path checks, root-owned review/CI.

Each increment starts with a new failing behavioral test and preserves all RED,
compile/failure and interrupted output. Old c113/858a code is unavailable and is
not an implementation or GREEN source.

## Native transaction and schema seams

`bml/store.go:Store.putInner` is the existing record CAS, target CAS, supersedes,
FTS and counter transaction. Add a bounded native mutation envelope and immutable
operation result inside this transaction, before its existing Commit. Do not call
Home CRUD and then insert a receipt. Do not revive `memory_apply_journal` or
invent proposal IDs. Retain actual stored result and native revision, including
the tombstone operation's actual native result and target identity; do not derive
a replay from today's record or from Home.RemoveRecord's deposed-entry response.

Validate request and exact bound identity first; check immutable operation replay
before stale record/store preconditions. Persist both the supplied digest and a
canonical request fingerprint so changed body, sources, operation, CAS shape or
target cannot exploit an unchanged caller digest. Immutable outcome includes full
scope, destination, actual target/result/revision and index/canonical disposition.
Lookup checks identity before disclosing the result. Cross-owner record mutation
and tombstone/supersedes targets must be checked inside the same transaction.

The smallest storage shape appears to be new native ownership and operation
tables in the existing SQLite file, with exact nullable ownership for old records.
This avoids changing legacy canonical Record JSON or treating machineScope as
the trusted subject. Record ownership is durable, not adapter memory. Any chosen
schema must preserve this distinction for reads as well as writes. Old unbound
rows remain legacy; mapping them to personal diva or the C1 subject is unavailable.

Schema v1 currently has exact-match checks. Both `openPath->initialize` AND
`Home.existingStore->openExistingMutable->checkIdentity` need the bounded writable
upgrade path. Changing initialize alone does not upgrade an existing Home.
`OpenExisting` is explicitly read-only and must never upgrade. Keep old readable
legacy capabilities truthful and report bound mutation/lookup unavailable where
the required schema is absent. Unknown/future schema or workspace mismatch fails
without mutation. Backup validation must not silently upgrade the backup in place:
maintenance.Restore and existing identity migration currently validate via openPath.
Native upgrade tests must cover fresh/v1/reopen/readonly, complete pre-upgrade
snapshot, failure rollback, backup preservation and restore. No core migration046
or tenant migration is in scope.

`Home` remains the lifecycle/L1 owner. On replay it refreshes/invalidate from the
actual committed result; projection-refresh failure must not erase the receipt.
Native commit failure must leave no receipt, record, supersede, counter or FTS
change. Test same/different-operation concurrency with shared Store and reopened
handles, not only an adapter mock.

## Read/privacy closure

`Home.SearchVisible` currently overwrites the caller's scope with local machine
scope. Legacy `Service.Recall` and generated memory context source use it through
global Active. Simply storing new LIFE rows in that machine scope leaks history
to ordinary Coding and workers.

Exclude explicitly bound records at native legacy List/Get/Search/Update/Remove
and startup L1 boundaries, before LIMIT/ranking projection. Separate exact bound
Home reads/search/export from legacy machine recall; reuse native FTS ranking and
canonical records, without ranking in the adapter. Bound export must verify exact
stored owner, active/tombstone/supersede visibility and expected revision from the
same read result. An unscoped ExportSource signature cannot authorize a bound
record by itself. Unknown legacy owner stays unavailable to the Garden adapter.

Test a real LIFE projected secret through ordinary and worker ContextHost/model
requests and through memory CRUD/L1, alongside unchanged legacy Coding recall.
Also test worker/private/Notebook/report data cannot enter LIFE projection.
The existing ingestExclusionPredicate already excludes report purpose and
excluded automatic-ingest provenance/tool operations; retain these checks.

## App composition and lifecycle

`memory.Open` returns Active before checking cfg.DataDirectory; failed CAS also
returns ambient Active. `App.CloseContext` unconditionally calls memory.Close,
including a no-BML composition. Bind cleanup to the exact opened Service. Reject
competing ownership explicitly or use identity-aware detach/close of that service;
do not build another global registry. Normalize data roots before opening and
reject a foreign root. App stores its actual Service for cleanup and FactoryInput.
BML adapter.Close is a no-op over shared Home. Test foreign-root Open, failed
construction, no-BML App close and same-root storage lease rejection cannot expose
or close another App's live Home.

Choose BML solely from the actual sealed Assembly selecting memory-bml and pass
that App-owned handle through existing private FactoryInput. Factory retains
legacy ProfileID=diva/personal scope separately from trusted C1 subject/domain.
Remove hard-coded destination constants from binding/dispatch where the selected
writer varies; pass Config.BackendID/DestinationID and exact Config.Backends.
DIVA recipe has diva-cognitive+diva-memory but NO memory-bml, so keeps Mentle and
cannot bind ambient BML Active.

Fallback inspection: agentapi.handle.selectedBackend obeys Config.BackendID and
fails missing non-Mentle binding. Generic runtimecore.BackendFor can lazily mint
Mentle and is called by ingest and SearchCards/ReadEvidence. However actual default
Vivy boundSink calls BindSession(sessionID), not cap.WorkspaceID; factory workspace
is empty and ingest.scopeFor therefore resolves the injected diva/personal scope.
Human dispatch calls BindHumanSession(sessionID, ""), and BoundDomain checks the
exact bundle scope. DIVA's workspace-aware RecallSource is not selected by default
and its recipe remains Mentle. No default missing-scope bypass is proven, so do
not enlarge Laputa work merely from generic API potential. Add actual-path tests.

## Observer/single-sink closure

Default currently selects memory-bml-sync plus cognitive capture. Build the LIFE
projection subscription once in App, checking selected candidate count exactly
one; zero/multiple selected sinks cannot silently choose a winner. Preserve
ObserverHost cursor store and recovery scan. It already replays terminal runs,
retains cursor on receiver/index failure, and permits receipt-aware providers.

Persisted run source/policy pins decide LIFE versus legacy, not the session's
current state or event payload fields. Exclude LIFE from old BML completion and
old capture; the subject provider verifies current trusted grant/source pin,
repairs/seals retained C2, builds a deterministic history projection with exact
original references, performs native operation and acknowledges its actual durable
receipt. Retry after lost ACK replays it. No extra transcript authority, scheduler,
owner, codec or synchronous core+BML transaction.

Observer ExcludeRun only advances a cursor; it does not produce a policy-skip
receipt. When a truthful skipped receiver result is required, the receipt provider
must return an explicit deterministic skip disposition rather than fake memory
commit. Native v3 writer rejection remains directory-wide under all policies.

## Actual pinned-library compatibility gap for root

At bb57, `runtimecore.Open` starts Garden ingest, recovering accepted/running/
spooled rows and every activity_json status other than applied. Existing queued
legacy work is already inside Garden; a Vivy observer exclusion cannot reach it.

`garden/internal/ingest/capture_activity.go:projectActivity` calls AppendSnapshot
or LookupCaptured against the ACTMEM owner. `actmem.loadHead` returns
recap_unavailable for a v3 head. The existing intent remains pending/unknown;
`service.go` worker retries drain every second, and HighWatermark and ArchiveSession
fence on every non-applied intent. The status decoder accepts only pending,
applying, applied, unknown; there is no policy_skipped terminal result. Current
agentapi has no owner API to resolve those pending intents truthfully from Vivy.

Also `actmem.LookupCaptured` calls s.load before its existing archive receipt scan,
so a v3 head prevents reading any otherwise retained legacy capsule outcome.
`agentapi.LookupCapture` can return Garden's accepted ingest row, which is not
proof the old ACTMEM native projection committed.

This is a concrete S5 pending-v3 compatibility gap requiring root-owned dependency
closure, not permission to change the pin here. Minimal likely native change:
preserve committed legacy receipt lookup, recognize v3 incompatibility before any
legacy writer mutation, terminalize uncommitted queue intents as explicit policy
skips, and exclude those terminal dispositions from retry/fence/archive counts.
Already-unknown effects must be resolved by actual retained outcome before any
skip; do not label an ambiguous prior commit as definitely absent. No new public
Backend method is needed. Root decides the smallest library seam and new pin.

## Historical sources and loaded status

S4 sources intentionally returns recap_sources_unavailable. Extend the existing
runtime control cell with a bounded exact source reader, not a Module parser.
Service decodes the requested historical head's own Sources.Digest through the
existing recap_receipt codec. Current authorizeSubjectRun/disposition-copy helpers
and ReadSubjectOriginal provide authorization and exact C2 evidence primitives.
Verify recorded digests, interaction IDs and aligned canonical/view message IDs;
expand only the stored subset. Historical fingerprint-only receipt remains
explicitly unavailable. BML lag/tombstone never removes retained C2 originals.

S4 loaded_status is already honestly unavailable. If implementing loaded/pinned
status, derive it from actual request/runtime pins; an owner head read alone cannot
prove what an active model request loaded. UI/headless/tool flows consume the same
runtime outputs and existing reference/attachment readers.

## Eino capability check

Pinned v0.9.20 retriever.Retriever exposes Retrieve returning schema.Document;
indexer.Indexer exposes Store returning document IDs. Neither supplies native
SQLite CAS plus immutable scoped receipts or trusted Vivy C2 authorization.
Keep existing Eino summarization/compaction/runner machinery unchanged. The bounded
Store/Host adapters implement durability/authority the generic RAG interfaces do
not own, and introduce no new ranking, retrieval engine, summarizer or agent loop.

## Verification boundary

No commands compiling, testing or starting services have run in this preparation.
After explicit lane release use toolchain Go1.26.4 and the existing local-only
runner with offline deps, credential stripping and deny proxy. Preserve root's
unstaged docs/evidence; stage explicit implementation paths only. Root owns full
fixed-candidate CI, independent review, external pin/push and installed acceptance.

## Native C5 producer checkpoint refinement (root-reviewed preparation)

This producer increment precedes Vivy consumer activation and requires its own
native checkpoint, independent review, publication and new exact pin. Source lane
is still frozen. This section supersedes the earlier tentative suggestion to make
policy-skipped another effect status: preserve effect status and record consumer
closure separately inside existing activity_json.

### Scope and files

Likely production files are `laputa/actmem/capture_pair.go` (archive-only lookup
under v3), an existing owner helper in `recap_history.go` if needed to avoid
duplicating its validation, `garden/internal/ingest/capture_activity.go`
(disposition/decoder/projection/drain/archive), `garden/internal/ingest/service.go`
(trusted binding and Start/HighWatermark predicates), and
`garden/internal/runtimecore/runtime.go` (pass the already resolved RecapBinding
to the same ingest before Start). The corresponding existing native tests and a
small producer report document the narrow semantic addition. No new database,
scheduler, ack store, recovery API, authority parser or Backend method is needed.
No generic missing-scope fallback change is justified by this checkpoint.

### Positive v3 policy proof and locking

Runtime already resolves the trusted `g.RecapBinding` against the exact existing
`g.Actmem` owner before it starts ingest. Carry that value into ingest, separate
from ProfileID. When this binding is absent, keep existing legacy behavior; never
infer it from ProfileID, request data, or a v3 prefix.

The policy check calls existing `s.Actmem.ReadRecap(ctx, trustedBinding)` and accepts
closure only on success with matching binding and revision > 0. This traverses the
actual validated reachable C1 chain and the existing native positive recovery
barrier. A zero uninitialized view is not proof. Generic recap_unavailable,
recap_commit_unknown, owner busy, malformed/incomplete chain, binding mismatch,
permission/IO, context errors and a raw schema prefix do not authorize closure.
Live unknown C1 state and an old unknown legacy effect are different: the former
prevents policy proof; the latter can remain unknown while a proven valid v3 policy
closes the incompatible consumer.

ReadRecap is logically read-only but can republish identical selected bytes and
flush reachable files on first recovery, including Windows. Reuse that qualified
barrier; do not invent a filesystem-read substitute or assert that it performs no
file operations. Assert identical ACTMEM/reachable-history/capsule bytes and stable
C1 revision/digest/text/coverage. Same-owner v3 is monotonic: legacy mutation remains
denied, and C1 edits/clear/restore remain v3. Read policy outside an open SQL rows
iterator/transaction; never hold database iteration while entering owner IO. Use
existing activityMu for bounded intent read/modify/write and ArchiveSession ordering.
Keep owner mutex within owner methods; never call public ReadRecap recursively
while holding that mutex.

Do not turn ReadRecap into a new prerequisite for healthy legacy writes: with a
trusted optional binding, a real nonempty v1/v2 directory normally returns
recap_legacy_nonempty from C1. Existing legacy-native success remains success.
Consult the positive policy gate only when resolving an incompatible legacy path
or validating an already persisted consumer closure; no-positive-proof leaves
ordinary v1/v2 behavior in place. A failure while validating an existing closure
cannot silently reopen that consumer or claim a complete watermark/archive.

### Effect outcome versus consumer disposition

Already `ActivityProjection.Status == applied` returns its original persisted
receipt before current policy/owner checks, without rewriting its entry IDs or
revision. This matters when a prior native result is readable but the current
owner is temporarily unavailable.

Add one optional typed consumer-disposition object in existing activity_json,
such as `legacy_consumer: {state: policy_closed, reason: recap_v3, binding: ...,
policy_revision: ..., policy_digest: ...}`. The revision/digest here identify the
positive C1 policy proof and are explicitly not the old effect result. Keep the
existing schema and original pending/applying/unknown/applied vocabulary; accept
old rows without the optional field. Strictly validate any present object and its
closed vocabulary; unknown fields/states, invalid proof/binding, or malformed JSON
cannot become an exclusion shortcut. Expose the optional disposition through the
existing ActivityProjection surface, not a new status database or API.

For an old attempted effect, preserve original Status, Before (revision+hash),
Source, Error, Entries and Revision when only closing the consumer. A closure does
not mean the native effect was absent, rejected or applied. No clearing source
text, no fake negative result, and no fabricated entry IDs/revision. Only exact
positive native archive proof with a complete valid original persisted Before can
resolve it through the existing finishActivity path. Save consumer closure in the
same existing activity_json update, then replay it durably after restart; failed
SQL persistence keeps the row retryable/fenced. No C1 write/coverage advancement is
part of this metadata update.

### Owner archive lookup

`LookupCaptured(entries)` has no trusted RecapBinding/context parameter and no
durable capture receipt table. Its current result.Revision is the current v2 head
revision, not necessarily the original capture revision. Root accepted the narrow
v3 archive-only meaning: actual retained Entries/IDs with Revision=0 because no
current legacy head exists. Never fill that field with the C1 revision.

The owner itself must positively validate an actual v3 chain and reject live
recapUnknown before taking an archive-only branch. Reuse native decodeRecap,
chain validation and existing sessionCapsules/parseFoldCapsule, including exact
pair identity, body, sources, scope and duplicate/partial handling. Garden must
not decode authority Markdown or scan capsules. A generic error from s.load is
not sufficient to select this path. The host-side policy proof still uses the
trusted external binding; archive lookup itself grants no C1 content read.

Refactor the existing common candidate matcher only as needed, keeping v1/v2
lookup and every legacy writer unchanged. Missing, partial or conflicting archive
is not negative outcome proof. Preserve the old intent's uncertainty. A valid-v3
consumer closure can be recorded separately, including when no exact prior effect
proof exists; it cannot erase that uncertainty. Capsule IO/malformed evidence must
remain visible and never be represented as a successful effect. Existing scanning
silently ignores unparsable fold files, so tests must ensure this does not become
an absence/applied claim in the new branch.

Garden's existing `finishActivity` computes Before.Revision+1. Continue using it
for v3 archive resolution only when original Before has a real complete native
snapshot hash/revision (zero revision can be a real empty v2 snapshot with a valid
hash), the exact complete pair is positively present, and increment cannot overflow.
An empty/fabricated/missing Before or partial/conflicting pair leaves the effect
unresolved. Do not derive Before from the current C1 head or substitute new sources.

### Exact queue, watermark and archive predicate changes

One shared semantic predicate must cover all four current SQL sites:

`needs_legacy_activity = activity_json != '' AND effect_status != 'applied'
AND NOT positively_verified_closed_consumer`.

The last term requires both a valid persisted consumer disposition bound to this
owner and a successful current trusted-v3 policy check. A string field alone or
COALESCE of malformed/unknown state cannot suppress a row. Keep SQL JSON guards
fail-closed (CASE/json_valid where needed) and strict native decoding as the final
validation. Reuse one helper/predicate definition rather than hand-maintained
slightly different closure rules in four queries. No live policy proof means no
new skip/exclusion; surface the error instead of returning an apparently complete
watermark. Do not hold rows open during policy reads or disposition writes.

1. `Service.Start`: preserve raw ingestion replay `status IN
   ('accepted','running','spooled')` as a separate OR; change only the legacy
   activity-recovery branch to needs_legacy_activity. A closed ACTMEM consumer
   must not silently discard a pending canonical material ingestion. Strictly
   validate relevant persisted closures before they can suppress recovery.
2. `drainActivity`: select needs_legacy_activity in rowid order. Process and persist
   policy closure once under positive v3; subsequent drains/restarts omit that
   consumer, so the existing one-second retry timer becomes idle. Other genuinely
   unresolved rows retain their current fence/retry behavior.
3. `HighWatermark`: its MIN(rowid) fence uses the same predicate. It remains the
   existing raw-ingestion ledger watermark, never a native-effect success receipt
   or permission to advance C1 CoveredThrough. Existing Window rows/status stay
   factual; closing the legacy consumer creates no new C1 source authority.
4. `ArchiveSession`: pending count uses the same predicate. After it reaches zero,
   valid v3 must return the truthful no-fold/policy-closed disposition through the
   existing error-only lifecycle boundary rather than still calling FoldSession.
   Current FoldSession rejects v3 and must continue to reject it. Valid legacy
   directories retain the existing actual fold. Unknown/invalid current owner
   state never masquerades as a successful archival fold.

ArchiveSession must resolve eligible session consumer dispositions using the same
projection code/worker, not spin forever awaiting a row the new queue omits. Any
returned no-op means that no legacy fold is required/permitted by the confirmed
policy; it must not report new capsule names or a committed effect. Caller-level
Observer receipts must likewise distinguish policy skip from native write success.

### Required RED-to-GREEN producer fixtures after source release

- Real `OpenPaused -> Submit -> persist intent -> Close -> reopen -> Start`,
  not a direct projectActivity-only invocation: pending never-attempted and
  applying/unknown legacy rows beneath a valid v3 owner become consumer-closed
  without altering original effect/evidence fields. Observe beyond the real
  one-second retry interval (bounded test timeout); no repeated writes/retries
  and same disposition after another restart.
- Existing applied row is returned unchanged, even with current unavailable
  policy; its actual entries/revision stay readable. Existing committed archive
  pair plus complete persisted Before resolves to its actual prior IDs and
  Before.Revision+1, with owner archive-only Revision=0 explicitly tested.
- Unknown prior effect with no archive, incomplete/conflicting archive or missing
  Before stays unknown/unresolved in the effect fields while separately closing
  the consumer only under proven valid v3. No negative receipt is invented.
- Malformed v3, incomplete/different-binding chain, live recap_commit_unknown,
  raw v3 prefix, C1 IO failure and revision-zero/uninitialized view do not create
  a policy closure. Failed activity_json update does not produce ACK or erase
  retry/fence evidence. Malformed consumer metadata cannot bypass strict decoding.
- HighWatermark stops fencing on proven closed consumers; ArchiveSession returns
  without attempting legacy FoldSession; pending raw material ingestion remains
  eligible. Neither result changes C1 text, coverage, digest or revision.
- Run all old writer calls (Pulse/Work/ring/AppendCaptured/Fold/delete capsule)
  against v3 and compare exact authority/archive bytes before and after. Real
  v1/v2 capture/replay/fold continue to work with no consumer-close field.
- Native Windows test covers revision>0 positive proof/recovery, and proves its
  missing-head zero view/orphan cannot become policy closure or negative outcome.
  Execute Windows qualification; cross-compilation is not equivalent evidence.
- Agentapi/runtimecore Open fixture proves trusted binding is passed before the
  real worker Start. It must not manually repair the producer after construction.

### S4 inherited full-App prerequisite

Root's independent S4 reviewer found that production App.ServiceDeps omitted
ToolEvidence although runtime fixtures manually supplied it; NewService does not
infer it. Therefore previous hand-wired fixture evidence does not prove default
App LIFE admission. S5 consumer activation requires the accepted S4 TDD fix and
its real full-App HTTP/seal/reopen fixture. Reuse that production construction
path without manually reconnecting ServiceDeps. Source remains frozen until root
finishes S4 fix acceptance and explicitly releases the producer source lane.

### Producer branch integration prerequisite

Root supplied current Laputa main `f44ba00eb6ab5aa6ab9a2f5c09868373e36679f5`.
Read its root, Garden, garden/internal, ingest and Laputa AGENTS and ADR-0018
through git show without switching the checkout. Common ancestor with bb57 is
`4b2bec2cc2ab3374b7ec1ab8d448e612c1e4db24`; main-only commits are 657ed3d,
56e1d6c and merge f44ba00. `git diff 4b2bec2..f44ba00 -- '*.go'` has no changes.
The two-tip bb57..f44 diff does show absent recovery Go code because main does not
yet contain bb57; it must not be used to replace or reset the recovery source.

After explicit producer release, the isolated native branch must normally merge
f44ba00 while retaining bb57, record source invariance, and only then execute the
TDD compatibility increment. Root owns publisher/pin operations. Current Laputa
checkout remains clean and detached at bb57 while S4 verification uses it.

ADR-0018 confirms BML-first validation, retained Mentle DIVA, explicit worker
admission, same owner/context/Journal, no parallel scheduler/store, no cascade
erase and planned Work/capture/fold compatibility. Its documentation-only delivery
does not itself authorize implementation; the approved recovery task and explicit
future source release supply that authorization. Existing raw evidence, C1 chain,
human Mission/Persona controls and legacy v1/v2 semantics remain intact.
