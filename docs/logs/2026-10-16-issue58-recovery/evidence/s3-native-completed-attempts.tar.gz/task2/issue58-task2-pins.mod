module issue58-pin-verification

go 1.26.4

require (
 github.com/ProjectViVy/laputa/garden v0.0.0-20261015094757-5f26de678a99
 github.com/ProjectViVy/laputa/laputa v0.0.0-20261015094757-5f26de678a99
 github.com/ProjectViVy/laputa/mentle v0.0.0-20261015094757-5f26de678a99
)
