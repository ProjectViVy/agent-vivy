from pathlib import Path
from collections import defaultdict, Counter
import hashlib, json, shutil
log=Path('docs/logs/2026-10-15-issue58-subject-binding')
commands={
 'red':"go test ./internal/runtime -run '^TestIssue58RetainedQuestionRestartKeepsExactAnswer$' -count=1 -json",
 'green':"go test ./internal/runtime -run '^TestIssue58RetainedQuestionRestartKeepsExactAnswer$' -count=1 -json",
 'focused':"go test ./internal/runtime ./internal/storage/... ./internal/app ./internal/rpc -run '^TestIssue58' -count=1 -json",
 'required-race':"go test -race ./internal/runtime ./internal/storage/sqlite -run '^(TestIssue58|TestMessageProjector|TestToolOperationCrashMatrix|TestApprovalResumeReusesPreparedToolOperation|TestServiceCancelConcurrentIdempotent)' -count=1 -json",
 'full':"go test ./internal/runtime ./internal/storage/... -count=1 -json",
 'native-regressions':"go test -race ./internal/runtime -run '^(TestServiceQuestion|TestGoalRecovery.*Question|TestPendingGoalQuestion|TestCancelResumedGoalQuestion|TestServiceRecoverRestoresSkillMountedTools|TestPlanGoalProbeSubmissionFencesLaterToolInSameBatch|TestMapperInterruptDetails|TestRealParkedCancellation|TestParkedCancellation|TestServiceCancelPendingRun)' -count=1 -json",
}
m={'base':'15e79419ccfa302ad3f8330fe72448c88796a5fb','eino':'v0.9.20','laputa_published':'4c7c6b20859375d0d764d3ba2a0188926cf73c9e','toolchain':'go1.26.4 linux/amd64','source_sha256':{},'eino_capability_sources_sha256':{},'verification':{},'fixture_manifests':[]}
for p in ['internal/runtime/tooladapter.go','internal/runtime/subject_question_test.go','internal/storage/postgres/history_mutations.go']:
 m['source_sha256'][p]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p in ['/root/go/pkg/mod/github.com/cloudwego/eino@v0.9.20/components/tool/interrupt.go','/root/go/pkg/mod/github.com/cloudwego/eino@v0.9.20/compose/tool_node.go']:
 m['eino_capability_sources_sha256'][p]=hashlib.sha256(Path(p).read_bytes()).hexdigest()
for name,cmd in commands.items():
 raw=Path('/tmp/issue58-task2-fix1-'+name+'.jsonl').read_bytes()
 rows=[json.loads(s) for s in raw.decode().splitlines() if s.startswith('{')]
 counts=defaultdict(Counter)
 for row in rows:
  if row.get('Test') and row['Action'] in ['pass','skip','fail']:
   counts[row['Package']][row['Action']]+=1
 failure=any(row['Action']=='fail' for row in rows)
 assert failure==(name=='red'),(name,'unexpected result')
 skips=[{'package':r['Package'],'test':r['Test']} for r in rows if r.get('Test') and r['Action']=='skip']
 m['verification'][name]={'command':cmd,'exit_code':1 if name=='red' else 0,'counts':dict(counts),'skips':skips,'failures':[r['Test'] for r in rows if r.get('Test') and r['Action']=='fail'],'raw_output_sha256':hashlib.sha256(raw).hexdigest()}
 if name=='green':
  m['fixture_manifests']=[r['Output'].strip() for r in rows if 'manifest resumed question' in r.get('Output','')]
 if name in ['red','green','required-race']:
  shutil.copyfile('/tmp/issue58-task2-fix1-'+name+'.jsonl',log/('task-2-fix-1-'+name+'.jsonl'))
(log/'task-2-fix-1-verification.json').write_text(json.dumps(m,indent=2)+'\n')
summary='''

## Task2 fix round1 — accepted I1/I2

Corrected PostgreSQL's two new exact-copy statements to native positional parameters inside its existing raw SQL transaction. Retained native Question answers now use the existing coordinator's exact request/result receipt before enhanced projection, while Question remains the decision authority and Eino remains the interrupt/resume engine. No ask_user invocation, new state, weakened evidence validator or ordinary-session retention was introduced. The new actual suspend/reopen/recover/resume regression proves a 36KB answer (including a literal untrusted-output header) expands exactly, survives model shortening with its reference, seals once and permits the next domain interaction; ordinary unshared control remains excluded.

All required fix-round1 gates pass at the already upgraded official Eino v0.9.20. Full details and limitations are appended to task-2-report.md; exact source/output hashes and skips are in task-2-fix-1-verification.json. PostgreSQL server acceptance and centralized S6 product CI remain pending.
'''
with (log/'summary.md').open('a') as f:f.write(summary)
with (log/'verification.md').open('a') as f:f.write('''

## Task2 fix round1 verification (BASE 15e79419ccfa302ad3f8330fe72448c88796a5fb)

Meaningful Question RED: real suspend, DB reopen, native recovery and successful answer reached terminal with no completed exact receipt; ordinary control passed. The early test fixture omitted the existing five-minute interaction expiry and failed at recovery; that setup failure was corrected and is not counted as behavioral RED. The narrow retained-only answer receipt then made the exact same regression green (3 test entries). Complete RED/GREEN outputs are task-2-fix-1-red.jsonl and task-2-fix-1-green.jsonl.

Final unchanged required race regex passes at Eino v0.9.20: Runtime58 and SQLite24 entries (82 total), including retained Plan plus the new Question. Exact output: task-2-fix-1-required-race.jsonl. Targeted existing native Question/Plan/interrupt/cancellation race regressions pass19 entries, including the former unretained Plan race baseline. Focused Issue58 runtime/storage/App/RPC passes93 entries (Runtime42, storage1, migrations2, SQLite24, App14, RPC10) with8 PostgreSQL skips. Full runtime/storage passes1404 entries (Runtime1133, storage21, migrations40, SQLite209, PG1) with42 skips: Runtime1 external GitHub, migrations5 PostgreSQL, PostgreSQL36. git diff --check passes. Exact commands, output hashes, fixture manifest and all skip names are task-2-fix-1-verification.json.

The two raw PostgreSQL statements use $1/$2 and $1/$2/$3; existing shared backend copy provenance/rollback conformance remains registered. No real PostgreSQL DSN is present, so PG compilation/skips are not parity acceptance. Native Windows, live provider/product acceptance, #66, HTTP/UI integration and final just ci stay pending at S6 per dispatch. No dependency pin, current snapshot constants/Persona fixture, parent plan/index, tool capability or Eino converter was changed by this fix.
''')
with (log/'acceptance.md').open('a') as f:f.write('''

## Task2 fix round1 acceptance evidence

The new real native Question restart flow retains the actual submitted answer and request, presents a shortened answer with an exact retained reference, seals one interaction and permits the next same-domain seal. Its ordinary unshared control stores the real answer in Question authority without adding retained tool receipts or C2 history. Existing pending/cancelled and native interrupt/Plan replay regressions pass. PostgreSQL raw fork/clone syntax is corrected; a legitimate real-server conformance run is still required before PostgreSQL parity acceptance.
''')
print('Recorded source hashes, red/green/race outputs, all actual gates and skips')
