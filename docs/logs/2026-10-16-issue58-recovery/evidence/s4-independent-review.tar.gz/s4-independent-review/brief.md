# S4 recovery independent review brief

Independent architecture/security/correctness review after root supplies frozen
S4 source SHA/tree and accepted S3 predecessor3e13019b (treef482293e). Read root
AGENTS, approved S4/C4 and recovery index/rulings; do not reopen product design.
Reviewer: GPT-6 Astra High per approved plan. No source mutations/subagents.
Use isolated fixed worktree/clone and test-only overlays; preserve original RED
probes and exact source qualification. Root owns integrated acceptance/publication.

Review actual owner use and host boundaries, not only UI/Module fakes:
- Same C1 bundle owner through attached runtime control; no global ActiveRecap,
  second owner/parser/storage or model-claimed subject/domain/session grant.
- Current whole-domain singleton auth for read/history/edit/clear/restore/sources;
  ordinary, contribution-only, worker/child/private/restricted/foreign/unknown deny.
  Model tools additionally actual persisted primary run/policy/selected tool pins;
  no bypass via guessed names, human ActionHost route or stale resumed context.
- Deferred discovery AND activation AND invocation: initial full schemas absent,
  ordinary/worker cannot discover names/descriptions or activate/invoke. Reuse the
  official Eino toolsearch algorithm and existing ToolHost governance. Search is a
  native meta-tool: successful results, errors/refusals and exact raw arguments
  must participate in the existing durable tool-operation evidence chain so the
  actual LIFE interaction seals and next admission/restart succeeds. No duplicate
  tool receipts, unknown-source promotion, clipping or seal guard relaxation.
- Full exact multiline UTF8, strict closed inputs (raw invalid UTF8 cannot be
  normalized into accepted content), fixed edit/clear/restore causes, operation
  idempotency/conflicts, no implicit CAS retry of a human draft. Owner unknown/error
  stays explicit, originals/coverage retained. Conflict reread reauthorizes.
- History preserves reconcile distinctly and restore creates a new revision;
  clear epoch/next-safe-boundary semantics truthful. Historical sources decode in
  runtime shared codec only; S4 explicit unavailable is permitted until S5 bounded
  exact source expansion, never fabricated excerpt/success.
- UI belongs to existing memory module/staging/UI kit. Active Recap/History/Long-term
  preserve BML controls, full editor separate draft/base, dirty refresh safety,
  conflict copy/reload/edit-latest, save/cancel, clear confirmation, restore, exact
  history and Persona review link. No LIFE selector/creation/sidebar/#66 expansion,
  shell store imports or localStorage authority. Actual loaded revision/unavailable
  distinguished from current saved revision; zero/legacy session token pressure
  cannot be shown as measured unified LIFE totals.
- SDK catalog/Recipes/assembly regenerated normally; no ad hoc backend routes,
  second transport, hand-generated code or prototype-only fake ActionHost product.
- Ordinary Coding/native tool discovery/context remains intact. Existing App model
  switch/cancel/drain fences remain valid after dynamic discovery adapter changes.

Execute meaningful focused tests with fake localhost HTTP via existing
/tmp/issue58-localonly-runner.py (offline deps, credential vars removed, external
non-forwarding deny proxy). Coordinate broad/race builds with root; disk is bounded.
No real tenant data/provider requests. Go1.26.4 toolchain and clean sibling Laputa
bb57e93; Eino0.9.20. Existing built UI may supply embedding prerequisite only; real
UI typecheck/test/build/browser results remain source-qualified separately.

Report concrete findings ranked Critical/Important/Minor with locations, evidence
and smallest correction. Preserve logs/probes under this directory. Explicitly
qualify unrun PostgreSQL/native Windows/live-model/installed #66 gates, and component
mocks versus actual split3015+backend browser tests. One consolidated author TDD fix
pass follows; root reruns original reviewer probes, no redundant second review of
same diff. Final whole-candidate S6 review is a separate integration scope.
