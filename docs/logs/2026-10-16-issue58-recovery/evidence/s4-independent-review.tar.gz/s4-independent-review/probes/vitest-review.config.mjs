import base from '/workspace/scratch/5dda642e718d/agent-vivy-issue58-s4-review/ui/vitest.config.ts';
export default {...base, root:'/workspace/scratch/5dda642e718d/agent-vivy-issue58-s4-review/ui', test:{...base.test, include:['/workspace/scratch/5dda642e718d/agent-vivy-issue58-recovery/.superpowers/sdd/S4-review/probes/recap-review.test.tsx']}};
