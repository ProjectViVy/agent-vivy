package app
import (
 "context"
 "encoding/json"
 "fmt"
 "io"
 "net/http"
 "net/http/httptest"
 "os"
 "path/filepath"
 "strings"
 "sync/atomic"
 "testing"
 "time"
 "agent-vivy/internal/cognitivecontract"
 "agent-vivy/internal/config"
 "agent-vivy/internal/domain"
 genassembly "agent-vivy/internal/generated/assembly"
 "agent-vivy/internal/runtime"
 "agent-vivy/internal/storage"
)
func TestReviewS4RealAssemblyNativeTools(t *testing.T) {
 var calls atomic.Int32
 var captures []string
 const exact = "全文\r\n\n中文 😀\n"
 server:=httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter,r *http.Request){
  raw,_:=io.ReadAll(r.Body);captures=append(captures,string(raw));i:=calls.Add(1)
  delta:=map[string]any{"role":"assistant","content":"done"};finish:="stop"
  if i<=2 {name,args:="tool_search",`{ "query" : "select:actmem_update" }`;if i==2{name="actmem_update";a,_:=json.Marshal(map[string]any{"base_revision":0,"operation_id":"review-native-edit","text":exact});args=string(a)};delta["content"]="";delta["tool_calls"]=[]any{map[string]any{"index":0,"id":fmt.Sprintf("review-call-%d",i),"type":"function","function":map[string]any{"name":name,"arguments":args}}};finish="tool_calls"}
  payload,_:=json.Marshal(map[string]any{"id":"fixture","object":"chat.completion.chunk","model":"deepseek-flash","choices":[]any{map[string]any{"index":0,"delta":delta,"finish_reason":finish}}})
  w.Header().Set("Content-Type","text/event-stream");fmt.Fprintf(w,"data: %s\n\ndata: [DONE]\n\n",payload)
 }));defer server.Close()
 root:=t.TempDir();t.Setenv("VIVY_USER_HOME",root);t.Setenv("VIVY_PROVIDER","deepseek");t.Setenv("VIVY_MODEL","deepseek-flash");t.Setenv("VIVY_API_BASE",server.URL);t.Setenv("DEEPSEEK_API_KEY","synthetic-local-test")
 runtime.SetEngineVersionOverride(pinnedEinoVersion);defer runtime.SetEngineVersionOverride("")
 cfg:=config.Default();cfg.Storage.DataDir=root;cfg.Storage.SQLite.Path=filepath.Join(root,"fixture.db");cfg.Runtime.WorkspaceRoot=filepath.Join(root,"workspace");os.MkdirAll(cfg.Runtime.WorkspaceRoot,0700);cfg.Governance.Profile=string(domain.PolicyProfileFullAuto);cfg.Runtime.Cron.Enabled=false
 main:=&issue58SplitMain{}
 open:=func()*App{a,err:=NewWithAssembly(context.Background(),cfg,genassembly.BuildDefault(),WithoutEars(),WithMainConversationResolver(main),WithInstructionRoot(cfg.Runtime.WorkspaceRoot));if err!=nil{t.Fatal(err)};return a}
 a:=open()
 owner:=a.cognitive.(cognitivecontract.RecapProvider).Recap();head,err:=owner.ReadRecap(context.Background());if err!=nil{t.Fatal(err)}
 main.source=&storage.SubjectSourceBinding{SubjectHistoryBinding:storage.SubjectHistoryBinding{SubjectID:head.Binding.SubjectID,DomainID:head.Binding.DomainID},SessionID:"review-main",SchemaVersion:1,ConversationID:"review-conversation",PolicyID:domain.SubjectResidentPolicy,ToolPolicyRef:"review-tools",Scope:"personal",Grant:storage.SubjectGrantSnapshot{Reference:"review-whole",Version:1,WholeDomainRead:true,Snapshot:json.RawMessage(`{"review":true}`)}}
 if err=a.backend.CreateSession(context.Background(),domain.Session{ID:"review-main",CreatedAt:time.Now().UnixMilli()});err!=nil{t.Fatal(err)}
 ctx,cancel:=context.WithTimeout(context.Background(),20*time.Second);defer cancel()
 auth,authErr:=a.service.AuthorizeRecap(ctx,"review-main","","");status,statusErr:=a.service.ContextStatus(ctx,"review-main");t.Logf("PRECHECK auth=%+v authErr=%v context=%+v contextErr=%v",auth,authErr,status,statusErr);if authErr!=nil||statusErr!=nil{a.Close();t.Fatal("fixture precheck failed")}
 id,err:=a.service.Run(ctx,"review-main","Search for Recap tools and apply exact text");if err!=nil{a.Close();t.Fatal(err)}
 if !a.service.WaitIdle(ctx){a.Close();t.Fatal("run not idle")};run,err:=a.backend.GetRun(ctx,id);if err!=nil{t.Fatal(err)}
 for _,raw:=range captures{t.Logf("ASSEMBLY_HTTP_CAPTURE %s",raw)}
 if run.Status!=domain.RunCompleted{it,_:=a.backend.Replay(ctx,id,0);for it.Next(){e:=it.Value().Event;t.Logf("FAIL_EVENT %s %s",e.Type,e.Payload)};it.Close();a.Close();t.Fatalf("native assembled run=%+v",run)}
 head,err=owner.ReadRecap(ctx);if err!=nil||head.Text!=exact||head.Revision!=1 {a.Close();t.Fatalf("same owner native edit failed %+v %v",head,err)}
 if strings.Contains(captures[0],`"name":"actmem_update"`)||!strings.Contains(captures[1],`"name":"actmem_update"`){t.Fatal("deferred schema boundary failed")}
 store:=a.backend.(storage.SubjectSourceStore)
 through,err:=store.CaptureSubjectHistory(ctx,main.source.SubjectHistoryBinding);if err!=nil||through!=1{t.Fatalf("native same owner seal through=%d %v",through,err)}
 if err=a.CloseContext(ctx);err!=nil{t.Fatal(err)}
 a=open();defer a.Close()
 id,err=a.service.Run(ctx,"review-main","Read after actual host restart");if err!=nil{t.Fatal(err)};if !a.service.WaitIdle(ctx){t.Fatal("restart not idle")};run,err=a.backend.GetRun(ctx,id);if err!=nil||run.Status!=domain.RunCompleted{t.Fatalf("restart=%+v %v",run,err)}
 head,err=a.cognitive.(cognitivecontract.RecapProvider).Recap().ReadRecap(ctx);if err!=nil||head.Text!=exact||head.Revision!=1{t.Fatalf("reopened same owner %+v %v",head,err)}
}
