package runtime
import (
 "context"
 "encoding/json"
 "testing"
 "strings"
 "agent-vivy/internal/domain"
 "github.com/cloudwego/eino/schema"
)
func TestReviewS4NativeSearchSealsAndRestarts(t *testing.T) {
 for _, raw := range []string{`{ "query" : "select:actmem_read", "max_results": 1 }`, `{"query":"no_matches_exist"}`, `{"query":true}`, `{"query":""}`} {
  t.Run(raw,func(t *testing.T) {
   var svc *Service
   tool:=&issue58GovernedTool{service:&svc}
   f:=newIssue58Wire(t,tool); svc=f.svc
   f.reply=func(i int)*schema.Message { if i==0{return issue58RecapToolReply("tool_search",raw)};return schema.AssistantMessage("done",nil) }
   run:=f.run(t,"review exact native search")
   op,err:=f.b.GetToolOperation(context.Background(),run.ID,"recap-tool_search")
   if err!=nil || string(op.EffectiveArguments)!=raw || op.State!=domain.ToolOperationCompleted { t.Fatalf("exact durable op %+v err=%v",op,err) }
   rows,_,err:=f.b.ReadSubjectRunEvidence(context.Background(),conformanceBinding(),run.ID)
   if err!=nil {t.Fatalf("native search evidence %v",err)}
   tools:=0; for _,r:=range rows {if r.Role==domain.RoleTool {tools++; t.Logf("EXACT_TOOL_ROW %s",r.Content)}}
   if tools!=1 {t.Fatalf("tool evidence count=%d",tools)}
   through,err:=f.b.CaptureSubjectHistory(context.Background(),conformanceBinding())
   if err!=nil || through!=1 {t.Fatalf("search run failed sealing through=%d error=%v status=%s",through,err,run.Status)}
   f.restart(t);svc=f.svc
   f.reply=func(int)*schema.Message{return schema.AssistantMessage("next admission",nil)}
   next:=f.run(t,"review restart after native search")
   if next.Status!=domain.RunCompleted {t.Fatalf("next admission status=%s failure=%s",next.Status,issue58FailurePayload(t,f,next))}
   for _,r:=range f.capture(){if strings.Contains(r,"exact tool result:"){t.Fatal("bounded evidence substituted for actual wire result")}}
  })
 }
}

type reviewS4OrdinaryTool struct{}
func (*reviewS4OrdinaryTool) Spec()domain.ToolSpec{return domain.ToolSpec{Name:"ordinary_echo",Readonly:true,Exposure:domain.ToolExposureDeferred,Description:"Ordinary allowed tool",Schema:json.RawMessage(`{"type":"object"}`)}}
func (*reviewS4OrdinaryTool) InvokableRun(context.Context,json.RawMessage)(string,error){return "ordinary",nil}
func TestReviewS4UnauthorizedActivationCannotExposeSchemas(t *testing.T){
 var svc *Service
 denied:=&issue58GovernedTool{service:&svc}
 f:=newIssue58Wire(t,denied,&reviewS4OrdinaryTool{});svc=f.svc
 mustCreateSession(t,f.b,"ordinary")
 if err:=svc.SetToolActivation(context.Background(),"ordinary",[]string{"actmem_read"},true);err!=nil{t.Fatal(err)}
 f.reply=func(i int)*schema.Message{if i==0{return issue58RecapToolReply("tool_search",`{"query":"select:actmem_read,ordinary_echo"}`)};if i==1{return issue58RecapToolReply("actmem_read",`{}`)};return schema.AssistantMessage("done",nil)}
 _,err:=svc.Run(context.Background(),"ordinary","Check current tool authorization");if err!=nil{t.Fatal(err)};svc.WaitIdle(context.Background())
 for i,raw:=range f.capture(){
  var wire struct{Tools []struct{Function struct{Name string}}; Messages []struct{Role string;Content string}}
  if err:=json.Unmarshal([]byte(raw),&wire);err!=nil{t.Fatal(err)}
  for _,entry:=range wire.Tools{if entry.Function.Name=="actmem_read"{t.Fatalf("forbidden schema request=%d",i)}}
  for _,msg:=range wire.Messages{if (strings.Contains(msg.Content,"available-deferred-tools")||msg.Role=="tool")&&strings.Contains(msg.Content,"actmem_read"){t.Fatalf("forbidden discovery %s",msg.Content)}}
  t.Logf("ORDINARY_HTTP_CAPTURE %s",raw)
 }
 if denied.calls!=0{t.Fatalf("guessed unauthorized invocation executed %d",denied.calls)}
}
