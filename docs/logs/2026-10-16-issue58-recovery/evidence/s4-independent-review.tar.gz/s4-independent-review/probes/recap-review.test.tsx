// @vitest-environment happy-dom
import { act } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { PluginHostProvider, type FaceStoreState, type FullUIHost } from '@vivy/ui-sdk';
import { RecapWorkspace } from '/workspace/scratch/5dda642e718d/agent-vivy-issue58-s4-review/plugins/vivy-memory/ui/vivy-memory/src/recap';

const HEAD = { revision: 7, text: '完整的中文 Recap\r\n\n# 第二段\n---\n', cause: 'reconcile', covered_through: 31, invalidation_epoch: 2, updated_at: '2026-10-15T12:00:00Z' };
const key = (name: string) => `plugin.vivy/memory.recap.${name}`;

describe('RecapWorkspace', () => {
 let container: HTMLDivElement;
 let root: Root;
 beforeEach(() => {vi.stubGlobal('IS_REACT_ACT_ENVIRONMENT',true); container=document.createElement('div');document.body.append(container);root=createRoot(container)});
 afterEach(async()=>{await act(async()=>root.unmount());container.remove();vi.unstubAllGlobals()});
 const button=(name:string)=>[...document.body.querySelectorAll('button')].find(item=>item.textContent===key(name)) as HTMLButtonElement;
 async function click(name:string){expect(button(name)).toBeTruthy();await act(async()=>button(name).click())}
 async function edit(text:string){const input=container.querySelector('textarea')!;expect(input).toBeTruthy();await act(async()=>{Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,'value')!.set!.call(input,text);input.dispatchEvent(new Event('input',{bubbles:true}))})}
 async function mount(call:(id:string,input:Record<string,unknown>)=>Promise<unknown>){const host=makeHost(call);await act(async()=>root.render(<PluginHostProvider host={host}><RecapWorkspace/></PluginHostProvider>));return host}


 it('review: holds the same operation id through an ambiguous failure and explicit retry',async()=>{
  const writes:Record<string,unknown>[]=[];
  await mount(async(id,input)=>{if(id==='vivy.recap.edit'){writes.push(input);if(writes.length===1)throw new Error('lost response');return {status:'applied',head:{...HEAD,revision:8,text:input.text}}};return {status:'listed',head:HEAD}});
  await click('edit');await edit('exact draft\r\n😀\n');await click('save');await click('save');
  expect(writes).toHaveLength(2);expect(writes[1]).toEqual(writes[0]);
  expect(container.querySelector('[data-testid="recap-full-text"]')?.textContent).toBe('exact draft\r\n😀\n');
 });
 it('review: clear completion preserves dirty draft and forces explicit conflict resolution',async()=>{
  let latest=HEAD;const writes:Record<string,unknown>[]=[];
  await mount(async(id,input)=>{if(id==='vivy.recap.clear'){latest={...HEAD,revision:8,text:'',cause:'clear'};return {status:'applied',head:latest,activation:'next_safe_boundary'}};if(id==='vivy.recap.edit'){writes.push(input);return {status:'conflict',head:latest}};return {status:'listed',head:latest}});
  await click('edit');await edit('retain my draft\n');await click('clear');await click('confirmClear');
  expect(container.querySelector('textarea')?.value).toBe('retain my draft\n');await click('save');expect(writes[0].base_revision).toBe(7);expect(writes).toHaveLength(1);
  await click('reload');await click('dismiss');expect(container.querySelector('textarea')?.value).toBe('retain my draft\n');
 });
 it('review: late save result cannot contaminate another session or delete its draft',async()=>{
  let finish:((value:unknown)=>void)|undefined;
  const host=await mount(async(id,input)=>{if(id==='vivy.recap.edit')return new Promise(resolve=>finish=resolve);return {status:'listed',head:{...HEAD,text:input.session_id==='other'?'other head':HEAD.text}}});
  await click('edit');await edit('main draft');await click('save');
  await act(async()=>host.store.setState({activeSessionId:'other'}));await click('edit');await edit('other draft');
  await act(async()=>finish?.({status:'applied',head:{...HEAD,revision:8,text:'main saved'}}));
  expect(container.querySelector('textarea')?.value).toBe('other draft');expect(container.textContent).not.toContain('main saved');
  await act(async()=>host.store.setState({activeSessionId:'main'}));await click('edit');expect(container.querySelector('textarea')?.value).toBe('main draft');
 });

});
function makeHost(call:(id:string,input:Record<string,unknown>)=>Promise<unknown>):FullUIHost {
 let state={activeSessionId:'main',connection:'connected',currentRun:null} as unknown as FaceStoreState;
 const listeners=new Set<()=>void>();
 return {api:{} as FullUIHost['api'],rpc:{capabilities:{protocol_version:'vivy.rpc.v1',capabilities:['module.action.invoke']},call:vi.fn(async(_method,params)=>{const p=params as {action_id:string,input:Record<string,unknown>};return call(p.action_id,p.input)}),onNotification:vi.fn(()=>()=>{}),onClose:vi.fn(()=>()=>{}),close:vi.fn()} as unknown as FullUIHost['rpc'],store:{getState:()=>state,getInitialState:()=>state,subscribe:(listener:()=>void)=>{listeners.add(listener);return()=>listeners.delete(listener)},setState:(partial:Partial<FaceStoreState>)=>{state={...state,...partial};listeners.forEach(listener=>listener())}} as unknown as FullUIHost['store'],router:{navigate:vi.fn().mockResolvedValue(undefined),invalidate:vi.fn().mockResolvedValue(undefined)},composition:{} as FullUIHost['composition'],t:key=>key,registerCleanup:()=>({active:true,dispose:vi.fn()})};
}
