module issue58-native-pin-verification

go 1.26.4

require (
 github.com/ProjectViVy/laputa/garden v0.0.0-20261015222145-249a756e04c5
 github.com/ProjectViVy/laputa/laputa v0.0.0-20261015222145-249a756e04c5
 github.com/ProjectViVy/laputa/mentle v0.0.0-20261015222145-249a756e04c5
)
