# Independent bounded S6 CI review

## Verdict

**PASS — no substantive Critical, Important, or Minor issues found in the four-file CI delta.** This accepts the wiring for execution, not native Windows behavior, rendered browser acceptance, S5 integration, or whole S6/Issue #58 completion.

Reviewed immutable source: local `2e6273d8b4a6a58d5154633b1805137a633a59b9`, tree `89dbbe29a3fd08f7d116ff44b7e0a7c8c11e4093`, versus `6e4096e8444b89713a2857b061e63fa1c2e4be01`. Published counterpart `f1d651622bf91b6aabdfc408964850eea3980ea8` was supplied by root; this review did not fetch or claim a live CI result. Worktree `/workspace/scratch/5dda642e718d/agent-vivy-issue58-native-pin-validation` remained clean. Sibling Laputa was verified clean at the lock's `249a756e04c5f28af781e4dadea9e9086689bde0`.

Scope: `justfile`, `.github/workflows/ci.yml`, `ui/playwright.issue58.config.ts`, and `docs/logs/2026-10-16-issue58-recovery/s6-ci-wiring.md`. Referenced bootstrap, fixtures, default Playwright setup/teardown, module declarations, and installed Playwright process cleanup were read only to assess this delta. Root/UI AGENTS and the requested code-review workflow were read. No source/index edits, commits, dependency changes, production changes, broad formatting, or subdelegation occurred. Review outputs are confined to `.superpowers/sdd/S6-ci-review`.

## Review evidence

### Native identity, source and module selection

`.github/workflows/ci.yml:109–200` introduces an actual `windows-latest` job, uses the repository's declared Go version, calls the existing bootstrap, compares native checkout HEAD to the published lock, and records both Vivy/native identities, host/runner OS, GOOS/GOARCH, Go version and run URL. The explicit GOOS guard rules out reporting a non-Windows target as this lane. This is an execution workflow, not a cross-compile command.

Each native command executes from its own module directory. BML's `go.mod` declares SQLite `v1.56.0`, whereas the root/Garden declaration selects `v1.59.0`; entering `bml` is therefore material. No `go.work` exists in the inspected source closure. Garden's sibling replacements remain the source-pinned native Laputa/Mentle modules. Capturing `go mod edit -json` is accurately labeled declared-module evidence; it is not mislabeled as a complete resolved dependency graph. The actual suites are full BML `./...`, ACTMEM `./actmem`, and the three specified Garden packages, with no test-name filter.

The native lane has a 20-minute overall bound and each `go test` has a five-minute per-package bound, serial package scheduling and uncached execution. It preserves command records before tests, raw JSONL/stderr, per-lane exit/timing/counts, and cumulative results. Native command failures are collected explicitly despite PowerShell native-command error preference being disabled; failed test/package events also fail the job. Ordinary test failures do not prevent the next required native lane from being attempted. Setup/metadata/parse failures fail closed. A timeout is failure/incomplete execution, not acceptance.

### CI coverage and failure propagation

The new `bml-ci` recipe enters the previously omitted nested module and runs vet before tests; both commands propagate nonzero exit status. Both `ci` and `backend-ci` depend on it. The pre-existing recipes and dependency order are unchanged apart from appending this gate; the existing 35-minute root package bound, DIVA/MemoryLoop recipes and plugin gates are not weakened.

The always-running aggregate now requires `backend`, `browser`, `native`, and `ui` each to report `success` (`ci.yml:369–395`). Failure, cancellation or skipping of a required job cannot produce aggregate success. The new browser step propagates Playwright's exit status. A prior failed browser step may skip it, but then the job/aggregate remains failed; this is not a false successful Recap gate.

### Browser ownership and evidence

The selected full-UI executable is started directly, its PID is retained, and the changed teardown (`ci.yml:342–352`) stops that selected process and waits up to 30 seconds before the new Recap test can start. The inspected fixture action is in-process echo behavior with no child process launch. The separate default Playwright backend (`go run` on 8799) is owned by the previous Playwright invocation; the installed pinned Playwright implementation uses Windows `taskkill /T /F` for its process cleanup. Therefore the new PowerShell wait is not being mistaken for a generic process-tree killer. No surviving child listener was identified in the actual selected fixture path.

A bounded reviewer probe executed the same `Get-Process → Stop-Process → Wait-Process` sequence against a real sleeping process and confirmed successful exit/absence. **That probe ran on Linux PowerShell and does not qualify Windows port release.** The upcoming actual Windows browser gate must still prove the transition from the old 3015 owner to the exclusive new Vite/Recap pair. `reuseExistingServer:false` for both new servers fails rather than silently reusing a stale listener.

The existing fixture uses `t.TempDir`, a disposable workspace/database/owner, synthetic loopback model settings, authenticated ActionHost/C1, and a test-only singleton resolver. `GO_EXE` is obtained from the installed Go command; the existing shell-aware quoting rejects unsupported characters. The stop marker is in a dedicated OS temporary directory and asks the fixture to run App shutdown; no production tenant paths or public authorization bypass are introduced. Assertions and production denial cases are unchanged.

The new `outputDir` is specifically `ui/test-results/issue58-recap`. Installed Playwright removes the selected output directory, so this invocation does not erase its sibling/default test results. The unchanged scenario explicitly saves read/conflict/history/source-unavailable/clear-confirm images; `screenshot:'on'` additionally preserves success/failure screenshots and `trace:'retain-on-failure'` preserves failed test traces. Successful traces are deliberately not promised. Setup failure before a browser exists cannot produce a screenshot; artifact absence warns while the underlying job remains failed. The artifact paths contain test evidence only, not application data roots.

### Immutable action pin and evidence provenance

The added upload steps use full SHA `cf430e030ddbb5b0abf93d22962f4752f3646cd9`. I inspected the previously captured official GitHub tag/action metadata: `actions/upload-artifact` tag `v7.0.2` points to that commit, and its `action.yml` declares `node24`. This is an archived upstream verification, not a new network lookup. Workflow permission remains `contents: read`; no additional credentials or broad permissions were introduced.

I recomputed every archived hash: **37 author raw files plus all 4 frozen source hashes match**, and **29 root-fixed raw files match**. Their checkpoint/tree identifiers match the reviewed candidate. The root-fixed archive records actual `just bml-ci` exit 0 at this candidate, configuration checks, all 17 PowerShell blocks parsed, one Playwright test collected, and strict TypeScript checks. These remain root execution evidence, not tests rerun by this reviewer. The historical baseline `just --unstable --fmt --check` exit 1 is preserved and remains a genuine pre-existing formatting RED; it was not fixed or relabeled.

## PASS / FAIL / NOT RUN

| Check | Status and qualification |
|---|---|
| Four-file source review, source/tree identity and clean checkout | PASS |
| `git diff --check 6e4096e... HEAD` | PASS, reviewer executed |
| Author/root archive hashes and frozen source hashes | PASS, reviewer recomputed all |
| Selected-process stop/wait semantic probe | PASS, reviewer executed on Linux PowerShell only |
| Actual `just bml-ci`, config, 17 PowerShell parses, Playwright list, strict TS | PASS in verified root-fixed archive; not redundantly rerun |
| Historical baseline Justfile formatter | FAIL preserved in author archive; pre-existing, unrelated to new recipe semantics |
| Actual Windows native lane and actual Windows browser/process-port transition | NOT RUN by reviewer; await real workflow evidence |
| Rendered Recap test/screenshots/traces, full `just ci`, S5 integrated runtime | NOT RUN by reviewer |
| PostgreSQL/live model/installed #66/tenant activation | NOT RUN; no claim |

Root reported workflow run `38825120165` pending at assignment and an earlier `38824982363` potentially cancelled. Neither is treated as a pass, and this report is not a live status check. Config parsing, Linux execution, test collection and source review do not establish native Windows or rendered UI results.

## Reviewer probe command and artifacts

```text
python /tmp/issue58-localonly-runner.py /workspace/scratch/5dda642e718d/agent-vivy-issue58-native-pin-validation review-ci-teardown-process pwsh -NoProfile -File /workspace/scratch/5dda642e718d/agent-vivy-issue58-recovery/.superpowers/sdd/S6-ci-review/teardown-process-probe.ps1
```

Result: exit 0, 1.268 seconds, candidate `2e6273d8...`, external requests rejected 0/forwarded 0, credentials stripped by name, dependency network disabled. The unchanged required runner was used. No broad test suite or browser was started.

Adjacent artifacts preserve the probe script/raw log/runner metadata, reviewed delta, source identity/hash seal, archive verification and archived official upload-action metadata. `manifest.json` hashes this report and every adjacent evidence file. No new RED was produced by reviewer execution. Root retains publication/remediation, actual CI observation and later whole-candidate S6 acceptance.
