$ErrorActionPreference = 'Stop'
$process = Start-Process -FilePath '/bin/sleep' -ArgumentList '30' -PassThru
try {
  $selected = Get-Process -Id $process.Id -ErrorAction SilentlyContinue
  if ($selected) {
    $selected | Stop-Process -Force -ErrorAction Stop
    $selected | Wait-Process -Timeout 30 -ErrorAction Stop
  }
  if (Get-Process -Id $process.Id -ErrorAction SilentlyContinue) { throw 'selected process survived' }
  Write-Output 'PASS: selected process Stop-Process then Wait-Process; Linux PowerShell semantic probe only'
} finally {
 Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
}
