package app

import (
	genassembly "agent-vivy/internal/generated/assembly"
	memorymodule "agent-vivy/internal/modules/memory"
	"fmt"
)

// Bind generated T1 instances to this App's actual service before any workers
// or tool/context dispatch. Closed bindings never fall back to ambient Active.
func bindMemoryProviders(assembly genassembly.RuntimeAssembly, service *memorymodule.Service) error {
	bind := func(value any) error {
		if provider, ok := value.(interface {
			BindMemoryService(*memorymodule.Service) error
		}); ok {
			if err := provider.BindMemoryService(service); err != nil {
				return fmt.Errorf("app: bind memory provider: %w", err)
			}
		}
		return nil
	}
	for _, p := range assembly.Tools {
		if err := bind(p); err != nil {
			return err
		}
	}
	for _, p := range assembly.ContextSources {
		if err := bind(p); err != nil {
			return err
		}
	}
	for _, p := range assembly.RunObservers {
		if err := bind(p); err != nil {
			return err
		}
	}
	for _, set := range assembly.ActionSets {
		for _, p := range set.Providers {
			if err := bind(p); err != nil {
				return err
			}
		}
	}
	return nil
}
