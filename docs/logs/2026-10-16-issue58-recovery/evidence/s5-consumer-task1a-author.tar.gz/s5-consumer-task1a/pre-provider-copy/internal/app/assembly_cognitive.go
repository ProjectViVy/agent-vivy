package app

import (
	"context"
	"fmt"
	"path/filepath"
	"sync"

	"agent-vivy/internal/cognitivecontract"
	"agent-vivy/internal/config"
	"agent-vivy/internal/domain"
	genassembly "agent-vivy/internal/generated/assembly"
	memorymodule "agent-vivy/internal/modules/memory"
	"agent-vivy/internal/runtime"
	"agent-vivy/internal/storage"
	"github.com/ProjectViVy/agent-vivy/bml"
	gardenmemory "github.com/ProjectViVy/laputa/garden/memory"
	laputaevolution "github.com/ProjectViVy/laputa/laputa/evolution"
)

// generatedCognitiveFactoryBinding is the opaque accessor emitted by the
// generated RuntimeAssembly whenever vivy/diva-cognitive is selected.
type generatedCognitiveFactoryBinding interface {
	CognitiveFactoryValue() any
}

// cognitiveBundleForAssembly resolves the sealed factory seam: a composition
// without vivy/diva-cognitive returns nil; a selected module whose emitted
// binding is missing or mistyped fails init instead of degrading to a second
// construction path.
func cognitiveBundleForAssembly(ctx context.Context, assembly *genassembly.RuntimeAssembly, cfg config.Config, generationID string, store storage.SnapshotStore, memoryService ...*memorymodule.Service) (cognitivecontract.Bundle, error) {
	if !assemblyHasModule(assembly.Manifest.Modules, "vivy/diva-cognitive") {
		return nil, nil
	}
	binding, ok := any(assembly).(generatedCognitiveFactoryBinding)
	if !ok {
		return nil, fmt.Errorf("app: generated Assembly lacks the cognitive factory seam")
	}
	factory, ok := binding.CognitiveFactoryValue().(cognitivecontract.Factory)
	if !ok || factory == nil {
		return nil, fmt.Errorf("app: generated cognitive factory binding has invalid type")
	}
	// Config paths may be relative to the process working directory. The
	// owner requires an absolute root; resolve it before crossing its seam.
	dataRoot, err := filepath.Abs(cfg.DataDirectory())
	if err != nil {
		return nil, fmt.Errorf("app: resolve cognitive data directory: %w", err)
	}
	cfg.Storage.DataDir = dataRoot
	var makeBackend func(context.Context, cognitivecontract.RecapBinding) (gardenmemory.Backend, error)
	if len(memoryService) > 0 && memoryService[0] != nil {
		if !assemblyHasModule(assembly.Manifest.Modules, memorymodule.ID) {
			return nil, fmt.Errorf("app: unselected memory service")
		}
		owned := memoryService[0]
		makeBackend = func(_ context.Context, binding cognitivecontract.RecapBinding) (gardenmemory.Backend, error) {
			return memorymodule.NewBoundBackend(owned, bml.OwnershipBinding{SubjectID: binding.SubjectID, DomainID: binding.DomainID, ScopeKind: "personal", DestinationID: "bml"})
		}
	}
	bundle, err := factory(ctx, cognitivecontract.FactoryInput{
		NewSubjectBackend: makeBackend,
		ResolveRecapBinding: func(ctx context.Context, actualRoot string) (cognitivecontract.RecapBinding, error) {
			binding, err := ResolveSubjectBinding(ctx, store, actualRoot)
			return cognitivecontract.RecapBinding{SubjectID: binding.SubjectID, DomainID: binding.DomainID}, err
		},
		Config:       cfg,
		GenerationID: generationID,
		Store:        store,
	})
	if err != nil {
		return nil, fmt.Errorf("app: cognitive factory: %w", err)
	}
	return bundle, nil
}

// lazyDomain resolves the bound evolution Domain on first use so a
// selected-but-unavailable memory writer fails the affected effect, not the
// whole composition. The resolution is memoized.
type lazyDomain struct {
	binding laputaevolution.RunBinding
	bundle  cognitivecontract.Bundle
	once    sync.Once
	domain  laputaevolution.Domain
	err     error
}

func (d *lazyDomain) bound(ctx context.Context) (laputaevolution.Domain, error) {
	d.once.Do(func() {
		d.domain, d.err = d.bundle.BoundDomain(ctx, d.binding)
	})
	return d.domain, d.err
}

// BindForRun reuses the one owned domain with this run's persisted pins.
// The App construction binding is not a new run's authority revision.
func (d *lazyDomain) BindForRun(ctx context.Context, binding laputaevolution.RunBinding) (laputaevolution.Domain, error) {
	return d.bundle.BoundDomain(ctx, binding)
}

func (d *lazyDomain) Collect(ctx context.Context, window laputaevolution.Window) (laputaevolution.EvidenceBatch, error) {
	bound, err := d.bound(ctx)
	if err != nil {
		return laputaevolution.EvidenceBatch{}, err
	}
	return bound.Collect(ctx, window)
}

func (d *lazyDomain) Apply(ctx context.Context, effect laputaevolution.Effect) (laputaevolution.EffectReceipt, error) {
	bound, err := d.bound(ctx)
	if err != nil {
		return laputaevolution.EffectReceipt{}, err
	}
	return bound.Apply(ctx, effect)
}

func (d *lazyDomain) Lookup(ctx context.Context, operationID string) (laputaevolution.EffectReceipt, error) {
	bound, err := d.bound(ctx)
	if err != nil {
		return laputaevolution.EffectReceipt{}, err
	}
	return bound.Lookup(ctx, operationID)
}

// cognitiveControlPort maps the bound bundle's armed control cell onto the
// runtime service callbacks. It is constructed once per composition and
// attached to the bundle after Service construction (single-use).
type cognitiveControlPort struct {
	svc    *runtime.Service
	bundle cognitivecontract.Bundle
}

func (c *cognitiveControlPort) GetState(ctx context.Context) (cognitivecontract.ControlState, error) {
	if c.svc == nil {
		return cognitivecontract.ControlState{}, runtime.ErrCognitiveUnavailable
	}
	state, watermark, err := c.svc.CognitiveStatus(ctx)
	if err != nil {
		return cognitivecontract.ControlState{}, err
	}
	policy, revision, err := c.svc.CognitivePolicyState(ctx)
	if err != nil {
		return cognitivecontract.ControlState{}, err
	}
	return cognitivecontract.ControlState{
		Enabled:        policy.Enabled,
		MinIntervalMS:  policy.MinIntervalMS,
		PolicyRevision: revision,
		ActiveRunID:    state.ActiveRunID,
		SourceID:       c.bundle.SourceID(),
		Watermark:      watermark,
		PendingThrough: state.PendingThrough,
		Phase:          state.Phase,
		BlockReason:    state.BlockReason,
	}, nil
}

func (c *cognitiveControlPort) SetPolicyCAS(ctx context.Context, policy laputaevolution.TriggerPolicy, baseRevision uint64) (cognitivecontract.ControlState, error) {
	if c.svc == nil {
		return cognitivecontract.ControlState{}, runtime.ErrCognitiveUnavailable
	}
	if err := c.svc.UpdateCognitivePolicyCAS(ctx, policy, baseRevision); err != nil {
		return cognitivecontract.ControlState{}, err
	}
	return c.GetState(ctx)
}

func (c *cognitiveControlPort) Trigger(ctx context.Context) (cognitivecontract.ControlState, error) {
	if c.svc == nil {
		return cognitivecontract.ControlState{}, runtime.ErrCognitiveUnavailable
	}
	elig, err := c.svc.TriggerCognitive(ctx)
	if err != nil {
		return cognitivecontract.ControlState{}, err
	}
	state, getErr := c.GetState(ctx)
	if getErr != nil {
		return cognitivecontract.ControlState{}, getErr
	}
	state.Eligibility = &elig
	return state, nil
}

func (c *cognitiveControlPort) Cancel(ctx context.Context, runID domain.RunID) (cognitivecontract.ControlState, error) {
	if c.svc == nil {
		return cognitivecontract.ControlState{}, runtime.ErrCognitiveUnavailable
	}
	cancelled, err := c.svc.CancelRun(ctx, runID)
	if err != nil {
		return cognitivecontract.ControlState{}, err
	}
	state, getErr := c.GetState(ctx)
	if getErr != nil {
		return cognitivecontract.ControlState{}, getErr
	}
	if !cancelled {
		state.BlockReason = "run_not_active"
	}
	return state, nil
}

// The per-module ActionHost wrapper that hands the armed dispatcher to the
// generated providers lands with DN-4C (same pattern as actionhost's
// newMaskActionHost); until then every cognitive action fails closed at its
// cognitivecontract.ActionHost type assertion.

// AuthorizeRecap shares the already attached runtime cell and the same C1 owner.
func (c *cognitiveControlPort) AuthorizeRecap(ctx context.Context, sid domain.SessionID, rid domain.RunID, name string) (cognitivecontract.RecapBinding, error) {
	if c.svc == nil {
		return cognitivecontract.RecapBinding{}, cognitivecontract.ErrUnarmed
	}
	return c.svc.AuthorizeRecap(ctx, sid, rid, name)
}
