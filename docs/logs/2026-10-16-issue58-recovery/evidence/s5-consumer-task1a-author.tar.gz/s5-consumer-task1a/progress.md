# SDD ledger — plan: docs/superpowers/plans/issue-58/S5.md

Task1 BASE22a137c68e53a5ba9b46b73fecb8ab019aa2e523. Root released exclusive
source/index; shared recovery checkout is the authorized isolated write lane.
Task2 remains unauthorized and all its actual unsafe tool/recall seams remain open.

Preflight: Task1 native adapter and exact C2 source reader feed Task2 observer;
no Task2 activation is implemented here. Native operation status API requires
explicit bounded extension because Garden MutationStatus has no digest. Root
approved Store/Home.LookupBoundOperation, retaining strict digest lookup/replay.
Ruling: preserve legacy ProfileID/raw/Mentle route (root/revision3C5); no same-key
Config.Backends replacement, unused map entry, UUID alias or second owner.

Modules: existing T1 vivy/memory-bml(+sync/tools), vivy/diva-cognitive. Existing
std/context-source@v1, std/observer/run@v1, std/control-action@v1 and private
core/cognitive-factory@v1 remain unchanged; no public new Port/Grant. App owns
exact Home service and one Garden bundle; native adapter borrows Home and Close
is no-op. Garden memory.Backend is existing scoped semantic boundary. Current
sources action uses attached Service authorization/C2 reader, no module parser.
Native SQLite/FTS/receipts stay BML-owned; core Journal/C2 originals stay core.
Eino check: pinned0.9.20 retriever.Retriever.Retrieve and indexer.Indexer.Store
cannot provide exact native CAS/outcome or current C2 grants. Reuse existing
model/tool/compaction paths; no new RAG/model/orchestration capability is added.

Verification ruling: root owns full justci/independent Astra/fixed-SHA/publish.
All author code checks use unchanged local-only runner, Go1.26.4, offline deps,
credential stripping and deny proxy. Logs retained here, not skill auto-runner.
No broad gofmt/justci over untracked reviewer Go probes; stage explicit paths.

Task1 native status prerequisite: semantic RED3missingAPI -> GREEN162testevents
(native complete normal/race). Added read-only LookupBoundOperation with one
shared query/decoder and explicit nil optional digest internal mode. Strict
LookupBoundMutation still rejects empty/wrong digest. Same transaction replay
checks complete canonical fingerprint; no schema/write API/dependency changes.

Task1a phase split (root): stop after adapter/lifecycle, before exact historical
C2 source navigation Task1b. TDD found two real App ownership seams beyond root
identity: distinct core leases sharing Home, and Run's independent shutdown path.
Both now use the exact service. Assembly reuse RED required typed firstparty
provider copies; the caller Assembly is not rebound. A temporary entry-defer
closing Home alone on early listener return was removed after root ordering
review. Only ordinary cancellation closes after consumer drain; early listener
reusable callers retain full-Close responsibility. CLI fatal process exit remains
unchanged. All temporary passing logs and failure chains remain evidence.

Ruling: deterministic adapter metadata uses unspecified zero times and hashes the
complete raw Garden request into native provenance, retaining typed sources. This
avoids invented clocks and today's-row reconstruction; source eligibility is not
conferred by the adapter (cost if wrong: downstream UI must treat zero as unknown,
and Task2 must enforce real C2 grants before invoking this private selected sink).
Ruling: root-authorized op-only native read extension is the existing Backend
MutationStatus compatibility seam; strict public digest lookup remains strict
(cost if wrong: operation-only reads could expose retained results; exact full
native owner/destination checks and corruption tests are retained).

Task1a: complete author checkpoint f6bcae7df73cd192e352480762621b8bb84ae711,
tree28c871b5da28c48f14157b05f12fff6f440c0e70; parent46a10b3. Final normal380test
PASS+4pk/3optinSKIP25.467s; focused race81PASS+4pk/1SplitFixtureSKIP70.878s;
vetPASS2.085s; rootMVS native162PASS+1pk1.727s. All16 Task1a tested Go source
hashes matched staged bytes before commit. Source/index FREEZE released to root.
No further source, index, tests, builds, Task1b or Task2 work without new release.
Independent review/root immutable rerun remain pending. ActualWindows NOTRUN.
