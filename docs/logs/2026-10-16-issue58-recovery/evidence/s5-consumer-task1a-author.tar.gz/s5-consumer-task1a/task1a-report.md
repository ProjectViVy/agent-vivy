# S5 Task1a author checkpoint

Status: source and index FROZEN and released to root. No push, dependency change,
Task1b source-navigation implementation or Task2 activation was performed.
Independent acceptance remains pending.

Consumer checkpoint: `f6bcae7df73cd192e352480762621b8bb84ae711`
Tree: `28c871b5da28c48f14157b05f12fff6f440c0e70`
Parent/native read-status prerequisite: `46a10b3f299c00b3efe6b8328a42967bf537ce30`
Prerequisite tree: `bdf80d0396c0fd46539d5f2c6cbf53d67875cdeb`
Release base: `22a137c68e53a5ba9b46b73fecb8ab019aa2e523`
Human commit identity: `大湿 <57738020+mastwet@users.noreply.github.com>`.

The prerequisite has5 changed paths; Task1a has19 explicitly staged paths,
including16 Go source/test paths and3 minimal English iteration records. The
24-path cumulative immutable blob/SHA256 manifest is
`checkpoint-source-manifest.json`. `task1a-final-sourcehashes.json` records the
16 final tested working-source hashes; each matched the explicit index before
commit. Runner metadata correctly names the then-HEAD46a; it does not imply
these working-source runs tested immutable46a. Root's separate46a reruns are
not relabeled as consumer coverage.

## Result

The existing Garden memory Backend is implemented by an App-owned exact-bound
native BML adapter: actual native search rank and visibility, exact native
expansion, native CRUD/CAS/fingerprint, retained outcomes/status and replay.
No raw ingest method or legacy profile/backend replacement is added. Raw strings
are UTF-8 checked before canonical encoding; all request fields and typed source
refs affect the native fingerprint. Source clocks remain unspecified zeros.
Search cards contain no source bodies. Native export is not core-original C2
export. Borrowed backend Close is no-op.

App acquires memory under the normalized root AND actual existing core lease.
Identity-aware release cannot detach a replacement. Selected firstparty provider
copies bind the actual App service without mutating the caller Assembly. The
existing Recap owner callback prepares one bound backend through private factory
input; Garden ProfileID diva/raw/Mentle routing remains. Actual tests cover
constructor failure/foreign root/same Home distinct lease/no-memory close,
Assembly sequential reopen, old/fresh provider separation, competing constructors,
concurrent module acquire/close, and actual Run cancellation/reopen. Run's regular
cleanup closes Home after consumers drain. Early listener exit still needs full
caller Close for reusable in-process lifetime; face/headless defer it, CLI fatal
error exits process. No new Home-only early cleanup remains.

The full behavior and limitations are tracked in
`docs/logs/2026-10-16-issue58-consumer-task1a/{summary,verification,acceptance}.md`.

## Verification

| Final gate | Result |
| --- | --- |
| Four affected packages, normal | PASS380 test events+4pk,25.467s |
| Focused native adapter/App lifecycle/concurrency/Recap race | PASS81+4pk,70.878s;0 races |
| Affected vet | PASS2.085s |
| Native BML in root SQLite1.59 MVS | PASS162+1pk,1.727s |
| Native prerequisite SQLite1.56 normal/race | PASS162+1pk each,1.576s/8.097s |
| Root independent immutable46a native normal/race | Parent-reported PASS162+1 each,1.579s/8.405s; separate evidence |
| Explicit16-path gofmt and git diff checks | PASS |
| Actual Windows/browser/full repository CI | NOT RUN in this author phase |

Normal's3 existing opt-in SKIPs are CognitiveActionFixtureCapture, SplitFixture,
and RealProviderSmoke. Focused race has1 opt-in SplitFixture SKIP. MemoryLoop
is omitted via the parent's existing documented `-skip '^TestMemoryLoop'`
phase boundary; no assertions were skipped or weakened to qualify the adapter.
The parent owns separate unchanged MemoryLoop/default/DIVA gates. BML and Mentle
memorytest conformance use real Home/catalog, not fake backend fixtures.

Every literal command, exit, timing, external request count and parsed pass/fail/
skip is in `attempt-results.json` and its29 unchanged raw `.log`/`.json` pairs.
Every attempt used the unchanged `/tmp/issue58-localonly-runner.py`, absolute
`/bin/bash`,login:false, offline dependencies, credential stripping and a rejecting
proxy. Final normal rejected2 attempted external requests; all final gates
forwarded0 requests. Final race/native/vet attempted0 external requests.

REDs and intermediate failures are retained, including absent adapter/API,
root/lease/callback binding, actual Assembly reuse, actual Run release,
whitespace-incomplete owner, raw test initialization and changed legacy-root
expectation, and broad failure chains caused by a retained Active Home. The old
full attempt ended24.724s; it did not time out or get interrupted. Draft passing
normal/race with the removed early-listener defer are retained but do not qualify
the final source. Pre-copy and pre-defer-removal source snapshots/hashes are
included to distinguish those draft bytes.

## Remaining boundary

Task1b exact historical shared-codec/C2 source action authorization is entirely
unimplemented here. Task2 terminal subject projection, resident legacy recall/
explicit memory-tool pre-Home source qualification, selected-noBML LIFE denial,
and loaded/pinned revision reporting are also unimplemented. The prepared backend
is not a C2 eligibility grant. Actual DIVA no-BML admission is not claimed safe or
accepted. Current legacy private/unknown memory tool and ContextHost laundering
seams remain open until the later authorized increment.
