// Package app is the composition root of the vivy process. It owns the
// startup order (storage -> providers -> runtime -> JSON-RPC control plane), restart
// recovery of non-terminal runs before the server listens (E2), and the
// reverse shutdown order with a bounded grace period.
//
// The config is fully validated before New is called; app never re-reads
// files for non-secret settings (config boundary, FR-10). Provider keys
// live in the user workspace settings.yaml or a frozen ENV session and
// are resolved per call. A missing key no longer aborts startup.
package app

import (
	"context"
	"crypto/subtle"
	"encoding/json"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"path/filepath"
	"reflect"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"agent-vivy/internal/actionhost"
	"agent-vivy/internal/app/settings"
	"agent-vivy/internal/bundlecontract"
	"agent-vivy/internal/bundles"
	"agent-vivy/internal/channelhost"
	"agent-vivy/internal/cognitivecontract"
	"agent-vivy/internal/config"
	"agent-vivy/internal/domain"
	"agent-vivy/internal/eval"
	"agent-vivy/internal/events"
	genassembly "agent-vivy/internal/generated/assembly"
	"agent-vivy/internal/generated/presentation"
	"agent-vivy/internal/i18n"
	"agent-vivy/internal/logging"
	"agent-vivy/internal/modelhost"
	checkpointmodule "agent-vivy/internal/modules/checkpoint"
	credentialmodule "agent-vivy/internal/modules/credential"
	divacognitive "agent-vivy/internal/modules/diva-cognitive"
	loopmodule "agent-vivy/internal/modules/loop"
	maskmodule "agent-vivy/internal/modules/masks"
	memorymodule "agent-vivy/internal/modules/memory"
	modelmodule "agent-vivy/internal/modules/model"
	notebookmodule "agent-vivy/internal/modules/notebook"
	sandboxmodule "agent-vivy/internal/modules/sandbox"
	storagemodule "agent-vivy/internal/modules/storage"
	"agent-vivy/internal/observerhost"
	"agent-vivy/internal/provider"
	controlrpc "agent-vivy/internal/rpc"
	"agent-vivy/internal/runtime"
	"agent-vivy/internal/storage"
	"agent-vivy/internal/studio"
	"agent-vivy/internal/toolkitcontract"
	"agent-vivy/internal/tools"
	"agent-vivy/sdk/generation"
	"agent-vivy/sdk/module"
	actionport "agent-vivy/sdk/port/controlaction"
	"agent-vivy/sdk/port/providerprofile"
	toolworldport "agent-vivy/sdk/port/toolworld"
	"agent-vivy/ui"
	laputaevolution "github.com/ProjectViVy/laputa/laputa/evolution"
)

// shutdownGrace bounds the whole graceful shutdown window. It stays under
// the ~5s Windows CTRL_CLOSE window: a console close lets the signal
// handler run before the OS terminates the process, so the drain, the
// HTTP shutdown and the storage close must all fit inside (E4).
const shutdownGrace = 5 * time.Second

// App is the composed process.
type App struct {
	cfg    config.Config
	logger *slog.Logger

	service      *runtime.Service
	toolkits     *bundles.Manager
	channels     *channelhost.Host
	actionHost   *actionhost.Host
	observerHost *observerhost.Host
	cognitive    cognitivecontract.Bundle
	memory       *memorymodule.Service
	backend      storage.Engine
	worker       *workerManager
	resolver     *ModelResolver
	modelHost    *modelhost.Host

	control     controlrpc.Handler
	httpServer  *http.Server
	rpcToken    string
	mcpBackend  *runtime.MCPBackend
	assembly    *genassembly.RuntimeAssembly
	diagnostics *logging.Diagnostics
	closeOnce   sync.Once
	closeDone   chan struct{}
	closeStage  atomic.Value // string: component currently tearing down
	closeErr    error

	// closeHook runs at the start of teardown while the close stage is
	// "automatic work". Test seam: lets deadline tests hold the teardown open.
	closeHook func()
}

// AppOption tweaks one composition of the process. The zero value is the
// default gateway assembly.
type AppOption func(*appOptions)

type appOptions struct {
	mainConversation cognitivecontract.MainConversationResolver
	subjectSources   cognitivecontract.SubjectSourceResolver

	channels bool
	gateway  bool
	sink     runtime.EventSink
	// cognitiveCaptureReceiptHook is an internal crash-test seam. It runs
	// after a durable capture receipt and before ObserverHost receives its ACK.
	cognitiveCaptureReceiptHook func(runtime.CognitiveCaptureReceipt)
	// cognitiveCaptureSinkWrapper is an internal crash-test seam for pausing
	// immediately before the durable Capture boundary.
	cognitiveCaptureSinkWrapper func(runtime.CognitiveCaptureSink) runtime.CognitiveCaptureSink
	// cognitiveDomainWrapper is a nil-by-default internal crash-test seam for
	// pausing after a durable effect receipt and before its caller receives it.
	cognitiveDomainWrapper func(laputaevolution.Domain) laputaevolution.Domain
	// cognitiveSnapshotStoreWrapper is a nil-by-default internal crash-test
	// seam for pausing before the processed-through watermark is persisted.
	cognitiveSnapshotStoreWrapper func(storage.SnapshotStore) storage.SnapshotStore
	settingsPath                  string
	// projectRoot is deliberately opt-in. Runtime.WorkspaceRoot is the
	// tenant/sandbox workspace for ordinary Vivy processes, not necessarily
	// the code project root from which a face may resolve attachments.
	projectRoot string
	// instructionRoot is the launch directory scanned for AGENTS.md and
	// conventional skill packages. It is independent of projectRoot so the
	// web sandbox can inject project instructions without exposing @file.
	instructionRoot string
	// contextSourceTimeout is a test seam for instrumented integration runs;
	// production compositions retain ContextHost's own default.
	contextSourceTimeout time.Duration
}

// WithMainConversationResolver supplies the governed #66/headless singleton.
// It consumes no user-facing create or conversion option.
func WithMainConversationResolver(resolver cognitivecontract.MainConversationResolver) AppOption {
	return func(o *appOptions) { o.mainConversation = resolver }
}

// WithSubjectSources binds existing Host Policy/Grant checks for contribution-only
// personal sources. The callback is reevaluated for every admission.
func WithSubjectSources(resolver cognitivecontract.SubjectSourceResolver) AppOption {
	return func(o *appOptions) { o.subjectSources = resolver }
}

// WithoutEars composes the process with no channel Host: no partition, no
// run hook, no StartAll. The headless face is one terminal-bound turn and
// must never consume inbound channel traffic.
func WithoutEars() AppOption { return func(o *appOptions) { o.channels = false } }

// WithoutGateway composes the process with no HTTP gateway: no listener, no
// mux, no embedded UI, no browser origin policy (VIVY-FACE-PACK §7 — HTTP
// listening is faces/web's effect, not a kernel obligation). The control
// plane stays reachable in-process via DialControl, so a face can drive the
// same JSON-RPC methods as the web face. WithEventSink is the streaming
// path for such faces.
func WithoutGateway() AppOption { return func(o *appOptions) { o.gateway = false } }

// WithEventSink adds a second event sink next to the gateway bus. The
// headless face renders the run stream for stdout/stderr through it.
func WithEventSink(sink runtime.EventSink) AppOption {
	return func(o *appOptions) { o.sink = sink }
}

// WithSettingsPath points this process at a shared operator settings file
// while allowing its Journal and other runtime state to live elsewhere.
// This is used by independent code-face processes: provider/model/operator
// preferences are shared, but sessions, runs, approvals, and checkpoints are
// isolated in each process's own storage directory.
func WithSettingsPath(path string) AppOption {
	return func(o *appOptions) { o.settingsPath = path }
}

// WithCodeProjectRoot supplies the canonical project root owned by the
// vivy-code composition. It is kept separate from Runtime.WorkspaceRoot so
// ordinary Vivy/web compositions cannot accidentally expose a tenant
// workspace through the attachment resolver.
func WithCodeProjectRoot(path string) AppOption {
	return func(o *appOptions) { o.projectRoot = path }
}

// WithInstructionRoot supplies the launch directory whose AGENTS.md and
// .agents/.vivy skill packages are discovered and fed to the existing Eino
// agentsmd / skill middlewares. It does not change the file-tool world.
func WithInstructionRoot(path string) AppOption {
	return func(o *appOptions) { o.instructionRoot = path }
}

func withContextSourceTimeout(timeout time.Duration) AppOption {
	return func(o *appOptions) { o.contextSourceTimeout = timeout }
}

// developerPresentationLocale reads the development-only locale input from
// the launch root. A sealed Generation must depend solely on its embedded
// presentation settings and therefore never consult process or dotenv state.
func developerPresentationLocale(root string, sealed bool) (i18n.Locale, error) {
	if sealed {
		return "", nil
	}
	return i18n.DeveloperDefault(filepath.Join(root, ".env"))
}

// fanoutSink publishes one event to both the gateway bus and the extra
// face sink, preserving the synchronous persist order.
type fanoutSink struct {
	primary, extra runtime.EventSink
}

type assemblyHost string

func (host assemblyHost) ModuleID() string { return string(host) }

type assemblyHosts struct{}

func (assemblyHosts) ForModule(id string) module.Host { return assemblyHost(id) }

func (f fanoutSink) Publish(ev domain.RunEvent) {
	f.primary.Publish(ev)
	f.extra.Publish(ev)
}

// New builds the app from the default generated Assembly.
func New(ctx context.Context, cfg config.Config, opts ...AppOption) (*App, error) {
	return NewWithAssembly(ctx, cfg, genassembly.BuildDefault(), opts...)
}

// NewWithAssembly is the application composition boundary. General config
// syntax and policy errors are rejected by config.Load / config.Validate;
// generation-specific capability mismatches are rejected here before any
// runtime construction begins.
func NewWithAssembly(ctx context.Context, cfg config.Config, runtimeAssembly genassembly.RuntimeAssembly, opts ...AppOption) (*App, error) {
	logger := slog.Default()
	ao := appOptions{channels: true, gateway: true}
	for _, opt := range opts {
		opt(&ao)
	}
	if err := validateRuntimeAssemblyConfig(runtimeAssembly, cfg); err != nil {
		return nil, err
	}
	// Providers are not discovered, exposed, or constructed until every
	// generated Module has crossed Start and Ready. The deferred close above
	// rolls this back on every later composition failure.
	if err := runtimeAssembly.Start(ctx, assemblyHosts{}); err != nil {
		return nil, fmt.Errorf("app: start generated assembly: %w", err)
	}
	assemblyOwned := true
	defer func() {
		if assemblyOwned {
			shutdownCtx := context.WithoutCancel(ctx)
			_ = closeToolWorlds(shutdownCtx, runtimeAssembly.Worlds)
			_ = runtimeAssembly.Close(shutdownCtx)
		}
	}()
	if err := validateRuntimeAssembly(runtimeAssembly); err != nil {
		return nil, err
	}
	preToolMiddleware, err := generatedPreToolMiddleware(runtimeAssembly)
	if err != nil {
		return nil, err
	}
	developerLocale, err := developerPresentationLocale(ao.instructionRoot, presentation.SealedGeneration)
	if err != nil {
		return nil, fmt.Errorf("app: resolve developer locale: %w", err)
	}
	liveSettingsPath := ao.settingsPath
	if liveSettingsPath == "" {
		liveSettingsPath = settings.Path(cfg.DataDirectory())
	}
	// The vendor the configuration file names, captured before the settings
	// overlay: it is the "config default" the control plane reports, and the
	// settings document may override it for this process only.
	configVendor := cfg.Providers.Active
	// Operator-managed preferences (network search, execute ceiling, the
	// per-channel knobs) overlay the validated config. Provider keys are
	// NOT applied to the process environment; ModelResolver reads
	// settings.yaml / frozen ENV per call. The compiled plugin set is
	// registered first so the channels overlay can only name channels this
	// generation actually carries.
	cfg = applySettingsOverlayAt(ctx, logger, cfg, liveSettingsPath, compiledChannelNames(runtimeAssembly.Channels))
	if err := validateRuntimeAssemblyConfig(runtimeAssembly, cfg); err != nil {
		return nil, err
	}
	var originPolicy controlrpc.OriginPolicy
	if ao.gateway {
		policy, policyErr := controlrpc.NewOriginPolicy(cfg.Server.AllowedOrigins)
		if policyErr != nil {
			return nil, fmt.Errorf("app: configure browser origins: %w", policyErr)
		}
		originPolicy = policy
	}

	dataRoot := cfg.DataDirectory()
	if err := os.MkdirAll(dataRoot, 0o700); err != nil {
		return nil, fmt.Errorf("app: create data dir: %w", err)
	}

	backend, err := storagemodule.Open(ctx, cfg)
	if err != nil {
		return nil, err
	}

	workStore, ok := backend.(storage.WorkStore)
	if !ok {
		_ = backend.Close()
		return nil, errors.New("app: storage backend does not implement work store")
	}
	goalRunStore, ok := backend.(storage.GoalRunStore)
	if !ok {
		_ = backend.Close()
		return nil, errors.New("app: storage backend does not implement Goal run store")
	}
	primaryRunStore, ok := backend.(storage.PrimaryRunStore)
	if !ok {
		_ = backend.Close()
		return nil, errors.New("app: storage backend does not implement primary run store")
	}
	bundleStore, ok := backend.(storage.BundleStore)
	if !ok {
		_ = backend.Close()
		return nil, errors.New("app: storage backend does not implement toolkit store")
	}
	leaseOwner, ok := backend.(storage.OrganismLeaseOwner)
	if !ok || leaseOwner.OrganismLeaseOwner() == "" {
		_ = backend.Close()
		return nil, errors.New("app: storage backend does not expose organism lease ownership")
	}

	// The memory service is composition-owned: opened once after storage when
	// the Generation compiled the memory action module. Generated providers
	// receive copies bound to this exact service before dispatch.
	memoryOwned := false
	var memoryService *memorymodule.Service
	if assemblyHasModule(runtimeAssembly.Manifest.Modules, "vivy/memory-bml") {
		var err error
		memoryService, err = memorymodule.OpenOwned(ctx, cfg, leaseOwner.OrganismLeaseOwner())
		if err != nil {
			_ = backend.Close()
			return nil, fmt.Errorf("app: open memory service: %w", err)
		}
		memoryOwned = true
		defer func() {
			if memoryOwned {
				_ = memoryService.Close()
			}
		}()
		if err := bindMemoryProviders(&runtimeAssembly, memoryService); err != nil {
			_ = backend.Close()
			return nil, err
		}
	}

	// Provider metadata is part of the binary: there is no bundle directory,
	// no working-directory dependency, and nothing a running instance can be
	// pointed at (PROV-P1, decision D3). The embedded data is reconciled
	// against the sealed adapter set before anything can use it (D15).
	vendors, err := provider.LoadEmbedded()
	if err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: load embedded provider data: %w", err)
	}
	if err := provider.ReconcileAdapters(vendors, provider.AdapterFamilies()); err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: provider data does not match the sealed adapter set: %w", err)
	}
	catalog := provider.NewCatalog(vendors...)
	// The configured vendor must exist in the data that was just loaded. The
	// membership check lives here rather than in config.Validate because
	// internal/config cannot depend on the provider registry (PROV-P3).
	if _, ok := catalog.Vendor(cfg.Providers.Active); !ok {
		_ = backend.Close()
		return nil, fmt.Errorf("app: providers.active %q is not an embedded vendor; provider metadata is data now, "+
			"so name one of the embedded vendors", cfg.Providers.Active)
	}
	configDefault := resolveVendorSelectionBestEffort(catalog, configVendor)
	compiledProfiles := make([]providerprofile.Profile, 0, len(runtimeAssembly.ProviderProfiles))
	for _, profileProvider := range runtimeAssembly.ProviderProfiles {
		compiledProfiles = append(compiledProfiles, profileProvider.Definition())
	}
	// The wire catalog is the embedded data itself: the frontend holds no
	// provider data of its own (PROV-P4). Vendors the compiled Generation cannot
	// execute stay in the payload with executable:false, so a deferred protocol
	// is visible and not selectable rather than invisible.
	catalogVendors := catalog.Vendors()
	credentialResolver, err := credentialmodule.Compose(credentialmodule.CompileScopes(
		compiledProfiles,
		cfg.Channels,
	))
	if err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: construct Credential Resolver: %w", err)
	}
	modelProvider, err := modelmodule.Compose(compiledProfiles, provider.Capabilities())
	if err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: construct ModelHost: %w", err)
	}
	modelHost := modelProvider.Host()
	resolver := newModelResolverForProject(cfg, liveSettingsPath, ao.projectRoot, catalog, modelHost, credentialResolver)
	cur := resolver.Current()
	providerName := cur.Provider
	if providerName == "" {
		providerName = configDefault.Vendor
	}
	modelID := cur.Model
	if modelID == "" {
		modelID = configDefault.Model
	}
	chatModel := provider.NewResolvingChatModel(modelHost, catalog, resolver)
	loopDriver, err := loopmodule.Compose(runtime.NewEngineFactory(chatModel))
	if err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: construct LoopDriver: %w", err)
	}
	// CMP-2: optional cheaper compaction summary model, pinned to the
	// active provider's live spec (D9 single data source). Nil keeps the
	// main model as the summarizer. The value crosses into the engine as
	// the opaque runtime.SummaryModel seam (D-007: no direct eino import).
	var summaryModel runtime.SummaryModel
	if id := cfg.Runtime.Compaction.SummaryModel; id != "" {
		summaryModel = provider.NewOverrideModel(modelHost, catalog, resolver, id)
	}

	var workspaces runtime.WorkspaceAllocator
	var fileOps tools.FileOperations
	var fileBackend *runtime.EinoFilesystemBackend
	var fileRecorder tools.FileVersionRecorder
	var skillOps tools.SkillOperations
	var skillBackend *runtime.EinoSkillBackend
	var toolkitManager *bundles.Manager
	var todoOps tools.TodoOperations
	var searchOps tools.SearchOperations
	var httpOps tools.HTTPOperations
	var fetchOps tools.WebFetchOperations
	var downloadOps tools.DownloadOperations
	var mcpOps tools.MCPOperations
	var sequentialOps tools.SequentialThinkingOperations
	var commandOps tools.CommandOperations
	var workspaceManager *runtime.WorkspaceManager
	var sandboxManager *runtime.SandboxManager
	var sandboxProvider *sandboxmodule.Provider
	if cfg.Runtime.WorkspaceRoot != "" {
		sandboxProvider, err = sandboxmodule.ComposeWithSessionWorkspaces(cfg, backend, backend)
		if err != nil {
			_ = backend.Close()
			return nil, fmt.Errorf("app: compose Sandbox Backend: %w", err)
		}
		workspaceManager = sandboxProvider.Workspaces()
		sandboxManager = sandboxProvider.Sandbox()
		workspaces = workspaceManager
		fileBackend = sandboxProvider.Filesystem()
		fileOps = fileBackend
		fileRecorder = runtime.NewFileVersionRecorder(backend, nil)
		fileBackend.SetFileVersionRecorder(fileRecorder)
	}
	if cfg.Runtime.SkillsRoot != "" {
		built, err := runtime.NewEinoSkillBackend(cfg.Runtime.SkillsRoot, backend)
		if err != nil {
			_ = backend.Close()
			return nil, fmt.Errorf("app: build skills backend: %w", err)
		}
		skillBackend = built
		skillBackend.SetSessionWorkspaceLookup(backend)
		skillOps = built
	}
	// Toolkit Skills share the existing protected Skill tools while retaining
	// a read-only, late-bound owner over the captured Toolkit View.
	skillOps = runtime.NewBundleSkillOperations(skillOps, func() *bundles.Manager { return toolkitManager })
	var marketplace tools.SkillsMarketplace
	if skillBackend != nil {
		built, err := runtime.NewMarketplaceService(skillBackend, cfg.Runtime.SkillsMarketplaceURL)
		if err != nil {
			_ = backend.Close()
			return nil, fmt.Errorf("app: build skills marketplace: %w", err)
		}
		marketplace = built
	}
	todoBackend := runtime.NewEinoTodoBackend(backend, filepath.Join(dataRoot, "todos"))
	todoOps = todoBackend
	historyService := runtime.NewHistoryService(backend, backend)
	// The reference snapshot authority shares the history read path and the
	// atomic continuity seam; a backend without ContinuityStore leaves it
	// nil-continuity, which only disables model-side attach commits.
	continuityStore, _ := backend.(storage.ContinuityStore)
	referenceService := runtime.NewReferenceService(historyService, backend, backend, backend, continuityStore)
	referenceService.SetViewStores(backend, backend)
	historyService.SetReferenceLookup(referenceService.Lookup)
	// Deliverable presentation shares the WorkspaceManager's trusted run
	// root, the Journal and the T4 receipt seam; transfer snapshots live in
	// a dedicated scratch that startup purges and nothing else touches.
	var deliverableOps tools.DeliverableOperations
	var deliverableService *runtime.DeliverableService
	if workspaceManager != nil {
		scratch := filepath.Join(dataRoot, "transfers")
		if mkErr := os.MkdirAll(scratch, 0o700); mkErr != nil {
			_ = backend.Close()
			return nil, fmt.Errorf("app: create transfer scratch: %w", mkErr)
		}
		deliverableService, err = runtime.NewDeliverableService(workspaceManager, backend, backend, continuityStore, scratch)
		if err != nil {
			_ = backend.Close()
			return nil, fmt.Errorf("app: build deliverable service: %w", err)
		}
		deliverableService.SetViewStores(backend, backend)
		deliverableOps = deliverableService
	}
	searchService := runtime.NewNetworkSearchService(nil, nil)
	searchService.SetPreferredProvider(cfg.Tools.NetworkSearch.Provider)
	searchOps = searchService
	httpBackend := runtime.NewHTTPBackend(cfg.Runtime.HTTPAllowedHosts, cfg.Runtime.HTTPMaxResponseBytes, cfg.Runtime.HTTPTimeoutSeconds, sandboxManager)
	httpOps = httpBackend
	applyLiveHTTPSettings(httpBackend, liveSettingsPath, cfg)
	fetchOps = runtime.NewWebFetchBackend(cfg.Runtime.HTTPMaxResponseBytes, sandboxManager)
	if fileBackend != nil {
		downloadOps = runtime.NewDownloadBackend(fileBackend, sandboxManager)
	}
	var mcpBackend *runtime.MCPBackend
	if assemblyHasToolWorld(runtimeAssembly.Worlds, "mcp") {
		mcpBackend = runtime.NewMCPBackendWithOptions(mcpRuntimeConfigs(cfg.Runtime.MCPServers), nil, runtime.MCPBackendOptions{
			ProcessRoot: cfg.Runtime.WorkspaceRoot,
			Logger:      logger,
		})
	}
	mcpOwned := true
	defer func() {
		if mcpOwned && mcpBackend != nil {
			_ = mcpBackend.Close()
		}
	}()
	if mcpBackend != nil {
		mcpOps = mcpBackend
		// Replace the generated no-op MCP provider with the runtime bridge
		// before ToolWorld staging. The resulting provider is still discovered
		// by the sole ToolHost below; the compatibility MCP backend remains
		// control-plane-only.
		providers := append([]toolworldport.Provider(nil), runtimeAssembly.Worlds...)
		for index, provider := range providers {
			if provider != nil && provider.Definition().ID == "mcp" {
				providers[index] = mcpBackend.MCPToolWorldProvider()
			}
		}
		runtimeAssembly.Worlds = providers
	}
	sequentialOps = runtime.NewSequentialThinkingBackend()
	if sandboxProvider != nil {
		commandOps = sandboxProvider.Commands()
	}
	var worldLookup worldWorkspaceLookup
	if workspaceManager != nil {
		worldLookup = func(ctx context.Context) (string, error) {
			workspace, err := workspaceManager.Ensure(ctx, tools.RunIDFromContext(ctx))
			return workspace.Path, err
		}
	}
	if fileBackend != nil && len(runtimeAssembly.DiagnosticObservers) > 0 {
		fileBackend.SetWriteDiagnostics(generatedWriteDiagnostics{
			observers: runtimeAssembly.DiagnosticObservers,
			worldIDs:  runtimeAssembly.DiagnosticObserverWorldIDs,
			grants:    runtimeAssembly.ToolWorldGrants,
			lookup:    worldLookup,
			recorder:  fileRecorder,
		})
	}
	// The builtin registry is built once and re-resolved per engine build:
	// Resolve filters by the active name list (settings tools_enabled
	// overlay when written, config default otherwise).
	// The agent tool's ops are armed after the worker manager exists
	// (the manager needs the registered tool set; the ref defers the bind).
	agentOps := &agentToolRef{}
	workflowOps := &workflowToolRef{}
	replyMessageOps := &replyParentToolRef{}
	var cognitiveBundle cognitivecontract.Bundle
	var builtinRegistry *tools.Registry
	var registryMu sync.RWMutex
	var liveApplyMu sync.Mutex
	rebuildToolRegistry := func(providers []toolworldport.Provider) error {
		staged, stageErr := bindToolWorlds(ctx, providers, runtimeAssembly.ToolWorldGrants, worldLookup, fileRecorder)
		if stageErr != nil {
			return stageErr
		}
		next := tools.BuiltinWithChildInbox(nil, fileOps, skillOps, todoOps, searchOps, httpOps, mcpOps, sequentialOps, commandOps, fetchOps, downloadOps, agentOps, workflowOps, replyMessageOps, replyMessageOps).WithHistory(historyService).WithReferences(referenceService).WithDeliverables(deliverableOps)
		next = next.WithAdditional(staged...)
		for _, implementation := range divacognitive.NewRecapRuntimeTools(func() cognitivecontract.Bundle { return cognitiveBundle }) {
			for _, provider := range runtimeAssembly.Tools {
				if divacognitive.IsRecapToolProvider(provider) && provider.Definition().ID == implementation.Spec().Name {
					next = next.WithAdditional(implementation)
					break
				}
			}
		}
		var mcpCfgs []runtime.MCPServerConfig
		if s, err := settings.Load(liveSettingsPath); err == nil {
			mcpCfgs = liveMCPConfigs(cfg, s)
		} else {
			mcpCfgs = mcpRuntimeConfigs(cfg.Runtime.MCPServers)
		}
		next, stageErr = bindGeneratedTools(runtimeAssembly.Tools, next, resolveToolExposure(cfg.Tools, mcpCfgs), preToolMiddleware...)
		if stageErr != nil {
			return stageErr
		}
		registryMu.Lock()
		builtinRegistry = next
		registryMu.Unlock()
		return nil
	}
	if err := rebuildToolRegistry(runtimeAssembly.Worlds); err != nil {
		_ = backend.Close()
		return nil, err
	}
	appliedMCPConfigs := []runtime.MCPServerConfig(nil)
	if mcpBackend != nil {
		appliedMCPConfigs = mcpBackend.ConfiguredServers()
	}
	registryMu.Lock()
	appliedMCPConfigs = append([]runtime.MCPServerConfig(nil), appliedMCPConfigs...)
	registryMu.Unlock()
	// resolveActiveTools builds the live active surface plus its hidden
	// complement. It backs startup and every engine rebuild, so a
	// Settings-side active/hidden change lands without a process restart.
	// Generated ToolWorld tools stay appended to the active surface; only
	// builtins participate in the active/hidden split.
	resolveActiveTools := func() ([]tools.Tool, []tools.Tool, error) {
		registryMu.RLock()
		registry := builtinRegistry
		registryMu.RUnlock()
		if registry == nil {
			return nil, nil, errors.New("app: tool registry is unavailable")
		}
		enabled := cfg.Tools.Enabled
		if s, err := settings.Load(liveSettingsPath); err == nil && s.ToolsEnabled != nil {
			enabled = append([]string(nil), *s.ToolsEnabled...)
		}
		enabled = config.NormalizeLegacyToolSearch(enabled)
		// MCP capabilities are discovered from the live server, so a
		// settings/config selection may name a capability that disappears
		// when the server is replaced. Preserve the selected server intent,
		// drop retired projections, and include the replacement's current
		// projections before strict registry resolution. Static tool names
		// remain strict: an unknown non-MCP name is still an error.
		selectedMCPInstances := make(map[string]struct{})
		for _, name := range enabled {
			if instance, ok := mcpProjectedToolInstance(name); ok {
				selectedMCPInstances[instance] = struct{}{}
			}
		}
		filtered := make([]string, 0, len(enabled))
		for _, name := range enabled {
			if _, compiled := registry.Lookup(name); !compiled && (tools.IsAssemblyControlledTool(name) || name == "mcp_list_tools" || name == "mcp_call" || divacognitive.IsRecapTool(name)) {
				continue
			}
			if _, compiled := registry.Lookup(name); !compiled {
				if _, selected := mcpProjectedToolInstance(name); selected {
					continue
				}
			}
			filtered = append(filtered, name)
		}
		enabled = filtered
		if len(selectedMCPInstances) > 0 {
			selected := make(map[string]struct{}, len(enabled))
			for _, name := range enabled {
				selected[name] = struct{}{}
			}
			for _, spec := range registry.Specs() {
				instance, ok := mcpProjectedToolInstance(spec.Name)
				if !ok {
					continue
				}
				if _, wanted := selectedMCPInstances[instance]; !wanted {
					continue
				}
				if _, already := selected[spec.Name]; already {
					continue
				}
				enabled = append(enabled, spec.Name)
				selected[spec.Name] = struct{}{}
			}
		}
		resolved, err := registry.Resolve(enabled)
		if err != nil {
			return nil, nil, err
		}
		return resolved, registry.Except(enabled), nil
	}
	ts, hidden, err := resolveActiveTools()
	if err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: resolve tools: %w", err)
	}
	// The checkpoint bridge fail-closes on its engine version, so an
	// unknown build version aborts startup rather than suspend runs on
	// unverifiable checkpoints (C6).
	engineVersion := runtime.EinoEngineVersion()
	if engineVersion == "" {
		_ = backend.Close()
		return nil, errors.New("app: eino engine version unavailable; checkpoint store cannot be anchored")
	}
	checkpointProvider, err := checkpointmodule.Compose(backend.Blobs(), engineVersion)
	if err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: build checkpoint store: %w", err)
	}
	checkpoints := checkpointProvider.Store()
	policy := policyEngine(cfg)
	userHooks := scriptHooksForConfig(cfg, func(format string, args ...any) {
		logger.Warn("hook registered but not approved", "detail", fmt.Sprintf(format, args...))
	})
	bundleHooks := runtime.NewBundleHookDispatcher(bundleStore, runtime.BundleHookExecutionResolverFunc(
		func(ctx context.Context, view bundlecontract.View, record bundlecontract.ComponentRecord, workspaceRoot string) (string, string, error) {
			if toolkitManager == nil {
				return "", "", errors.New("toolkits: Hook execution owner is unavailable")
			}
			return toolkitManager.ResolveHookExecution(ctx, view, record, workspaceRoot)
		}), cfg.Governance.HookTimeout)
	orderedHooks := append([]runtime.ToolHook(nil), userHooks...)
	orderedHooks = append(orderedHooks, bundleHooks)
	hooks := runtime.NewToolHookChain(cfg.Governance.HookTimeout, orderedHooks...)
	// Resolve the effective context-compression policy against the model's
	// context window (settings overlay already folded into cfg at startup).
	modelWindow := 0
	if info, infoErr := catalog.ResolveModelInfo(ctx, providerName, modelID); infoErr == nil {
		modelWindow = info.ContextWindow
	}
	cmp := compactionPolicyFor(cfg, nil, modelWindow, modelID)
	agentsMDBackend, agentsMDFiles, err := projectInstructionBackends(logger, ao.instructionRoot, skillBackend, fileBackend, backend)
	if err != nil {
		_ = backend.Close()
		return nil, err
	}
	engineCfg := buildEngineConfig(cfg, skillBackend, agentsMDBackend, checkpoints, policy, hooks, &cmp, summaryModel, fileBackend)
	engineCfg.ContextHost, err = contextHostForAssembly(runtimeAssembly, mcpBackend, ao.contextSourceTimeout)
	if err != nil {
		_ = backend.Close()
		return nil, err
	}
	engineCfg.SkillSources, err = generatedSkillSources(runtimeAssembly)
	if err != nil {
		_ = backend.Close()
		return nil, err
	}
	engineCfg.SkillSources = append(engineCfg.SkillSources, runtime.NewBundleSkillSource())
	engineCfg.AgentsMDFiles = agentsMDFiles
	engineCfg.HiddenTools = hidden
	eng, err := loopDriver.Build(ctx, ts, engineCfg)
	if err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: build engine: %w", err)
	}

	bus := events.NewBus(cfg.Runtime.StreamBuffer)
	workBus := events.NewWorkBus(cfg.Runtime.StreamBuffer)
	svcSink := runtime.EventSink(bus)
	if ao.sink != nil {
		svcSink = fanoutSink{primary: bus, extra: ao.sink}
	}
	// The ChannelHost is constructed before the runtime service so it can
	// join the initial hook list. It receives only a Run callback — never
	// *runtime.Service — so plugins cannot reach the runtime and the
	// channelhost layer stays free of internal/runtime imports. The
	// channels envelope may only name compiled-in channel plugins, and
	// every generated Channel Provider must carry the focused v1 Channel ABI (FR-10).
	// The headless face composes with no ears (WithoutEars).
	var svc *runtime.Service
	toolkitManagerOwned := false
	defer func() {
		if toolkitManagerOwned && toolkitManager != nil {
			_ = toolkitManager.Close(context.Background())
		}
	}()
	var channelHost *channelhost.Host
	if ao.channels {
		channelPlugins, err := bindChannels(runtimeAssembly.Channels, runtimeAssembly.ChannelGrants, cfg.Channels)
		if err != nil {
			_ = backend.Close()
			return nil, err
		}
		channelHost = channelhost.New(channelhost.Deps{
			Journal:    backend,
			Messages:   backend,
			Sessions:   backend,
			Deliveries: backend,
			RunPrepared: func(ctx context.Context, sessionID domain.SessionID, text string, attachments []domain.Attachment, prov *domain.Provenance, prepare channelhost.PrepareRunFunc) (domain.RunID, error) {
				if svc == nil {
					return "", errors.New("app: runtime service is not wired")
				}
				// Channel inbound media (channel tier 2) rides the same
				// RunOptions.Attachments contract as the UI boundary. The
				// RPC path rejects images for a model without vision; the
				// channel path cannot bounce a platform message, so it
				// degrades visibly instead: attachments drop with a
				// warning and the text still runs.
				if len(attachments) > 0 {
					if info := svc.GetModelInfo(ctx); info.ContextWindow > 0 && !info.SupportsImages {
						channel := ""
						if prov != nil {
							channel = prov.Channel
						}
						logger.Warn("app: dropping channel image attachments; the active model does not support images",
							"session", string(sessionID), "channel", channel, "attachments", len(attachments))
						attachments = nil
					}
				}
				return svc.RunWithOptions(ctx, sessionID, text, runtime.RunOptions{
					Provenance: prov, Attachments: attachments, BeforeStart: prepare, HumanAdmission: true,
				})
			},
			Approvals: backend,
			Runs:      backend,
			DecideApproval: func(ctx context.Context, approvalID, decision, actor string) error {
				if svc == nil {
					return errors.New("app: runtime service is not wired")
				}
				return svc.DecideApprovalAsActor(ctx, approvalID, decision, "", actor)
			},
			Channels:    channelPlugins,
			Config:      cfg.Channels,
			Logger:      logger,
			Credentials: credentialResolver,
		})
	}
	runHooks := []runtime.RunHook{runtime.AuditHook{Sink: runtime.SlogAuditSink{Logger: logger}}}
	if channelHost != nil {
		runHooks = append(runHooks, channelHost)
	}
	generationID := runtimeGenerationID(runtimeAssembly)
	// DN-LC: the one cognitive owner binds through the same sealed accessor
	// pattern as the mask factory. A selected-but-unarmed binding fails the
	// composition; an omitted module changes nothing.
	cognitiveBundle, err = cognitiveBundleForAssembly(ctx, &runtimeAssembly, cfg, generationID, backend.Snapshot(), memoryService)
	if err != nil {
		_ = backend.Close()
		return nil, err
	}
	// N2: the optional notebook owner binds through the same sealed accessor
	// pattern. An omitted module leaves the action/tool inventories absent.
	notebookBundle, err := notebookBundleForAssembly(ctx, &runtimeAssembly, generationID, backend)
	if err != nil {
		_ = backend.Close()
		return nil, err
	}
	if notebookBundle != nil {
		notebookmodule.SetActive(notebookBundle)
	}
	// R0: the optional reports owner binds through the same sealed accessor
	// pattern; its admission bridge is attached once the Service exists.
	reportsBundle, err := reportsBundleForAssembly(ctx, &runtimeAssembly, generationID, notebookScopeResolver{engine: backend})
	if err != nil {
		_ = backend.Close()
		return nil, err
	}
	var cognitiveSubs []observerhost.RunSubscription
	if cognitiveBundle != nil {
		captureSink := cognitiveBundle.Sink()
		if ao.cognitiveCaptureSinkWrapper != nil {
			captureSink = ao.cognitiveCaptureSinkWrapper(captureSink)
		}
		cognitiveSubs = append(cognitiveSubs, runtime.CognitiveCaptureSubscription(backend, captureSink,
			func(receipt runtime.CognitiveCaptureReceipt) {
				if ao.cognitiveCaptureReceiptHook != nil {
					ao.cognitiveCaptureReceiptHook(receipt)
				}
				if svc != nil && receipt.Seq != 0 {
					_ = svc.NotifyCognitiveInput(context.Background(), receipt.Seq)
				}
			}, ingestExclusionPredicate(backend)))
	}
	runObserverHost, err := observerHostForAssembly(ctx, runtimeAssembly, backend, cognitiveSubs...)
	if err != nil {
		if cognitiveBundle != nil {
			_ = cognitiveBundle.Close()
		}
		_ = backend.Close()
		return nil, err
	}
	observerHostOwned := runObserverHost != nil
	if runObserverHost != nil {
		runHooks = append(runHooks, runObserverHost)
	}
	defer func() {
		if observerHostOwned && runObserverHost != nil {
			runObserverHost.Close()
		}
	}()
	// A sealed first-party composition must never silently downgrade to the
	// legacy sequential primary admission path. The headless default
	// composition carries its own declared identity in the generated Assembly
	// (HeadlessGenerationID), so every binary built from this repository —
	// dev, headless, or embedded — arms the same mask/admission contracts as
	// a packed build. Only a custom embedder Assembly without any identity
	// stays on the explicitly compatible path.
	sealed := presentation.SealedGeneration || generationID != ""
	maskService, err := maskManagerForAssembly(ctx, runtimeAssembly, backend, generationID, sealed)
	if err != nil {
		_ = backend.Close()
		return nil, err
	}
	admission, err := primaryAdmissionForComposition(backend, generationID, sealed)
	if err != nil {
		_ = backend.Close()
		return nil, err
	}
	maskFrame, maskFrameDigest := "", ""
	if maskService != nil {
		maskFrame, maskFrameDigest = maskService.PromptAssets()
	}
	var cognitiveBinding *runtime.CognitiveBinding
	if cognitiveBundle != nil {
		resolvedBinding, err := cognitiveBundle.ResolveBinding(ctx)
		if err != nil {
			_ = cognitiveBundle.Close()
			_ = backend.Close()
			return nil, fmt.Errorf("app: resolve cognitive binding: %w", err)
		}
		var cognitiveDomain laputaevolution.Domain = &lazyDomain{binding: resolvedBinding, bundle: cognitiveBundle}
		if ao.cognitiveDomainWrapper != nil {
			cognitiveDomain = ao.cognitiveDomainWrapper(cognitiveDomain)
		}
		var cognitiveStore storage.SnapshotStore = backend.Snapshot()
		if ao.cognitiveSnapshotStoreWrapper != nil {
			cognitiveStore = ao.cognitiveSnapshotStoreWrapper(cognitiveStore)
		}
		cognitiveBinding = &runtime.CognitiveBinding{
			Domain:   cognitiveDomain,
			Binding:  resolvedBinding,
			SourceID: cognitiveBundle.SourceID(),
			Source:   cognitiveBundle.Source(),
			Sink:     cognitiveBundle.Sink(),
			Store:    cognitiveStore,
			Mission:  cognitiveBundle.Mission(),
			Primary:  cognitiveBundle,
			Resolve:  cognitiveBundle.ResolveBinding,
			Policy:   cognitiveBundle.Policy(),
		}
	}
	svc = runtime.NewService(eng, providerName, modelID, runtime.ServiceDeps{
		MainConversation:      ao.mainConversation,
		SubjectSources:        ao.subjectSources,
		Journal:               backend,
		Work:                  workStore,
		WorkSink:              workBus,
		Runs:                  backend,
		Messages:              backend,
		GoalRuns:              goalRunStore,
		PrimaryRuns:           primaryRunStore,
		Approvals:             backend,
		Questions:             backend,
		ApprovalExpiration:    cfg.Tools.Approval.Expiration,
		ApprovalSettleTimeout: time.Duration(cfg.Runtime.Sandbox.Approval.TimeoutSeconds) * time.Second,
		ShellState:            backend.Blobs(),
		ToolEvidence:          backend.Blobs(),
		Budget: runtime.BudgetPolicy{
			MaxEvents: cfg.Runtime.MaxRunEvents, MaxModelCalls: cfg.Runtime.MaxModelCalls,
			MaxToolCalls: cfg.Runtime.MaxRunToolCalls, MaxRetries: cfg.Runtime.MaxRunRetries,
		},
		Workspaces:           workspaces,
		Sessions:             backend,
		PolicyDefaultProfile: domain.PolicyProfile(cfg.Governance.Profile),
		Hooks:                runHooks,
		Sink:                 svcSink,
		Compactions:          backend,
		Truncations:          backend,
		ExportDir:            filepath.Join(dataRoot, "exports"),
		// A backend without the atomic ContinuityStore seam leaves the dep
		// nil; continuity submissions then fail unavailable rather than
		// degrading to a non-atomic write (SC-D4).
		Continuity:      func() storage.ContinuityStore { c, _ := backend.(storage.ContinuityStore); return c }(),
		References:      referenceService,
		Deliverables:    deliverableService,
		Crons:           backend,
		Channels:        channelHost,
		Titles:          provider.NewChainTitler(provider.TitleCandidates(modelHost, catalog, resolver, chatModel, cfg.Runtime.SmallModel)...),
		Admission:       admission,
		Bundles:         bundleStore,
		MaskResolver:    maskService,
		MaskFrame:       maskFrame,
		MaskFrameDigest: maskFrameDigest,
		GenerationID:    generationID,
		Cognitive:       cognitiveBinding,
		Recap: func() cognitivecontract.RecapPort {
			if provider, ok := cognitiveBundle.(cognitivecontract.RecapProvider); ok {
				return provider.Recap()
			}
			return nil
		}(),
		RebuildEngine: func(ctx context.Context, ec runtime.EngineConfig) (*runtime.Engine, error) {
			live, hidden, err := resolveActiveTools()
			if err != nil {
				return nil, fmt.Errorf("app: resolve live tools: %w", err)
			}
			ec.HiddenTools = hidden
			return loopDriver.Build(ctx, live, ec)
		},
		CacheWarmingMode:          cfg.Runtime.CacheWarming,
		CacheWarmingMinSavingsUSD: cfg.Runtime.CacheWarmingMinSavingsUSD,
	})
	toolkitLimits := bundlecontract.DefaultLimits()
	toolkitOwnerCapabilities := toolkitcontract.Capabilities{Owners: map[bundlecontract.ComponentKind]bool{
		bundlecontract.Skill: assemblyHasModule(runtimeAssembly.Manifest.Modules, "vivy/skill-source"),
		bundlecontract.Mask:  maskService != nil,
		bundlecontract.Rule:  true,
		bundlecontract.Hook:  true,
		bundlecontract.MCP:   mcpBackend != nil,
	}}
	currentUserMCPConfigs := func(_ context.Context) ([]runtime.MCPServerConfig, error) {
		live, loadErr := settings.Load(liveSettingsPath)
		if loadErr != nil {
			return nil, loadErr
		}
		return liveMCPConfigs(cfg, live), nil
	}
	refreshToolkitMCPProjection := func(_ context.Context, configs []runtime.MCPServerConfig) error {
		if mcpBackend == nil {
			return nil
		}
		registryMu.RLock()
		previous := append([]runtime.MCPServerConfig(nil), appliedMCPConfigs...)
		registryMu.RUnlock()
		if sameMCPRuntimeConfigs(configs, previous) {
			return nil
		}
		mcpToolsAvailable := true
		if rebuildErr := rebuildToolRegistry(runtimeAssembly.Worlds); rebuildErr != nil {
			logger.Warn("Toolkit MCP tool registry rebuild failed; closing the MCP ToolWorld catalog", "err", rebuildErr)
			withoutMCP := make([]toolworldport.Provider, 0, len(runtimeAssembly.Worlds))
			for _, provider := range runtimeAssembly.Worlds {
				if provider != nil && provider.Definition().ID == "mcp" {
					continue
				}
				withoutMCP = append(withoutMCP, provider)
			}
			if fallbackErr := rebuildToolRegistry(withoutMCP); fallbackErr != nil {
				return fmt.Errorf("app: fail-closed Toolkit MCP tool registry rebuild: %w", fallbackErr)
			}
			mcpToolsAvailable = false
		}
		if mcpToolsAvailable {
			if contextHost, contextErr := contextHostForAssembly(runtimeAssembly, mcpBackend, ao.contextSourceTimeout); contextErr != nil {
				logger.Warn("Toolkit MCP context bridge unavailable", "err", contextErr)
				engineCfg.ContextHost = nil
			} else {
				engineCfg.ContextHost = contextHost
			}
		} else {
			engineCfg.ContextHost = nil
		}
		_, hidden, resolveErr := resolveActiveTools()
		if resolveErr != nil {
			return fmt.Errorf("app: resolve Toolkit MCP tools: %w", resolveErr)
		}
		engineCfg.HiddenTools = hidden
		if reloadErr := svc.ScheduleEngineReload(engineCfg); reloadErr != nil {
			return fmt.Errorf("app: reload Toolkit MCP tools: %w", reloadErr)
		}
		registryMu.Lock()
		appliedMCPConfigs = append([]runtime.MCPServerConfig(nil), configs...)
		registryMu.Unlock()
		return nil
	}
	toolkitManager, err = bundles.NewManager(bundles.Config{
		StateRoot: dataRoot, Limits: toolkitLimits,
		Capabilities: bundles.Capabilities{Owners: toolkitOwnerCapabilities.Owners, Limits: toolkitLimits},
		Gate:         toolkitDrainGate{service: func() *runtime.Service { return svc }},
		PrepareOwners: func(prepareCtx context.Context, view bundlecontract.View) (bundles.PreparedOwners, error) {
			owners, prepareErr := prepareToolkitMCPOwners(prepareCtx, view, bundleStore, mcpBackend, currentUserMCPConfigs,
				assemblyHasModule(runtimeAssembly.Manifest.Modules, "vivy/context-host"))
			if prepareErr != nil {
				return nil, prepareErr
			}
			if prepared, ok := owners.(*toolkitMCPPreparedOwners); ok {
				prepared.afterPublish = refreshToolkitMCPProjection
			}
			return owners, nil
		},
		MCPStatuses: func() []bundles.MCPRuntimeStatus {
			if mcpBackend == nil {
				return nil
			}
			statuses := mcpBackend.ServerStatuses()
			out := make([]bundles.MCPRuntimeStatus, 0, len(statuses))
			for _, status := range statuses {
				out = append(out, bundles.MCPRuntimeStatus{Name: status.Name, State: string(status.State), Initialized: status.Initialized, ToolCount: status.ToolCount})
			}
			return out
		},
		LeaseOwner: leaseOwner.OrganismLeaseOwner(),
	}, bundleStore)
	if err != nil {
		return nil, fmt.Errorf("app: create toolkit coordinator: %w", err)
	}
	toolkitManagerOwned = true
	if mcpBackend != nil {
		mcpBackend.SetToolkitMCPDiscoveryValidator(func(discoveryCtx context.Context, config runtime.MCPServerConfig) error {
			return validateToolkitMCPDiscovery(discoveryCtx, toolkitManager, bundleStore, config)
		})
	}
	if err := toolkitManager.Recover(ctx); err != nil {
		return nil, fmt.Errorf("app: recover toolkit catalog: %w", err)
	}
	if owner, ok := maskService.(interface {
		SetToolkitManager(maskmodule.ToolkitViewManager)
	}); ok {
		owner.SetToolkitManager(toolkitManager)
	}
	svc.SetToolkitRuntime(toolkitRuntimeBridge{manager: toolkitManager})
	if cognitiveBundle != nil {
		if err := cognitiveBundle.AttachRuntime(&cognitiveControlPort{svc: svc, bundle: cognitiveBundle}); err != nil {
			_ = cognitiveBundle.Close()
			_ = backend.Close()
			return nil, fmt.Errorf("app: attach cognitive runtime: %w", err)
		}
	}
	if reportsBundle != nil {
		reportsBundle.AttachAdmission(svc)
	}
	if err := bindCognitiveContextSources(runtimeAssembly, cognitiveBundle, backend); err != nil {
		if cognitiveBundle != nil {
			_ = cognitiveBundle.Close()
		}
		_ = backend.Close()
		return nil, err
	}
	svc.SetCatalog(catalog)
	workerManager := newWorkerManager(svc, backend)
	agentOps.arm(workerManager)
	workflowOps.arm(workerManager)
	replyMessageOps.arm(workerManager)

	liveProfile := domain.PolicyProfile(cfg.Governance.Profile)
	if !liveProfile.Valid() {
		liveProfile = domain.PolicyProfileDefault
	}

	// The action host is enabled only when the compiler emitted action
	// ProviderSets and the composition carries a proven identity — the
	// linker-embedded sealed manifest for a packed build, or the declared
	// HeadlessGenerationID for the default headless composition. An empty or
	// unverifiable inventory is a disabled capability, never an implicit
	// default-allow host.
	rpcToken := controlrpc.NewSessionToken()
	var actionHost *actionhost.Host
	actionHostOwned := false
	if len(runtimeAssembly.ActionSets) > 0 && generationID != "" {
		allowedTools := make(map[string]struct{}, len(ts))
		for _, candidate := range ts {
			if candidate != nil {
				allowedTools[candidate.Spec().Name] = struct{}{}
			}
		}
		authenticateAction := actionAuthenticate(string(rpcToken))
		authorizeAction := actionAuthorize(policy, liveProfile)
		authorizeAction = withNotebookHumanOrigin(authorizeAction, policy, liveProfile)
		authorizeAction = withToolkitHumanOrigin(authorizeAction, policy, liveProfile)
		authorizeBridge := func(ctx context.Context, identity actionhost.Identity, request actionhost.BridgeRequest) error {
			if identity.SessionID == "" {
				return actionport.ErrUnauthenticated
			}
			if request.Kind == actionhost.BridgeRun {
				if request.Run.SessionID != identity.SessionID {
					return actionport.ErrUnauthenticated
				}
			} else if request.Kind != actionhost.BridgeTool {
				return actionport.ErrAuthorizationUnavailable
			}
			return authorizeAction(ctx, identity, request.Action, request.Input)
		}
		var cognitiveProvider cognitivecontract.DispatcherProvider
		if cognitiveBundle != nil {
			provider, ok := cognitiveBundle.(cognitivecontract.DispatcherProvider)
			if !ok {
				_ = backend.Close()
				return nil, fmt.Errorf("app: cognitive bundle does not expose the action dispatcher")
			}
			cognitiveProvider = provider
		}
		actionHost, err = actionhost.New(actionhost.Deps{
			ProviderSets:        runtimeAssembly.ActionSets,
			MaskManager:         maskService,
			ToolkitManager:      toolkitManager,
			ToolkitCapabilities: toolkitOwnerCapabilities,
			Cognitive:           cognitiveProvider,
			Notebook:            notebookBundle,
			NotebookScopes:      notebookScopeResolver{engine: backend},
			Reports:             reportsBundle,
			ReportScopes:        reportScopeResolver{engine: backend},
			CognitiveSessionCheck: func(ctx context.Context, sessionID domain.SessionID) error {
				_, err := backend.GetSession(ctx, sessionID)
				return err
			},
			GenerationAvailable: true,
			GenerationID:        generationID,
			Audit:               actionhost.JournalAuditSink{Journal: backend, Logger: logger},
			Authenticate:        authenticateAction,
			Authorize:           authorizeAction,
			AuthorizeBridge:     authorizeBridge,
			AllowedTools:        allowedTools,
			StartRun: func(ctx context.Context, request actionport.RunRequest) (actionport.RunResult, error) {
				if svc == nil {
					return actionport.RunResult{}, actionport.ErrRunDenied
				}
				identity, ok := actionhost.IdentityFromContext(ctx)
				if !ok || identity.SessionID == "" || strings.TrimSpace(request.SessionID) != identity.SessionID {
					return actionport.RunResult{}, actionport.ErrUnauthenticated
				}
				id, runErr := svc.RunWithOptions(ctx, domain.SessionID(identity.SessionID), request.Text, runtime.RunOptions{HumanAdmission: true})
				if runErr != nil {
					return actionport.RunResult{}, actionport.ErrRunDenied
				}
				return actionport.RunResult{ID: string(id), Status: "accepted"}, nil
			},
			InvokeTool: func(ctx context.Context, id string, input json.RawMessage) (json.RawMessage, error) {
				if svc == nil {
					return nil, actionport.ErrToolDenied
				}
				identity, ok := actionhost.IdentityFromContext(ctx)
				if !ok || identity.SessionID == "" || identity.RunID == "" {
					return nil, actionport.ErrUnauthenticated
				}
				result, invokeErr := svc.InvokeActionTool(ctx, domain.SessionID(identity.SessionID), domain.RunID(identity.RunID), id, input)
				if invokeErr != nil {
					return nil, actionport.ErrToolDenied
				}
				return json.Marshal(result)
			},
		})
		if err != nil {
			_ = backend.Close()
			return nil, fmt.Errorf("app: build action host: %w", err)
		}
		actionHostOwned = true
	} else if len(runtimeAssembly.ActionSets) > 0 {
		logger.Warn("control actions disabled: sealed Generation identity unavailable")
	}
	defer func() {
		if actionHostOwned {
			_ = actionHost.CloseContext(context.Background())
		}
	}()

	liveSnap, err := policy.Snapshot(liveProfile)
	if err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: snapshot default policy: %w", err)
	}
	liveTools := make([]domain.ToolSpec, 0, len(ts))
	for _, tool := range ts {
		liveTools = append(liveTools, tool.Spec())
	}
	// appliedToolsEnabled tracks the active surface the running engine was
	// built with, so a settings save can detect an active/hidden change.
	appliedToolsEnabled := append([]string(nil), cfg.Tools.Enabled...)
	studioSvc := studio.NewService(backend)
	executable, exeErr := os.Executable()
	if exeErr != nil {
		executable = ""
	}
	evalRunner := eval.NewRunner(eval.Runner{
		Studio:     studioSvc,
		Executable: executable,
		EvalRoot:   filepath.Join(dataRoot, "evals"),
		Isolation: eval.Isolation{
			ProductionSQLite:    cfg.Storage.SQLite.Path,
			ProductionWorkspace: cfg.Runtime.WorkspaceRoot,
			ProductionListen:    cfg.Server.Addr,
		},
	})
	fileVersions, _ := backend.(storage.ModifiedFileStore)
	mcpCompiled := assemblyHasToolWorld(runtimeAssembly.Worlds, "mcp")
	contextCompiled := assemblyHasModule(runtimeAssembly.Manifest.Modules, "vivy/context-host")
	// OBS-05 (D5): bounded diagnostics over the owned runtime/gui log
	// families; the composition root chooses the file root, never the
	// caller. Close ordering sits with the other owned services in Close.
	diagnostics, diagErr := logging.NewDiagnostics(cfg.LogDirectory())
	if diagErr != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: diagnostics: %w", diagErr)
	}
	controlHandler, err := controlrpc.NewControlHandler(controlrpc.ControlDeps{
		Sessions: backend, Messages: backend, Runs: backend, Journal: backend, Work: workStore, WorkBus: workBus,
		Approvals: backend, Questions: backend, Reviews: backend, Todos: backend, Skills: skillOps, Bus: bus, Service: svc, History: historyService, References: referenceService, Deliverables: deliverableService,

		CodeModeAvailable: svc.FaceAvailable(domain.FaceCode),
		ActionHost:        actionHost,
		Marketplace:       marketplace,
		SkillRevisions:    backend,
		Compactions:       backend,
		Truncations:       backend,
		Crons:             backend, CronRunner: svc,
		Studio: studioSvc,
		Live: studio.LiveView{
			Provider:      providerName,
			PolicyProfile: liveProfile,
			PolicyHash:    liveSnap.Hash,
			Tools:         liveTools,
		},
		Eval:             evalRunner,
		Children:         workerManager,
		SettingsPath:     liveSettingsPath,
		GenerationLocale: presentation.DefaultLocale,
		DeveloperLocale:  developerLocale,
		SealedGeneration: presentation.SealedGeneration,
		ConfigProvider:   configDefault.Vendor,
		ConfigModel:      configDefault.Model,
		ConfigAdapter:    configDefault.Adapter,
		ProviderVendors:  catalogVendors,
		ProviderProfileStatuses: func() []modelhost.ProfileStatus {
			current := resolver.Current()
			// The ModelHost is keyed by the sealed adapter the live selection
			// speaks (PROV-P3).
			return modelHost.Statuses(current.Adapter, current.Ready)
		},
		RuntimeBaseURL:                  cur.BaseURL,
		ConfigNetworkSearchProvider:     cfg.Tools.NetworkSearch.Provider,
		ConfigExecuteMaxTimeoutSeconds:  cfg.Runtime.ExecuteMaxTimeoutSeconds,
		DefaultPermissionPreset:         defaultPermissionPreset(cfg),
		SandboxWorkspaceRoot:            cfg.Runtime.WorkspaceRoot,
		ExecuteAllowedCommands:          append([]string(nil), cfg.Runtime.ExecuteAllowedCommands...),
		ConfigSandboxDenyPrivateIPs:     cfg.Runtime.Sandbox.Network.DenyPrivateIPs,
		ConfigSandboxAllowedDomains:     append([]string(nil), cfg.Runtime.Sandbox.Network.AllowedDomains...),
		ConfigApprovalTimeoutSeconds:    cfg.Runtime.Sandbox.Approval.TimeoutSeconds,
		ConfigApprovalExpirationSeconds: int(cfg.Tools.Approval.Expiration / time.Second),
		ConfigHTTPAllowedHosts:          append([]string(nil), cfg.Runtime.HTTPAllowedHosts...),
		ConfigHTTPTimeoutSeconds:        cfg.Runtime.HTTPTimeoutSeconds,
		ConfigCompaction:                cmp,
		// Channel ears: the Host exposes the compiled-in set and the process
		// truth of the last StartAll; channel writes go through the settings
		// overlay and apply on the next restart (contract §11).
		Channels:       channelHost,
		ConfigChannels: cfg.Channels,
		// Settings→Tools surface: the full builtin catalog (active and
		// hidden) plus the effective config default active set.
		ToolCatalog:        builtinRegistry.Specs(),
		ConfigToolsEnabled: append([]string(nil), cfg.Tools.Enabled...),
		// Write-time env apply: a settings/providers save updates the
		// running process environment (base_url → VIVY_API_BASE, resolved
		// api_key → active bundle env_key) immediately; the startup overlay
		// replays the same document on the next launch.
		ApplySettingsEnv: func(s settings.Settings) { applySettingsEnv(logger, catalog, cfg, s) },
		TokenUsage:       backend,
		Diagnostics:      diagnostics,
		// /bug bundles land beside session exports (VCP C2).
		DiagnosticsBundleDir: filepath.Join(dataRoot, "exports"),
		// exports/read serves verified downloads from the same artifact root (VCP C3).
		ExportsDir:   filepath.Join(dataRoot, "exports"),
		FileVersions: fileVersions,
		// Model metadata rides the same provider catalog the runtime and
		// compaction use (D9: no separate data source). Resolve failures
		// mean unpriced/unknown, which the cost math reports as such.
		ModelMeta: func(ctx context.Context, providerName, modelID string) domain.ModelInfo {
			info, err := catalog.ResolveModelInfo(ctx, providerName, modelID)
			if err != nil {
				return domain.ModelInfo{}
			}
			return info
		},
		MCP:             mcpBackend,
		MCPCompiled:     &mcpCompiled,
		ContextCompiled: &contextCompiled,
		LanguageServers: buildLanguageServerStatusSource(runtimeAssembly.LanguageServerStatuses, backend, workspaceManager),
		WorkspaceFiles: func() controlrpc.WorkspaceFiles {
			if workspaceManager == nil {
				return nil
			}
			return runtime.NewWorkspaceFiles(workspaceManager, 0)
		}(),
		// Only vivy-code supplies this explicit seam. Runtime.WorkspaceRoot is
		// a tenant/sandbox setting for ordinary Vivy compositions and must not
		// implicitly become an attachment project root.
		ProjectRoot: ao.projectRoot,
		Frozen:      resolver.Frozen(),
		ToolCatalogLive: func() []domain.ToolSpec {
			registryMu.RLock()
			registry := builtinRegistry
			registryMu.RUnlock()
			if registry == nil {
				return nil
			}
			return registry.Specs()
		},
		OnSettingsChanged: func() {
			liveApplyMu.Lock()
			defer liveApplyMu.Unlock()
			resolver.Invalidate()
			live := resolver.Current()
			name := live.Provider
			id := live.Model
			if name == "" {
				name = configDefault.Vendor
			}
			if id == "" {
				id = configDefault.Model
			}
			svc.SetModel(name, id)
			applyLiveSandboxSettings(sandboxManager, liveSettingsPath, cfg)
			applyLiveHTTPSettings(httpBackend, liveSettingsPath, cfg)
			applyLiveApprovalWindow(svc, liveSettingsPath, cfg, logger)
			s, err := settings.Load(liveSettingsPath)
			if err != nil {
				logger.Warn("mcp overlay reload skipped", "err", err)
				return
			}
			mcpChanged := false
			if mcpBackend != nil {
				nextMCPConfigs := liveMCPConfigs(cfg, s)
				if toolkitManager != nil {
					handle, pinErr := toolkitManager.PinCurrent()
					if pinErr != nil {
						logger.Warn("toolkit MCP view pin failed", "err", pinErr)
						return
					}
					merged, mergeErr := mergeToolkitMCPConfigs(context.Background(), handle.View(), bundleStore,
						nextMCPConfigs, assemblyHasModule(runtimeAssembly.Manifest.Modules, "vivy/context-host"))
					handle.Release()
					if mergeErr != nil {
						logger.Warn("toolkit MCP settings merge failed", "err", mergeErr)
						return
					}
					nextMCPConfigs = merged
				}
				registryMu.RLock()
				previousMCPConfigs := append([]runtime.MCPServerConfig(nil), appliedMCPConfigs...)
				registryMu.RUnlock()
				mcpChanged = !sameMCPRuntimeConfigs(nextMCPConfigs, previousMCPConfigs)
				if mcpChanged {
					buildLatestMCPConfigs := func(drainCtx context.Context) ([]runtime.MCPServerConfig, error) {
						latestSettings, loadErr := settings.Load(liveSettingsPath)
						if loadErr != nil {
							return nil, loadErr
						}
						configs := liveMCPConfigs(cfg, latestSettings)
						if toolkitManager == nil {
							return configs, nil
						}
						handle, pinErr := toolkitManager.PinCurrent()
						if pinErr != nil {
							return nil, pinErr
						}
						defer handle.Release()
						return mergeToolkitMCPConfigs(drainCtx, handle.View(), bundleStore, configs,
							assemblyHasModule(runtimeAssembly.Manifest.Modules, "vivy/context-host"))
					}
					refreshMCPRegistry := func(currentMCPConfigs []runtime.MCPServerConfig) {
						registryMu.Lock()
						appliedMCPConfigs = append([]runtime.MCPServerConfig(nil), currentMCPConfigs...)
						registryMu.Unlock()
						if rebuildErr := rebuildToolRegistry(runtimeAssembly.Worlds); rebuildErr != nil {
							// A removed or replaced MCP instance must not remain in
							// the model catalog when discovery of its replacement
							// fails. Keep other generated worlds live, but fail closed
							// for MCP until the next successful settings rebuild.
							logger.Warn("MCP tool registry rebuild failed", "err", rebuildErr)
							withoutMCP := make([]toolworldport.Provider, 0, len(runtimeAssembly.Worlds))
							for _, provider := range runtimeAssembly.Worlds {
								if provider != nil && provider.Definition().ID == "mcp" {
									continue
								}
								withoutMCP = append(withoutMCP, provider)
							}
							if fallbackErr := rebuildToolRegistry(withoutMCP); fallbackErr != nil {
								logger.Warn("MCP tool registry fail-closed rebuild failed", "err", fallbackErr)
							}
						}
					}
					releaseSettingsMCPDrain, drainErr := replaceMCPServersWithDrain(svc, mcpBackend, buildLatestMCPConfigs, refreshMCPRegistry)
					if drainErr != nil {
						logger.Warn("MCP settings publication deferred", "err", drainErr)
						return
					}
					defer releaseSettingsMCPDrain()
				}
			}
			// Tools live-apply: an active/hidden change rebuilds the engine
			// so the next run binds the new surface (immediately when idle,
			// otherwise at the next idle run start).
			mergedTools := mergedToolsEnabled(cfg, s)
			registryMu.RLock()
			previousToolsEnabled := append([]string(nil), appliedToolsEnabled...)
			registryMu.RUnlock()
			toolsChanged := !sameStrings(mergedTools, previousToolsEnabled)
			if toolsChanged {
				registryMu.Lock()
				appliedToolsEnabled = mergedTools
				registryMu.Unlock()
			}
			// Compaction live-apply: rebuild the engine (reduction +
			// summarization middleware) only when the effective policy
			// changed. The rebuild lands immediately when idle, otherwise
			// at the next idle run start.
			modelInfo := svc.GetModelInfo(context.Background())
			cmp := compactionPolicyFor(cfg, s.Compaction, modelInfo.ContextWindow, modelInfo.ID)
			compactionChanged := !sameCompactionPolicy(svc.CompactionPolicy(), &cmp)
			if toolsChanged || mcpChanged || compactionChanged {
				reloadCfg := buildEngineConfig(cfg, skillBackend, agentsMDBackend, checkpoints, policy, hooks, &cmp, summaryModel, fileBackend)
				var reloadErr error
				reloadCfg.ContextHost, reloadErr = contextHostForAssembly(runtimeAssembly, mcpBackend, ao.contextSourceTimeout)
				if reloadErr != nil {
					logger.Warn("MCP context bridge reload skipped", "err", reloadErr)
					reloadCfg.ContextHost = nil
				}
				reloadCfg.SkillSources, reloadErr = generatedSkillSources(runtimeAssembly)
				if reloadErr != nil {
					logger.Warn("generated SkillSource reload skipped", "err", reloadErr)
					reloadCfg.SkillSources = nil
				}
				reloadCfg.AgentsMDFiles = agentsMDFiles
				if err := svc.ScheduleEngineReload(reloadCfg); err != nil {
					logger.Warn("engine reload failed", "err", err)
				}
			}
		},
	})
	if err != nil {
		_ = backend.Close()
		_ = diagnostics.Close()
		return nil, fmt.Errorf("app: build rpc control plane: %w", err)
	}
	// Restart recovery before the server listens (E2, FR-8): every
	// non-terminal run either re-registers on its pending approval or
	// closes with a definitive run.failed. A listing failure means the
	// storage truth is unreachable; startup aborts.
	if err := svc.Recover(ctx); err != nil {
		_ = backend.Close()
		return nil, fmt.Errorf("app: restart recovery: %w", err)
	}
	// Channel inbound retention (CH-C3-N1): chanin_* provenance events are
	// bounded operational records, pruned once per process start. A prune
	// failure never blocks startup — the next start retries it.
	if maint, ok := backend.(storage.ChannelMaintenanceStore); ok {
		if n, err := maint.PruneChannelInboundEvents(ctx, time.Now().Add(-storage.ChannelInboundRetention)); err != nil {
			logger.Warn("channel inbound event prune failed", "err", err)
		} else if n > 0 {
			logger.Info("channel inbound events pruned", "rows", n)
		}
	}
	// Start the channel ears before the server listens (C3). Unconfigured
	// and disabled channels are skipped; empty allow_from refuses Start
	// for that channel. A wiring failure here aborts startup. The headless
	// face has no ears.
	if channelHost != nil {
		if err := channelHost.StartAll(ctx); err != nil {
			_ = backend.Close()
			return nil, fmt.Errorf("app: start channels: %w", err)
		}
	}

	app := &App{
		cfg:          cfg,
		logger:       logger,
		service:      svc,
		toolkits:     toolkitManager,
		channels:     channelHost,
		actionHost:   actionHost,
		observerHost: runObserverHost,
		cognitive:    cognitiveBundle,
		backend:      backend,
		worker:       workerManager,
		resolver:     resolver,
		modelHost:    modelHost,
		control:      controlHandler,
		rpcToken:     rpcToken,
		mcpBackend:   mcpBackend,
		assembly:     &runtimeAssembly,
		diagnostics:  diagnostics,
		memory:       memoryService,
		closeDone:    make(chan struct{}),
	}
	if runObserverHost != nil {
		// Start only after every fallible composition and recovery step has
		// succeeded. Hooks invoked during Recover queue durable Run IDs, and
		// Start immediately wakes that backlog without racing error cleanup
		// that closes the storage backend.
		runObserverHost.Start(ctx)
	}
	mcpOwned = false
	actionHostOwned = false
	observerHostOwned = false
	assemblyOwned = false
	memoryOwned = false
	// The gateway is faces/web's effect: the mux, the embedded UI shell and
	// the loopback listener exist only in the gateway assembly (face-pack
	// §3). A gateway-less generation reaches the identical control plane
	// through DialControl instead.
	if !ao.gateway {
		toolkitManagerOwned = false
		return app, nil
	}

	mux := http.NewServeMux()
	mux.Handle("/rpc", controlrpc.WebSocketServer{Handler: controlHandler, Token: rpcToken, Origins: originPolicy})
	mux.HandleFunc("/rpc/bootstrap", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodGet {
			w.Header().Set("Allow", http.MethodGet)
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		if !originPolicy.Allows(r) {
			http.Error(w, "forbidden origin", http.StatusForbidden)
			return
		}
		originPolicy.ApplyCORS(w, r)
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("Content-Type", "application/json")
		_, _ = fmt.Fprintf(w, `{"protocol_version":%q,"websocket_path":"/rpc","token":%q}`, controlrpc.ProtocolVersion, rpcToken)
	})
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		_, _ = w.Write([]byte(`{"status":"ok","stage":"e2-recovery"}`))
	})
	// The default build serves the embedded UI; the vivy_headless build
	// supplies a 404 handler while retaining the same control plane.
	mux.Handle("/", ui.Handler())

	app.httpServer = &http.Server{
		Addr:              cfg.Server.Addr,
		Handler:           controlrpc.AccessLogMiddleware(logger, mux),
		ReadHeaderTimeout: 5 * time.Second,
	}
	toolkitManagerOwned = false
	return app, nil
}

// Close shuts down a gateway-less composition and is safe to call more than
// once. Resident gateway processes use Run, whose shutdown additionally owns
// the HTTP listener ordering.
func (a *App) Close() error {
	if a == nil {
		return nil
	}
	a.startClose()
	<-a.closeDone
	return a.closeErr
}

// CloseContext is Close with a caller deadline: on ctx expiry it reports
// which component is still unwinding instead of blocking, while teardown
// continues in the background and later Close calls still observe its
// completion. The teardown's internal shutdownGrace bound is unchanged.
func (a *App) CloseContext(ctx context.Context) error {
	if a == nil {
		return nil
	}
	a.startClose()
	select {
	case <-a.closeDone:
		return a.closeErr
	case <-ctx.Done():
		return fmt.Errorf("app: close timed out during %s: %w", a.currentCloseStage(), ctx.Err())
	}
}

// startClose spawns the teardown exactly once; every caller then waits on
// closeDone so a deadline-aware waiter can leave without stranding shutdown.
func (a *App) startClose() {
	a.closeOnce.Do(func() {
		if a.closeDone == nil {
			// Tests compose partial Apps by literal; keep the channel
			// lazily so every App value can Close.
			a.closeDone = make(chan struct{})
		}
		go func() {
			defer close(a.closeDone)
			shutdownCtx, cancel := context.WithTimeout(context.Background(), shutdownGrace)
			defer cancel()
			a.closeStage.Store("automatic work")
			if a.closeHook != nil {
				a.closeHook()
			}
			if a.service != nil {
				a.service.StopAutomaticWork()
			}
			if a.actionHost != nil {
				a.closeStage.Store("control action host")
				a.closeErr = errors.Join(a.closeErr, a.actionHost.Close())
			}
			if a.channels != nil {
				a.closeStage.Store("channels")
				a.channels.StopAll(shutdownCtx)
			}
			if a.service != nil {
				a.closeStage.Store("lifecycle services")
				a.service.StopInteractionSweeper()
				a.service.StopCronScheduler()
				// Cognitive admission stops before drains; in-flight workflow
				// runs stay durable and resume on the next open.
				a.service.StopCognitiveLoop()
				a.service.CancelAll()
			}
			if a.worker != nil {
				a.closeStage.Store("run worker")
				a.closeErr = errors.Join(a.closeErr, a.worker.Close(shutdownCtx))
			}
			if a.service != nil && !a.service.WaitIdle(shutdownCtx) {
				a.closeErr = errors.Join(a.closeErr, shutdownCtx.Err())
			}
			if a.observerHost != nil {
				a.closeStage.Store("run observer")
				a.observerHost.Close()
			}
			if a.toolkits != nil {
				a.closeStage.Store("toolkit coordinator")
				a.closeErr = errors.Join(a.closeErr, a.toolkits.Close(shutdownCtx))
			}
			// The owned Garden runtime outlives the Service and observer
			// admission paths but closes before the storage backend.
			if a.cognitive != nil {
				a.closeStage.Store("cognitive runtime")
				a.closeErr = errors.Join(a.closeErr, a.cognitive.Close())
			}
			if a.mcpBackend != nil {
				a.closeStage.Store("mcp backend")
				a.closeErr = errors.Join(a.closeErr, a.mcpBackend.Close())
			}
			if a.assembly != nil {
				a.closeStage.Store("assembly")
				a.closeErr = errors.Join(a.closeErr, closeToolWorlds(shutdownCtx, a.assembly.Worlds), a.assembly.Close(shutdownCtx))
			}
			a.closeStage.Store("memory")
			if a.memory != nil {
				a.closeErr = errors.Join(a.closeErr, a.memory.Close())
			}
			if a.diagnostics != nil {
				a.closeStage.Store("diagnostics")
				a.closeErr = errors.Join(a.closeErr, a.diagnostics.Close())
			}
			if a.backend != nil {
				a.closeStage.Store("storage backend")
				a.closeErr = errors.Join(a.closeErr, a.backend.Close())
			}
			a.closeStage.Store("done")
		}()
	})
}

func (a *App) currentCloseStage() string {
	if stage, ok := a.closeStage.Load().(string); ok {
		return stage
	}
	return "startup"
}

// ActionHost returns the process-owned typed Control Action host. Callers
// still need an authenticated Caller; this method does not expose provider
// registration or any arbitrary RPC route.
func (a *App) ActionHost() *actionhost.Host {
	if a == nil {
		return nil
	}
	return a.actionHost
}

func policyEngine(cfg config.Config) *runtime.PolicyEngine {
	definitions := make(map[domain.PolicyProfile]runtime.PolicyDefinition, len(cfg.Governance.Profiles))
	for name, profile := range cfg.Governance.Profiles {
		rules := make([]runtime.PolicyRule, 0, len(profile.Rules))
		for _, rule := range profile.Rules {
			rules = append(rules, runtime.PolicyRule{
				Tool: rule.Tool, Field: rule.Field, Equals: rule.Equals, Prefix: rule.Prefix,
				Decision: domain.PolicyDecision(rule.Decision), Reason: rule.Reason,
			})
		}
		definitions[domain.PolicyProfile(name)] = runtime.PolicyDefinition{
			Default: domain.PolicyDecision(profile.Default), Rules: rules,
		}
	}
	engine, err := runtime.NewPolicyEngine(definitions)
	if err != nil {
		// Config.Validate already rejects invalid policy definitions. Keep
		// composition fail-safe if a direct test bypasses that boundary.
		panic(fmt.Sprintf("app: invalid governance policy: %v", err))
	}
	return engine
}

// actionAuthenticate is the exact caller-authentication predicate the
// composed control plane installs on the action host: the caller must carry
// the process-owned RPC token and the serving peer must have stamped the
// trusted identity into the context. A caller-supplied identity field is
// never accepted.
func actionAuthenticate(rpcToken string) func(context.Context, actionhost.Caller) (actionhost.Identity, error) {
	return func(ctx context.Context, caller actionhost.Caller) (actionhost.Identity, error) {
		if caller.Opaque() == "" || subtle.ConstantTimeCompare([]byte(caller.Opaque()), []byte(rpcToken)) != 1 {
			return actionhost.Identity{}, actionport.ErrUnauthenticated
		}
		identity, ok := actionhost.IdentityFromContext(ctx)
		if !ok {
			return actionhost.Identity{}, actionport.ErrUnauthenticated
		}
		return identity, nil
	}
}

// actionAuthorize is the exact authorization predicate the composed control
// plane installs: evaluate the declared action against the live governance
// profile; an approval-required effect in a composition without an approval
// continuation route fails closed, and only an explicit full-auto profile
// admits effectful actions.
func actionAuthorize(policy *runtime.PolicyEngine, liveProfile domain.PolicyProfile) func(context.Context, actionhost.Identity, actionport.Definition, json.RawMessage) error {
	return func(_ context.Context, _ actionhost.Identity, definition actionport.Definition, input json.RawMessage) error {
		if policy == nil {
			return actionport.ErrAuthorizationUnavailable
		}
		spec := actionToolSpec(definition)
		evaluation, evalErr := policy.Evaluate(liveProfile, spec, input)
		if evalErr != nil {
			return actionport.ErrAuthorizationUnavailable
		}
		if evaluation.Decision != domain.PolicyAllow {
			if evaluation.Decision == domain.PolicyPrompt || definition.RequiresApproval || definition.ApprovalRequired {
				return actionport.ErrApprovalRequired
			}
			return runtime.ErrPolicyDenied
		}
		if definition.RequiresApproval || definition.ApprovalRequired {
			return actionport.ErrApprovalRequired
		}
		return nil
	}
}

// withNotebookHumanOrigin is the narrow trusted-origin rule for direct
// authenticated notebook edits (N2): a human control-plane caller (no bound
// Run) may mutate the notebook under the profile default without a full-auto
// profile or approval ceremony. Explicit policy rules — deny or prompt —
// remain decisive; agent-bound invocations (identity.RunID) keep frozen-run
// policy. The exemption names the owner so no other action inherits it.
func withNotebookHumanOrigin(next func(context.Context, actionhost.Identity, actionport.Definition, json.RawMessage) error, policy *runtime.PolicyEngine, liveProfile domain.PolicyProfile) func(context.Context, actionhost.Identity, actionport.Definition, json.RawMessage) error {
	return func(ctx context.Context, identity actionhost.Identity, definition actionport.Definition, input json.RawMessage) error {
		if err := next(ctx, identity, definition, input); err != nil {
			if errors.Is(err, actionport.ErrApprovalRequired) && identity.ID != "" && identity.RunID == "" && definition.Owner == "vivy/notebook-core" {
				if policy == nil {
					return err
				}
				evaluation, evalErr := policy.Evaluate(liveProfile, actionToolSpec(definition), input)
				if evalErr == nil && evaluation.Decision == domain.PolicyPrompt && !evaluation.Matched {
					return nil
				}
			}
			return err
		}
		return nil
	}
}

// withToolkitHumanOrigin admits direct, session-bound Toolkit management
// actions under the default profile. The UI has its own explicit prepare,
// review, and publish steps, while ActionHost has no approval continuation
// route for a direct control-plane call. Only the profile's default prompt is
// relaxed; agent-bound calls, missing identities/sessions, explicit policy
// rules, and provider approval requirements remain denied.
func withToolkitHumanOrigin(next func(context.Context, actionhost.Identity, actionport.Definition, json.RawMessage) error, policy *runtime.PolicyEngine, liveProfile domain.PolicyProfile) func(context.Context, actionhost.Identity, actionport.Definition, json.RawMessage) error {
	return func(ctx context.Context, identity actionhost.Identity, definition actionport.Definition, input json.RawMessage) error {
		if err := next(ctx, identity, definition, input); err != nil {
			if errors.Is(err, actionport.ErrApprovalRequired) &&
				identity.ID != "" && identity.SessionID != "" && identity.RunID == "" &&
				definition.Owner == "vivy/toolkits" &&
				!definition.RequiresApproval && !definition.ApprovalRequired {
				if policy == nil {
					return err
				}
				evaluation, evalErr := policy.Evaluate(liveProfile, actionToolSpec(definition), input)
				if evalErr == nil && evaluation.Decision == domain.PolicyPrompt && !evaluation.Matched {
					return nil
				}
			}
			return err
		}
		return nil
	}
}

func actionToolSpec(definition actionport.Definition) domain.ToolSpec {
	return domain.ToolSpec{
		Name:        definition.ID,
		Description: definition.Description,
		Readonly:    definition.Effect == actionport.EffectRead,
	}
}

// runtimeGenerationID resolves the composition identity: the generated
// Assembly's declared identity first (the headless default composition
// declares HeadlessGenerationID in its generated artifact), then the
// linker-embedded sealed manifest used by packed binaries. It intentionally
// never invents an ID from mutable runtime state; an Assembly without either
// source stays unidentified and its capability seams stay dormant.
func runtimeGenerationID(runtimeAssembly genassembly.RuntimeAssembly) string {
	if id := strings.TrimSpace(runtimeAssembly.GenerationID); id != "" {
		return id
	}
	raw, err := generation.EmbeddedManifest()
	if err != nil {
		return ""
	}
	id, _, err := generation.InspectManifestProvenance(raw)
	if err != nil {
		return ""
	}
	return strings.TrimSpace(id)
}

// applySettingsEnv applies the non-secret base URL and the active selection's
// api_key overlay to the process environment. It is shared between the startup
// overlay (next-launch semantics) and the write-time path, so a settings save
// updates the environment immediately AND the next start replays the same
// document. Secret values are never logged.
//
// The credential variable is the *vendor's*, read from the embedded data: a
// selection that resolves to a third-party endpoint writes that vendor's
// environment variable instead of one of the three former config blocks.
func applySettingsEnv(logger *slog.Logger, catalog *provider.Catalog, cfg config.Config, s settings.Settings) {
	if s.BaseURL != "" {
		if err := os.Setenv(provider.APIBaseEnvVar, s.BaseURL); err != nil {
			logger.Warn("settings base_url not applied", "err", err)
		}
	}
	selection, ok := resolveStoredSelection(catalog, cfg, s)
	if !ok || selection.Vendor == "" {
		return
	}
	vendor, ok := catalog.Vendor(selection.Vendor)
	if !ok {
		return
	}
	if key := resolveSettingsAPIKey(s, selection); key != "" {
		if err := os.Setenv(vendor.EnvKey, key); err != nil {
			logger.Warn("settings api_key not applied", "err", err)
		}
	}
}

// applySettingsOverlay reads the operator-managed settings document and
// overlays non-secret preferences onto cfg. Provider keys stay in the
// settings document (or a frozen ENV session) and are resolved per call.
// compiledChannels holds the channel plugin names of this generation: the
// per-channel overlay may only name those, and stale overlay entries for
// channels that are no longer compiled-in are dropped (with a warning)
// instead of failing startup.
func applySettingsOverlay(ctx context.Context, logger *slog.Logger, cfg config.Config, compiledChannels []string) config.Config {
	return applySettingsOverlayAt(ctx, logger, cfg, settings.Path(cfg.DataDirectory()), compiledChannels)
}

func applySettingsOverlayAt(ctx context.Context, logger *slog.Logger, cfg config.Config, path string, compiledChannels []string) config.Config {
	cfg.Tools.Enabled = config.NormalizeLegacyToolSearch(cfg.Tools.Enabled)
	s, err := settings.Load(path)
	if err != nil {
		logger.Warn("settings overlay skipped", "path", path, "err", err)
		return cfg
	}
	if s.IsZero() {
		return cfg
	}
	if s.Provider != "" {
		// A pre-migration document named a vendor: keep that vendor active so
		// an address-less selection still resolves to the endpoint it meant.
		// A document that already names an adapter leaves the configured vendor
		// in force (DESIGN.md §5): the adapter selects the endpoint variant.
		if legacy := settings.NormalizeProviderSelection(s.Provider).LegacyVendor; legacy != "" {
			cfg.Providers.Active = legacy
		}
	}
	if s.NetworkSearch.Provider != "" {
		cfg.Tools.NetworkSearch.Provider = s.NetworkSearch.Provider
	}
	if s.ExecuteMaxTimeoutSeconds > 0 {
		cfg.Runtime.ExecuteMaxTimeoutSeconds = s.ExecuteMaxTimeoutSeconds
	}
	if overlay := enabledMCPFromSettings(s); overlay != nil {
		cfg.Runtime.MCPServers = overlay
	}
	if s.ToolsEnabled != nil {
		cfg.Tools.Enabled = config.NormalizeLegacyToolSearch(*s.ToolsEnabled)
	}
	if s.Sandbox.DefaultPreset.ValidSwitch() {
		mode, policy, ok := s.Sandbox.DefaultPreset.Bundle()
		if ok {
			cfg.Runtime.Sandbox.DefaultMode = string(mode)
			cfg.Runtime.Sandbox.Approval.DefaultPolicy = string(policy)
		}
	}
	if s.Sandbox.Network.DenyPrivateIPs != nil {
		cfg.Runtime.Sandbox.Network.DenyPrivateIPs = *s.Sandbox.Network.DenyPrivateIPs
	}
	if s.Sandbox.Network.AllowedDomains != nil {
		cfg.Runtime.Sandbox.Network.AllowedDomains = append([]string(nil), s.Sandbox.Network.AllowedDomains...)
	}
	if s.Sandbox.ApprovalTimeoutSeconds != nil {
		cfg.Runtime.Sandbox.Approval.TimeoutSeconds = effectiveApprovalTimeoutSeconds(cfg, s.Sandbox.ApprovalTimeoutSeconds, logger)
	}
	cfg.Runtime.Compaction = mergedCompactionConfig(cfg.Runtime.Compaction, s.Compaction)
	if merged := mergedChannels(logger, cfg.Channels, s.Channels, compiledChannels); merged != nil {
		cfg.Channels = merged
	}
	logger.Info("settings overlay applied", "provider", cfg.Providers.Active, "model", s.DefaultModel, "network_search_provider", cfg.Tools.NetworkSearch.Provider, "execute_max_timeout_seconds", cfg.Runtime.ExecuteMaxTimeoutSeconds, "sandbox_preset", s.Sandbox.DefaultPreset, "approval_timeout_seconds", cfg.Runtime.Sandbox.Approval.TimeoutSeconds, "mcp_servers", len(cfg.Runtime.MCPServers), "compaction_enabled", cfg.Runtime.Compaction.Enabled, "channels_overlayed", len(s.Channels))
	return cfg
}

// effectiveApprovalTimeoutSeconds resolves the human review window
// (runtime.sandbox.approval.timeout_seconds) from the config default plus the
// optional settings overlay. An overlay that is not shorter than the hard
// tools.approval.expiration cannot shorten review, so it is ignored with a
// warning rather than silently ignored by the deadline clamp. The startup
// overlay and the live reload share this rule.
func effectiveApprovalTimeoutSeconds(cfg config.Config, overlay *int, logger *slog.Logger) int {
	base := cfg.Runtime.Sandbox.Approval.TimeoutSeconds
	if overlay == nil || *overlay < 0 {
		return base
	}
	if cfg.Tools.Approval.Expiration > 0 && time.Duration(*overlay)*time.Second >= cfg.Tools.Approval.Expiration {
		logger.Warn("sandbox approval timeout overlay ignored", "seconds", *overlay, "expiration", cfg.Tools.Approval.Expiration.String())
		return base
	}
	return *overlay
}

// mergedChannels overlays the settings.yaml per-channel entries onto the
// config.yaml channels envelopes. Each entry replaces only the fields it
// carries (pointer semantics); the config envelope's opaque per-plugin
// Settings yaml.Node always survives. An entry for a compiled-in channel
// that config.yaml has no envelope for starts a fresh envelope — that is
// how the UI configures a channel this generation without touching
// config.yaml. Entries naming channels that are not compiled-in are
// dropped with a warning so a stale overlay can never fail startup. A nil
// result (no overlay entries) keeps the config envelopes untouched.
func mergedChannels(logger *slog.Logger, base config.Channels, overlays []settings.ChannelOverlay, compiled []string) config.Channels {
	if len(overlays) == 0 {
		return nil
	}
	compiledSet := make(map[string]bool, len(compiled))
	for _, name := range compiled {
		compiledSet[name] = true
	}
	out := make(config.Channels, len(base)+len(overlays))
	for name, envelope := range base {
		out[name] = envelope
	}
	for _, overlay := range overlays {
		if !compiledSet[overlay.Name] {
			logger.Warn("settings overlay names a channel that is not compiled in; entry dropped", "channel", overlay.Name)
			continue
		}
		envelope := out[overlay.Name]
		if overlay.Enabled != nil {
			envelope.Enabled = *overlay.Enabled
		}
		if overlay.AllowFrom != nil {
			envelope.AllowFrom = append([]string(nil), *overlay.AllowFrom...)
		}
		if overlay.TokenEnv != nil {
			envelope.TokenEnv = *overlay.TokenEnv
		}
		out[overlay.Name] = envelope
	}
	return out
}

// mergedToolsEnabled returns the effective active tool names: the settings
// tools_enabled overlay when written, else the (already startup-overlaid)
// config default. The result is a copy; order is preserved because the
// surface order is a product contract.
func mergedToolsEnabled(cfg config.Config, s settings.Settings) []string {
	if s.ToolsEnabled != nil {
		return config.NormalizeLegacyToolSearch(*s.ToolsEnabled)
	}
	return config.NormalizeLegacyToolSearch(cfg.Tools.Enabled)
}

func sameStrings(a, b []string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := range a {
		if a[i] != b[i] {
			return false
		}
	}
	return true
}

func sameMCPRuntimeConfigs(left, right []runtime.MCPServerConfig) bool {
	if len(left) != len(right) {
		return false
	}
	leftByName := make(map[string]runtime.MCPServerConfig, len(left))
	rightByName := make(map[string]runtime.MCPServerConfig, len(right))
	for _, config := range left {
		leftByName[config.Name] = config
	}
	for _, config := range right {
		rightByName[config.Name] = config
	}
	return reflect.DeepEqual(leftByName, rightByName)
}

func mcpProjectedToolInstance(name string) (string, bool) {
	parts := strings.SplitN(name, ".", 3)
	if len(parts) != 3 || parts[0] != "mcp" || parts[1] == "" || parts[2] == "" {
		return "", false
	}
	return parts[1], true
}

// enabledMCPFromSettings returns the MCP servers from the overlay, preserving
// disabled entries as inactive runtime instances. A nil overlay means the
// config-file catalog remains authoritative.
func enabledMCPFromSettings(s settings.Settings) []config.MCPServer {
	if s.MCPServers == nil {
		return nil
	}
	out := make([]config.MCPServer, 0, len(*s.MCPServers))
	for _, server := range *s.MCPServers {
		out = append(out, config.MCPServer{
			Name: server.Name, Endpoint: server.Endpoint, Command: server.Command,
			Args: append([]string(nil), server.Args...), EnvFrom: cloneMCPEnvFrom(server.EnvFrom),
			Cwd: server.Cwd, AuthEnv: server.AuthEnv, ResourceBridge: server.ResourceBridge,
			DeferredReason: server.DeferredReason, Enabled: cloneBoolPtr(server.Enabled),
			ToolExposure: cloneMCPToolExposure(server.ToolExposure),
		})
	}
	return out
}

func mcpRuntimeConfigs(servers []config.MCPServer) []runtime.MCPServerConfig {
	out := make([]runtime.MCPServerConfig, 0, len(servers))
	for _, server := range servers {
		out = append(out, runtime.MCPServerConfig{
			Name: server.Name, Endpoint: server.Endpoint, Command: server.Command,
			Args: append([]string(nil), server.Args...), EnvFrom: cloneMCPEnvFrom(server.EnvFrom),
			Cwd: server.Cwd, AuthEnv: server.AuthEnv, ResourceBridge: server.ResourceBridge,
			DeferredReason: server.DeferredReason, Enabled: cloneBoolPtr(server.Enabled),
			ToolExposure: cloneMCPToolExposure(server.ToolExposure),
		})
	}
	return out
}

func cloneBoolPtr(value *bool) *bool {
	if value == nil {
		return nil
	}
	copy := *value
	return &copy
}

func cloneMCPToolExposure(value map[string]string) map[string]string {
	if value == nil {
		return nil
	}
	out := make(map[string]string, len(value))
	for glob, level := range value {
		out[glob] = level
	}
	return out
}

func cloneMCPEnvFrom(value map[string]string) map[string]string {
	if value == nil {
		return nil
	}
	out := make(map[string]string, len(value))
	for child, host := range value {
		out[child] = host
	}
	return out
}

func liveMCPConfigs(cfg config.Config, s settings.Settings) []runtime.MCPServerConfig {
	if overlay := enabledMCPFromSettings(s); overlay != nil {
		return mcpRuntimeConfigs(overlay)
	}
	return mcpRuntimeConfigs(cfg.Runtime.MCPServers)
}

func defaultPermissionPreset(cfg config.Config) domain.PermissionPreset {
	mode := domain.SandboxMode(cfg.Runtime.Sandbox.DefaultMode)
	if !mode.Valid() {
		mode = domain.SandboxModeWorkspaceWrite
	}
	policy := domain.ApprovalPolicy(cfg.Runtime.Sandbox.Approval.DefaultPolicy)
	if !policy.Valid() {
		policy = domain.ApprovalPolicyAsk
	}
	return domain.PermissionPresetOf(mode, policy)
}

func applyLiveSandboxSettings(manager *runtime.SandboxManager, path string, cfg config.Config) {
	if manager == nil {
		return
	}
	s, err := settings.Load(path)
	if err != nil {
		return
	}
	if s.Sandbox.DefaultPreset.ValidSwitch() {
		mode, _, ok := s.Sandbox.DefaultPreset.Bundle()
		if ok {
			manager.SetDefaultMode(mode)
		}
	}
	denyPrivate := cfg.Runtime.Sandbox.Network.DenyPrivateIPs
	allowed := append([]string(nil), cfg.Runtime.Sandbox.Network.AllowedDomains...)
	if s.Sandbox.Network.DenyPrivateIPs != nil {
		denyPrivate = *s.Sandbox.Network.DenyPrivateIPs
	}
	if s.Sandbox.Network.AllowedDomains != nil {
		allowed = append([]string(nil), s.Sandbox.Network.AllowedDomains...)
	}
	manager.SetNetworkPolicy(domain.NetworkPolicy{AllowedDomains: allowed, DenyPrivateIPs: denyPrivate})
}

// applyLiveHTTPSettings merges the settings.yaml http overlay over the
// config defaults and live-applies the result to the running HTTP backend
// (allowlist + request timeout). The startup path replays the same document.
func applyLiveHTTPSettings(backend *runtime.HTTPBackend, path string, cfg config.Config) {
	if backend == nil {
		return
	}
	s, err := settings.Load(path)
	if err != nil {
		return
	}
	hosts := append([]string(nil), cfg.Runtime.HTTPAllowedHosts...)
	timeout := cfg.Runtime.HTTPTimeoutSeconds
	if s.HTTP != nil {
		if s.HTTP.AllowedHosts != nil {
			hosts = append([]string(nil), *s.HTTP.AllowedHosts...)
		}
		if s.HTTP.TimeoutSeconds != 0 {
			timeout = s.HTTP.TimeoutSeconds
		}
	}
	backend.SetConfig(hosts, timeout)
}

// applyLiveApprovalWindow replays the settings.yaml approval-timeout overlay
// over the config default and live-applies it, so the next approval honors
// the saved review window without a restart.
func applyLiveApprovalWindow(svc *runtime.Service, path string, cfg config.Config, logger *slog.Logger) {
	if svc == nil {
		return
	}
	s, err := settings.Load(path)
	if err != nil {
		return
	}
	svc.SetApprovalSettleTimeout(time.Duration(effectiveApprovalTimeoutSeconds(cfg, s.Sandbox.ApprovalTimeoutSeconds, logger)) * time.Second)
}

// Run blocks until ctx is cancelled or the server fails. On cancellation
// it shuts down components in reverse startup order with a bounded grace
// period and returns the shutdown error, if any. A gateway-less assembly
// has no listener: it blocks on ctx alone while faces drive the in-process
// control plane, then takes the same reverse-order shutdown.
func (a *App) Run(ctx context.Context) error {
	// Run also owns shutdown; early listener exits must release only its Home.
	defer func() {
		if a.memory != nil {
			_ = a.memory.Close()
		}
	}()
	a.service.StartInteractionSweeper(context.Background(), time.Second)
	defer a.service.StopInteractionSweeper()
	// Cron fires agent turns on a schedule; it must not outlive the
	// server loop and its in-flight watchers drain during shutdown below.
	if a.cfg.Runtime.Cron.Enabled {
		a.service.StartCronScheduler(context.Background(), runtime.CronSchedulerOptions{})
		defer a.service.StopCronScheduler()
	}
	// The cognitive wake loop delivers strategy wakeups for a bound
	// Cognitive service; unbound compositions are a no-op. Stop order:
	// admission stops before runs are cancelled below.
	a.service.StartCognitiveLoop(context.Background(), 0)
	defer a.service.StopCognitiveLoop()
	// The listener is faces/web's effect (VIVY-FACE-PACK §7); a
	// gateway-less assembly has no server error source to wait on.
	errCh := make(chan error, 1)
	if a.httpServer != nil {
		go func() {
			a.logger.Info("vivy starting", "addr", a.cfg.Server.Addr)
			if err := a.httpServer.ListenAndServe(); err != nil && !errors.Is(err, http.ErrServerClosed) {
				errCh <- fmt.Errorf("http server: %w", err)
			}
			close(errCh)
		}()
	}

	select {
	case err := <-errCh:
		if err == nil {
			return nil
		}
		return err
	case <-ctx.Done():
	}

	a.logger.Info("vivy shutting down")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), shutdownGrace)
	defer cancel()
	a.service.StopAutomaticWork()

	// Reverse startup order with hard ordering guarantees (E4): channels
	// stop first so an adapter's Stop never races a cancelled run's final
	// delivery; runs are then cancelled and drained while storage is still
	// open, so every run.cancelled terminal persists before the journal
	// closes; only then do the HTTP server and the backend shut down.
	a.service.StopInteractionSweeper()
	if a.channels != nil {
		a.channels.StopAll(shutdownCtx)
	}
	// Stop the armed timer before cancelling runs: any in-flight cron
	// terminal watcher still writes its state back while storage is open
	// (bounded by StopCronScheduler's drain window).
	a.service.StopCronScheduler()
	// Cognitive admission stops before in-flight workflow runs are
	// cancelled; their durable state resumes on the next boot.
	a.service.StopCognitiveLoop()
	a.service.CancelAll()
	if a.worker != nil {
		if err := a.worker.Close(shutdownCtx); err != nil {
			a.logger.Warn("child worker drain timed out", "err", err)
		}
	}
	if !a.service.WaitIdle(shutdownCtx) {
		a.logger.Warn("shutdown drain timed out; closing storage underneath live runs")
	}
	if a.observerHost != nil {
		a.observerHost.Close()
	}
	var toolkitCloseErr error
	if a.toolkits != nil {
		toolkitCloseErr = a.toolkits.Close(shutdownCtx)
	}
	var cognitiveCloseErr error
	if a.cognitive != nil {
		cognitiveCloseErr = a.cognitive.Close()
	}
	var mcpCloseDone chan error
	if a.mcpBackend != nil {
		mcpCloseDone = make(chan error, 1)
		go func() { mcpCloseDone <- a.mcpBackend.Close() }()
	}
	var httpCloseErr error
	if a.httpServer != nil {
		httpCloseErr = a.httpServer.Shutdown(shutdownCtx)
	}
	var mcpCloseErr error
	if mcpCloseDone != nil {
		select {
		case mcpCloseErr = <-mcpCloseDone:
		case <-shutdownCtx.Done():
			a.logger.Warn("MCP client shutdown timed out", "err", shutdownCtx.Err())
		}
	}
	var assemblyCloseErr error
	if a.assembly != nil {
		assemblyCloseErr = closeToolWorlds(shutdownCtx, a.assembly.Worlds)
	}
	if a.assembly != nil {
		assemblyCloseErr = errors.Join(assemblyCloseErr, a.assembly.Close(shutdownCtx))
	}
	var memoryCloseErr error
	if a.memory != nil {
		memoryCloseErr = a.memory.Close()
	}
	if memoryCloseErr != nil {
		return fmt.Errorf("close memory: %w", memoryCloseErr)
	}
	if httpCloseErr != nil {
		return fmt.Errorf("shutdown http server: %w", httpCloseErr)
	}
	if mcpCloseErr != nil {
		return fmt.Errorf("close MCP clients: %w", mcpCloseErr)
	}
	if assemblyCloseErr != nil {
		return fmt.Errorf("close generated assembly: %w", assemblyCloseErr)
	}
	if toolkitCloseErr != nil {
		return fmt.Errorf("close toolkit coordinator: %w", toolkitCloseErr)
	}
	if cognitiveCloseErr != nil {
		return fmt.Errorf("close cognitive runtime: %w", cognitiveCloseErr)
	}
	if err := a.backend.Close(); err != nil {
		return fmt.Errorf("close storage: %w", err)
	}
	return nil
}
