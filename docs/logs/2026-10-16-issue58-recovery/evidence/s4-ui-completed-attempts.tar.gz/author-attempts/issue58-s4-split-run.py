import os,subprocess,signal,time,urllib.request,json,tempfile
from pathlib import Path
work=Path('/workspace/scratch/5dda642e718d/agent-vivy-issue58-recovery')
processes=[];handles=[]
marker=Path(tempfile.mkdtemp(prefix="vivy-issue58-split-"))/"stop"
try:
 for name,cmd,extra in [
 ('backend',['/workspace/scratch/5dda642e718d/toolchain/go/bin/go','test','-p=1','./internal/app','-run','^TestIssue58RecapSplitFixture$','-count=1','-v','-timeout=2m'],{'VIVY_ISSUE58_SPLIT_TEST':'1','VIVY_ISSUE58_SPLIT_SECONDS':'60','VIVY_ISSUE58_SPLIT_STOP_FILE':str(marker)}),
 ('vite',['pnpm','--dir','ui','dev','--host','127.0.0.1'],{})]:
  out=open('/tmp/issue58-s4-split-combined-'+name+'.log','w');handles.append(out)
  env=dict(os.environ);env.update(extra)
  processes.append(subprocess.Popen(cmd,cwd=work,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True))
 ready={}
 deadline=time.monotonic()+70
 while time.monotonic()<deadline:
  for name,url in [('backend','http://127.0.0.1:8787/healthz'),('vite','http://127.0.0.1:3015/rpc/bootstrap')]:
   if name in ready:continue
   try:
    with urllib.request.urlopen(url,timeout=.5) as r:
     if r.status==200:ready[name]=True
   except Exception:pass
  if len(ready)==2:break
  if any(p.poll() is not None for p in processes):raise RuntimeError('split child exited before readiness')
  time.sleep(.2)
 if len(ready)!=2:raise RuntimeError('split readiness unavailable: '+str(ready))
 result=subprocess.run(['node','/tmp/issue58-s4-split-smoke.mjs'],cwd=work,timeout=30,capture_output=True,text=True)
 Path('/tmp/issue58-s4-split-combined-actions.log').write_text(result.stdout+result.stderr)
 if result.returncode:raise RuntimeError('actual split smoke failed, see action log')
 print(result.stdout,flush=True)
 marker.touch()
 # Let the bounded test shut down normally and release its actual owner.
 code=processes[0].wait(timeout=45)
 if code:raise RuntimeError('backend fixture failed '+str(code))
 print(json.dumps({'backend_fixture_exit':code,'split_readiness':ready,'browser_rendered':False}),flush=True)
finally:
 for p in reversed(processes):
  if p.poll() is None:
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
 for h in handles:h.close()
 if marker.exists():marker.unlink()
 marker.parent.rmdir()
