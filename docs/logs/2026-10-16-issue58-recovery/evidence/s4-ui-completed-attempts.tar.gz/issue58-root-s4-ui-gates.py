import subprocess,json,time,sys
from pathlib import Path
commands=[['pnpm','--dir','ui','test'],['pnpm','--dir','ui','typecheck'],['pnpm','--dir','ui','build'],['git','diff','--exit-code']]
results=[]
for cmd in commands:
 print(json.dumps(dict(phase='start',command=cmd)),flush=True);start=time.monotonic();p=subprocess.run(cmd);r=dict(command=cmd,exit_code=p.returncode,elapsed_seconds=round(time.monotonic()-start,3));results.append(r);print(json.dumps(dict(phase='end',**r)),flush=True)
 if p.returncode:break
Path('/tmp/issue58-root-s4-ui168-phases.json').write_text(json.dumps(results,indent=2)+'\n');sys.exit(results[-1]['exit_code'])
