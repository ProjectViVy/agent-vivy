# Native BML execution ledger

Scope: explicit root release for native BML producer only. No subagents, App/adapter/runtime/UI/dependency edits or tenant migrations. Root owns independent review, publication and consumer release.

Ruling: retain Record.Scope independently of exact logical OwnershipBinding; old unknown rows remain unbound. No implicit ProfileID/subject conversion.
Ruling (root accepted): reject canonical identity migration/rollback before writes if ownership OR retained operation history exists. Cost: future bound identity conversion requires an explicit reviewed migration; fixed Home machine identity is unaffected.
Ruling: use pinned native SQLite immediate transactions (driver.go/tx.go in v1.56.0 inspected) for cross-handle writer serialization; preserve existing busy/CAS behavior.
Ruling: preserve every raw attempt and the existing local-only runner; skill workspace deletion/general integration steps are superseded by explicit root evidence retention and source-freeze/review ownership.

Author source pass: checked exact binding, canonical fingerprint/CAS presence, same putInner transaction, old-row isolation, restore/schema failure and retained history boundaries. Independent root review remains pending.

Final scoped gates: native normal/race 155 tests +1 package each PASS; root MVS normal same155+1 PASS; native vet PASS. Actual Windows NOT RUN.

## Complete invocation ledger

- issue58-bml-baseline-schema-expectations: exit 1, 0.967s, {"package_fail": 1, "test_fail": 5, "test_pass": 123}; `go test -json -p=1 ./... -count=1 -timeout=4m`.
- issue58-bml-bound-api-red: exit 1, 0.164s, {"package_fail": 1}; `go test -json -p=1 ./... -run '^TestIssue58Bound' -count=1 -timeout=3m`.
- issue58-bml-bound-fences-red: exit 1, 1.069s, {"package_fail": 1, "test_fail": 5, "test_pass": 2}; `go test -json -p=1 ./... -run '^TestIssue58Bound(Deleted|Cannot|Distinct|Schema|Restore)' -count=1 -timeout=3m`.
- issue58-bml-bound-green: exit 0, 1.085s, {"package_pass": 1, "test_pass": 31}; `go test -json -p=1 ./... -run '^TestIssue58(Bound|Schema)' -count=1 -timeout=3m`.
- issue58-bml-bound-red: exit 1, 0.872s, {"package_fail": 1, "test_fail": 4, "test_pass": 12}; `go test -json -p=1 ./... -run '^TestIssue58Bound' -count=1 -timeout=3m`.
- issue58-bml-checkpoint-native-normal: exit 0, 1.424s, {"package_pass": 1, "test_pass": 155}; `go test -json -p=1 ./... -count=1 -timeout=4m`.
- issue58-bml-checkpoint-native-race: exit 0, 7.354s, {"package_pass": 1, "test_pass": 155}; `go test -json -race -p=1 ./... -count=1 -timeout=5m`.
- issue58-bml-checkpoint-root-normal: exit 0, 1.73s, {"package_pass": 1, "test_pass": 155}; `go test -json -mod=readonly -p=1 github.com/ProjectViVy/agent-vivy/bml -count=1 -timeout=4m`.
- issue58-bml-checkpoint-vet: exit 0, 0.265s, {}; `go vet -p=1 ./...`.
- issue58-bml-empty-enum-red: exit 1, 1.022s, {"package_fail": 1, "test_fail": 5, "test_pass": 6}; `go test -json -p=1 ./... -run '^TestIssue58Bound(RawEnums|HomeProjection)' -count=1 -timeout=3m`.
- issue58-bml-fences-green: exit 0, 0.972s, {"package_pass": 1, "test_pass": 13}; `go test -json -p=1 ./... -run '^TestIssue58Bound(Deleted|Cannot|Distinct|Schema|Restore|RawEnums)' -count=1 -timeout=3m`.
- issue58-bml-final-native-normal: exit 0, 1.626s, {"package_pass": 1, "test_pass": 154}; `go test -json -p=1 ./... -count=1 -timeout=4m`.
- issue58-bml-final-native-race: exit 0, 30.479s, {"package_pass": 1, "test_pass": 154}; `go test -json -race -p=1 ./... -count=1 -timeout=5m`.
- issue58-bml-maintenance-green: exit 0, 0.967s, {"package_pass": 1, "test_pass": 7}; `go test -json -p=1 ./... -run '^TestIssue58Bound(Backup|Identity|GC)' -count=1 -timeout=3m`.
- issue58-bml-maintenance-red: exit 1, 0.918s, {"package_fail": 1, "test_fail": 7}; `go test -json -p=1 ./... -run '^TestIssue58Bound(Backup|Identity|GC)' -count=1 -timeout=3m`.
- issue58-bml-native-module: exit 0, 0.008s, {}; `go list -m -json modernc.org/sqlite`.
- issue58-bml-native-normal: exit 0, 1.574s, {"package_pass": 1, "test_pass": 153}; `go test -json -p=1 ./... -count=1 -timeout=4m`.
- issue58-bml-native-vet: exit 0, 7.941s, {}; `go vet -p=1 ./...`.
- issue58-bml-raw-enum-red: exit 1, 1.022s, {"package_fail": 1, "test_fail": 6}; `go test -json -p=1 ./... -run '^TestIssue58BoundRawEnums' -count=1 -timeout=3m`.
- issue58-bml-readonly-restore-red: exit 1, 0.968s, {"package_fail": 1, "test_fail": 1}; `go test -json -p=1 ./... -run '^TestIssue58ReadOnlyHandle' -count=1 -timeout=3m`.
- issue58-bml-root-module: exit 0, 0.008s, {}; `go list -m -json modernc.org/sqlite`.
- issue58-bml-root-mvs-normal: exit 0, 1.809s, {"package_pass": 1, "test_pass": 154}; `go test -json -mod=readonly -p=1 github.com/ProjectViVy/agent-vivy/bml -count=1 -timeout=4m`.
- issue58-bml-schema-green: exit 0, 0.869s, {"package_pass": 1, "test_pass": 4}; `go test -json -p=1 -overlay=/tmp/issue58-bml-schema-overlay.json ./... -run '^TestIssue58Schema' -count=1 -timeout=3m`.
- issue58-bml-schema-red: exit 1, 0.032s, {"package_fail": 1}; `go test -json -p=1 ./... -run '^TestIssue58Schema' -count=1 -timeout=3m`.
- issue58-bml-schema-red2: exit 1, 15.216s, {"package_fail": 1, "test_fail": 3, "test_pass": 1}; `go test -json -p=1 -overlay=/tmp/issue58-bml-schema-overlay.json ./... -run '^TestIssue58Schema' -count=1 -timeout=3m`.
- issue58-bml-v1-shape-red: exit 1, 0.921s, {"package_fail": 1, "test_fail": 1}; `go test -json -p=1 ./... -run '^TestIssue58SchemaOneCannot' -count=1 -timeout=3m`.
