# SDD ledger — plan: docs/superpowers/plans/issue-58/S4.md

Base: 3e13019b0373d8f6344bb84469fd72598f4c11ab. Sole source writer released by root after normal/race Issue58 gates passed.

Pre-flight: Task 1 produces strict action outcomes consumed by Task 2. C1 aliases expose Go fields; management wire projects only revision/text/time/cause/coverage, with no receipt or binding claims.
Pre-flight: S3 runtime codec is private. S4 sources reports explicit unavailable until S5 supplies Service expansion. No historical inference or cloned decoder.
Ruling: use the authorized existing recovery workspace rather than creating another checkout. Root owns detached broad checks and review.
Ruling: oil-frontend is absent from repository and installed skill catalog; root explicitly directs existing UI AGENTS/kit/testing-vivy-ui workflow without pause.
Ruling: preserve S4 evidence directory rather than executing-plans cleanup; root explicitly requires report/log archival for integration review.

Task 1: in progress. Boundary tests catch absent management handlers, unauthorized owner reads, public receipt/cause injection, CAS retries, history truncation, and tool/action owner divergence.

Task 1: RED actions missing handlers; GREEN actual C1 multiline/CAS/idempotency/clear/restore/reconcile (3 tests). Runtime compile RED records missing private authorization. Real HTTP discovery RED exposed actmem_read to ordinary sessions; scoped official Eino delegation fixes catalog and final activation visibility.
Ruling: existing assembler has one provider collection constructor per Module. Add stateless T1 vivy/recap-tools with std/tool@v1, depending on existing cognitive owner and ToolHost, rather than widening generator/public contracts. No second owner or Active singleton.
Eino check: github.com/cloudwego/eino/adk/middlewares/dynamictool/toolsearch.Config (v0.9.20) accepts only static DynamicTools/UseModelToolSearch. Wrap its middleware and invocation using the current authorized subset, keeping official search implementation. Existing activation middleware remains authoritative for session schema exposure; a final authorization filter prevents saved activations granting access.
Strict text boundary: added RED proof for raw invalid UTF-8 and unpaired UTF-16 normalization in both action/tool paths, plus duplicate authority keys and required-null rejection. GREEN uses bounded flat-object validation before typed decoding. Valid Chinese, CRLF, supplementary pairs, replacement-character literals, escaped backslashes and slash preserve exact text.
Reporting RED: selected ContextStatus returned legacy zero tokens as estimated pressure. GREEN now explicitly declares shared measurement unavailable and reports actual committed revision; selected compact results mark token totals unavailable. UI consumers will honor these markers in Task 2.
S4 deferred integration RED: native tool_search bypassed ordinary toolAdapter receipts, so first run completed but C2 refused terminal seal and reopened next admission. Existing serviceToolOperationCoordinator now retains the actual native search result/error, with explicit original.captured metadata. Its verified full result is unframed only for native machine-JSON forward-selection. No seal assertion was weakened. Reopen test now requires a second actual HTTP request with authorized schema rehydrated after SQLite and C1 reopen.

Task 1: backend checkpoint 94bff8014525a22ed647b23453d3b57fb9115f12, tree 7678864b43badef22a603c38b2d67e67303003d2. Final focused 317 tests/subtests + 5 packages PASS; 1 opt-in fixture capture SKIP; zero fail or network forwarding. Root owns whole-candidate review/gates. Integration sources/loaded timing remain S5.
Task 2: in progress. UI consumes the exact C4 projection; tests must fail on absent full editor, dirty draft loss/automatic overwrite, hidden clear writes, incorrect restore base, untruthful source states and unmeasured tokens. Preserve BML and Persona review route.
