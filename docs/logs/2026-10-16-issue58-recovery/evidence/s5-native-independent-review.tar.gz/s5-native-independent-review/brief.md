# Independent S5 native C5 compatibility review

Prepared scope only; root will supply immutable candidate/clone after the author
commits and freezes. Do not begin review or builds until explicit assignment.
Independent reviewer GPT-6 Astra High. No subagents, GitHub mutation or source edits.
Root integrates and publishes; one consolidated author TDD pass follows findings,
then root reruns unchanged reviewer probes. No redundant second fix-diff review.

## Scope and baseline

Reviewed native owner pin bb57e93a61cfb41460524d00a557a3a9f2cce1e7 is retained.
Current main f44ba00eb6ab5aa6ab9a2f5c09868373e36679f5 contains policy docs/AGENTS,
not Go changes. Author ordinarily merged both as local1ce1c1e/treea6d45151,
remote9b25b0a9d191845a97ca8a114a18619625eaf223 with ordered bb57+f44 parents.
Review source compatibility increment against that merge, not an unrelated broad
BML redesign. Apply latest native AGENTS/ADR0018 and approved Vivy revision3 C5.

S4 actual App omission is already fixed and original unchanged probes rerun at
Vivy7ab14d5/tree5d4e0a7. S5 BML consumer/pin activation remains prohibited until
this producer is independently reviewed, fixed and published. Vivy still pinsbb57.

## Review focus

1. Actual runtimecore Open must pass the existing trusted RecapBinding before
   ingest starts; ProfileID is not the new subject identity. One owner/parser.
2. Only positive valid current v3 ReadRecap revision can justify incompatible
   legacy consumer closure. Raw schema prefix, generic unavailable, IO/malformed/
   foreign chain, live commit unknown, revision zero and orphan Windows states
   cannot. Native same-byte recovery publication is expected and must remain.
3. Existing applied receipts return true stored entries/revision. Existing exact
   complete archived native pair remains readable under v3. Archive-only result
   Revision=0 explicitly means no legacy head revision, not a new C1 revision.
   Garden recovers original Before.Revision+1 only from valid original snapshot
   plus exact positive entry proof. Legitimate original Before.Revision=0 is not
   automatically invalid; empty/malformed SHA or absent proof is unavailable.
4. Unknown old effect stays unknown with original Before/source/error/evidence.
   Consumer policy closure is a separate durable disposition, never fake applied
   or negative/no-effect proof. No C1 text/coverage movement or new ack store.
5. Real Start/restart, retry worker, HighWatermark and ArchiveSession consistently
   validate and honor closure. SQL json_extract alone must not bypass malformed
   metadata. One ordered source snapshot must retain earlier unresolved fences;
   close SQL rows before owner IO, inspect lock ordering/concurrency/cancellation.
   ArchiveSession must avoid denied v3 FoldSession rather than claiming a fold.
6. All legacy v3 writers still reject without authority/archive content mutation;
   v1/v2 behavior and actual positive old receipts stay intact. Failed durable
   closure write is not ACK. Existing raw-material accepted/running/spooled work
   is separate; consumer qualification/privacy on new BML selection remains a
   later S5 task, not an invented producer-wide migration or safety claim.

## Independent execution and evidence

Use an isolated clone with fixed native SHA and existing local-only runner, offline
dependencies, stripped credential-bearing env names and non-forwarding deny proxy.
Test-only overlays/external probes allowed; no production mutation. Preserve all
RED/failed/compile/interrupted output with exact command/native SHA/tree/source
hashes and pass/fail/skip counts. Coordinate disk/builds with root; do not repeat
broad gates or consume full race lanes without necessity. Root owns affected Vivy
integration, normal module publication/pin resolution, actual native Windows and
whole-candidate S6 gates. Cross-compile is not native Windows execution. No DSN is
not PostgreSQL execution; scripted HTTP is not live model quality.

Write report.md/raw/probes/source-hashes/hash-manifest here. List only substantiated
findings with exact reproduction/locations/severity; distinguish inherited issues,
new defects and scoped pending gates. Do not accept whole S5 or Issue58 from this
producer review. Root will archive and publish completed review evidence.

## Assigned immutable candidate

Native source candidate:3c365207d295221c4a3c5667fc71a6a465ee59f8,
tree1ca98be9a8cffb18d242bf3c1aa40a613d0bbb7f. Clean isolated clone already
prepared at /workspace/scratch/5dda642e718d/laputa-issue58-native-review with a real
.git directory. Root published tree-equivalent source remote
1edf7b2379d7887a016c57b78e2060ad9dae1588 on
feat/issue-58-recovery-native-20261016; source checkpoint is WIP/unaccepted pending
this independent review. Root verified full remote tree and merge-parent ancestry.
Do not change the sibling active /workspace/scratch/5dda642e718d/laputa checkout.

Author's English records are committed under
native docs/logs/2026-10-16-issue58-legacy-consumer/{summary,verification,acceptance}.md.
Author reports Garden ingest/runtimecore/agentapi normal/race each161 tests plus3
packages, ACTMEM normal/race each120 tests plus1 package,0fail/skip/race and no
external requests. These are author working-source iterations, not your execution;
keep every failed fixture/RED alongside completed GREEN in qualification. Root
will point to the final author raw report after it is written, but the committed
source/records are sufficient to begin. Actual Windows fixtures are source only
and NOT executed. Vivy still pinsbb57 and no BML consumer is active.

Use /tmp/issue58-localonly-runner.py and toolchain Go1.26.4; native working dirs
are <clone>/laputa and <clone>/garden. Follow native declared module dependencies,
and record them; root Vivy consumes Eino0.9.20 separately. Current free disk about
7GB, all author test builds have ended. Coordinate before large broad/race builds;
focused independent normal probes are authorized. No need to duplicate all author
race gates. Root owns later same-fixed-source normal/race/publication pin and all
Vivy activation regression. Full report must freeze source tree clean and include
per-file integrity plus execution manifests and original probe reproduction.
