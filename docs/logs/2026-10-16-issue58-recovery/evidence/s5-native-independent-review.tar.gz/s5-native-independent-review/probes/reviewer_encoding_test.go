package ingest

import (
 "context"
 "testing"
 "github.com/ProjectViVy/laputa/laputa/actmem"
)

func TestReviewerS5ClosureRejectsTrailingDelimiters(t *testing.T) {
 for _, suffix := range []string{"}","]"} {
  t.Run(suffix,func(t *testing.T){
   ctx := context.Background()
   s := openActivityIngest(t,t.TempDir())
   defer func(){_ = s.Close(); _ = s.Actmem.Close()}()
   s.RecapBinding = legacyTestBinding
   accepted,err := s.Submit(ctx,activityRequest()); if err != nil {t.Fatal(err)}
   if _,err = s.Actmem.CommitRecap(ctx,actmem.RecapCommit{Binding:legacyTestBinding,OperationID:"reviewer-v3",Cause:"edit",Text:"C1"}); err != nil {t.Fatal(err)}
   if err = s.projectActivity(ctx,accepted.IngestionID); err != nil {t.Fatal(err)}
   if _,err = s.db.Exec(`UPDATE ingestions SET status='completed', activity_json=activity_json || ? WHERE ingestion_id=?`,suffix,accepted.IngestionID); err != nil {t.Fatal(err)}
   if _,err = s.ActivityProjection(ctx,accepted.IngestionID); err == nil {t.Errorf("ActivityProjection accepted invalid JSON ending in extra %q",suffix)}
   if high,e := s.HighWatermark(ctx,""); e == nil {t.Errorf("HighWatermark accepted invalid closure and advanced to %d (row=%d)",high,accepted.Seq)}
   if e := s.ArchiveSession(ctx,activityRequest().SessionID); e == nil {t.Errorf("ArchiveSession accepted invalid closure")}
   if e := s.Start(); e == nil {t.Errorf("Start accepted invalid closure")}
  })
 }
}
