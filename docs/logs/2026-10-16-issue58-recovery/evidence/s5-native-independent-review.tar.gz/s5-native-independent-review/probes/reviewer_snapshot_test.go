package ingest

import (
 "context"
 "encoding/json"
 "testing"
 "github.com/ProjectViVy/laputa/laputa/actmem"
)

// Independent source-preserving overlay: positive native archive proof must not
// manufacture the missing original legacy revision. Zero is separately valid.
func TestReviewerS5OriginalSnapshotCompleteness(t *testing.T) {
 for _, mode := range []string{"complete_zero", "complete_nonzero", "missing_revision", "null_revision"} {
  t.Run(mode, func(t *testing.T) {
   ctx := context.Background()
   s := openActivityIngest(t,t.TempDir())
   defer func(){_ = s.Close(); _ = s.Actmem.Close()}()
   s.RecapBinding = legacyTestBinding
   accepted,err := s.Submit(ctx,activityRequest()); if err != nil {t.Fatal(err)}
   intent,seq,session,event,workspace,err := s.loadActivity(ctx,accepted.IngestionID); if err != nil {t.Fatal(err)}
   pair := s.projectedPair(intent,seq,session,event,workspace)
   if mode != "complete_zero" {
    seed := append(pair[:0:0],pair...)
    for i := range seed {seed[i].EventID = "older-native-event"; seed[i].SessionID = "older-session"}
    snap,e := s.Actmem.AppendSnapshot(); if e != nil {t.Fatal(e)}
    if _,e = s.Actmem.AppendCaptured(seed,snap); e != nil {t.Fatal(e)}
    if _,e = s.Actmem.FoldSession("older-session"); e != nil {t.Fatal(e)}
   }
   intent.Before,err = s.Actmem.AppendSnapshot(); if err != nil {t.Fatal(err)}
   originalRevision := intent.Before.Revision
   if mode != "complete_zero" && originalRevision == 0 {t.Fatal("fixture needs nonzero original revision")}
   actual,err := s.Actmem.AppendCaptured(pair,intent.Before); if err != nil {t.Fatal(err)}
   if actual.Revision != originalRevision+1 {t.Fatal("fixture lost native revision")}
   if _,err = s.Actmem.FoldSession(session); err != nil {t.Fatal(err)}
   intent.Status,intent.Error = "unknown","original uncertain attempt"
   if err = s.saveActivity(ctx,accepted.IngestionID,intent); err != nil {t.Fatal(err)}
   if mode == "missing_revision" || mode == "null_revision" {
    encoded,e := json.Marshal(intent); if e != nil {t.Fatal(e)}
    var fields map[string]json.RawMessage; if e = json.Unmarshal(encoded,&fields); e != nil {t.Fatal(e)}
    var before map[string]json.RawMessage; if e = json.Unmarshal(fields["before"],&before); e != nil {t.Fatal(e)}
    if mode == "missing_revision" {delete(before,"revision")} else {before["revision"] = json.RawMessage("null")}
    fields["before"],e = json.Marshal(before); if e != nil {t.Fatal(e)}
    encoded,e = json.Marshal(fields); if e != nil {t.Fatal(e)}
    if _,e = s.db.Exec(`UPDATE ingestions SET activity_json=? WHERE ingestion_id=?`,string(encoded),accepted.IngestionID); e != nil {t.Fatal(e)}
   }
   head,err := s.Actmem.CommitRecap(ctx,actmem.RecapCommit{Binding:legacyTestBinding,OperationID:"reviewer-v3",Cause:"edit",Text:"current C1"}); if err != nil {t.Fatal(err)}
   err = s.projectActivity(ctx,accepted.IngestionID)
   if mode == "missing_revision" || mode == "null_revision" {
    if err != nil {t.Logf("incomplete original snapshot rejected: %v",err);return}
    got,_,_,_,_,e := s.loadActivity(ctx,accepted.IngestionID); if e != nil {t.Fatal(e)}
    if got.Status == "applied" || got.Revision != 0 || len(got.Entries)>0 || got.Source.UserText != intent.Source.UserText || got.Error != intent.Error {
     t.Fatalf("incomplete snapshot manufactured applied receipt: actual_native_revision=%d original_before_revision=%d got_status=%s got_revision=%d got_entries=%v got_source=%q got_error=%q",actual.Revision,originalRevision,got.Status,got.Revision,got.Entries,got.Source.UserText,got.Error)
    }
    if got.LegacyConsumer == nil {t.Fatal("expected independent policy closure or explicit rejection")}
   } else {
    if err != nil {t.Fatal(err)}
    got,_,_,_,_,e := s.loadActivity(ctx,accepted.IngestionID); if e != nil {t.Fatal(e)}
    if got.Status!="applied" || got.Revision != actual.Revision || len(got.Entries)!=2 || got.Entries[0]!=actual.Entries[0].ID || got.Entries[1]!=actual.Entries[1].ID {t.Fatalf("valid positive proof failed: %+v",got)}
    t.Logf("complete original revision %d rejoined native revision %d",originalRevision,actual.Revision)
   }
   current,e := s.Actmem.ReadRecap(ctx,legacyTestBinding); if e != nil || current != head {t.Fatalf("C1 changed: %+v %v",current,e)}
  })
 }
}
