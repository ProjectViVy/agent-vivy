# Independent S5 native BML producer review

Prepared scope only. Do not execute until root supplies immutable SHA/tree and
clean isolated clone. Independent GPT-6 Astra High, no subagents, source edits,
index changes or GitHub mutations. Root owns integration/publishing and consumer
activation. One consolidated author TDD pass follows substantiated findings, then
root reruns unchanged probes; no redundant second review of the same fix diff.

## Contract and scope

Approved revision3 C4/C5 and S5 plan, existing native BML Home/Store/SQLite/FTS.
Base Vivy0baf8d3b/tree d006e2f1; product/dependency pinfdcb25a5. Native Laputa
published249a756e/tree9fff8cf9 is separately reviewed and immutable. No App/Factory/
Garden adapter/runtime/Observer/UI/Recipe consumer activation belongs to this cut.
Eino is outside this native persistence scope; later orchestration must reuse
pinned Eino0.9.20 and existing approved seams. This is not another memory engine,
transcript authority, index algorithm or schema046 core tenant migration.

## Review focus

- Native schema2 fresh and actual existing Home mutable-open upgrade are atomic;
  legacy schema1 read-only does not upgrade/create or falsely claim bound support.
  Backup validation is read-only, original backup bytes retained, only copied live
  restore upgrades under existing rollback. Preserve old unbound backup/identity
  migration behavior. Newly bound canonical-identity migration explicitly refuses
  before any metadata/record/backup write; historical operation state also fences
  migration even if all owned records have been tombstoned or collected.
- One existing Store.putInner SQLite transaction commits record/owner/FTS/
  supersedes/counters and immutable operation result. Receipt failure rolls all
  back. No CRUD-then-receipt, second DB, revive-old-apply-journal or fake proposal.
- Explicit full subject/domain/scope-kind/logical-workspace/destination binding is
  separate from native physical Record.Scope and old ProfileID. No implicit old
  row ownership promotion. Unknown old data remains legacy/unbound.
- Canonical request fingerprint includes complete raw record/provenance/source
  refs and every optional CAS with absence versus explicit zero preserved, plus
  operation and exact binding/destination. Caller digest alone is insufficient;
  malformed UTF-8 must reject before JSON replacement/normalization.
- Original immutable actual operation result survives later update, tombstone,
  restart and native GC. Replay lookup precedes today's CAS; operation reuse with
  altered full request rejects. Native record/revision/storeRevision/target/index
  dispositions must be truthful, not reconstructed from today's row. Concurrent
  handles same operation cause one effect; failure/cancel/commit uncertainty does
  not fabricate receipt. Inspect SQLite locking and transaction boundaries.
- Legacy Store/Home Get/List/Search/SearchVisible/Update/Remove/Import/L1 and GC
  cannot see or mutate new bound rows. Filters precede LIMIT/FTS ranking. Bound
  Get/Search/export/lookup enforce exact owner and expected revision; tombstone/
  stale/index-unavailable outcomes explicit. New binding cannot read unknown old
  machine rows. Preserve ordinary legacy Coding storage behavior. Check reverse
  link/supersedes/tombstone paths and exported source/raw material.
- Minimal cohesive implementation, existing native search/ranker retained; no
  DTO coupling to Garden. Native receipt stores result/fingerprint only, not a
  second copy of original body as another transcript authority.

## Execution and evidence

Use clean clone real .git directory (Go1.26 VCS root discovery); native module
./bml declares SQLite1.56.0, root MVS1.59 qualification is separate. Exact versions
are cached; /tmp/issue58-localonly-runner.py uses offline dependencies, credential
name stripping and non-forwarding deny proxy while allowing localhost fixtures.
Read AGENTS and approved design/plan plus author's report. Independent probes may
use external immutable test overlays; never edit product source. Preserve all RED/
compile/failed/interrupted outputs, full candidate SHA/tree, exact commands, pass/
fail/skip counts, per-file source and artifact SHA256 manifest. Coordinate builds
with root; do not blindly duplicate broad/race author gates. Report only evidenced
findings ordered by impact with locations, reproduction, consequence, minimal fix.

Root owns fixed normal/race, root MVS integration, Windows/new-browser/final CI.
Cross-compile is not Windows execution; no DSN is not PostgreSQL; HTTP fixtures
are not live model quality. No App/BML consumer or whole S5 acceptance in report.
Write report.md, raw, probes, execution/source/hash manifests in this directory.

## Assigned immutable candidate

Local source92048bccda52875a798ade1bccc4e44823a564fb, tree
a9532ce41a286334e0462b7401bce786e89e65c0; exact-tree remote
5770f07ffbe4fd0b5701678846b97d4e6557eb68 already published/GET-verified.
Clean isolated clone /workspace/scratch/5dda642e718d/agent-vivy-issue58-bml-native-review
is detached at that SHA with real .git directory; review only ./bml and direct
existing contracts. Active main workspace has pending root docs/evidence and
will later receive small separately scoped fixture/i18n CI fixes; those are not
your review candidate and cannot alter this frozen clone. Native Laputa unchanged.

Source19files,14Go(7prod+7test),5docs. Author final working-source nativeSQLite1.56
normal/race each155tests+1pkg PASS1.424s/7.354s; rootMVS1.59 normal155+1 PASS1.730s,
vet PASS. Runner HEAD0baf reflects precommit working-source execution, not a
fixed92048 execution; source-hashes/tested-source-hashes bind actualGo bytes to
committed19files. Read committed bml/docs/owned-memory.md and native records;
author final external raw/report in active .superpowers/sdd/S5-bml-native. Root
will independently verify hashes and run fixed-candidate normal/race later. No
consumer activated. All author tests/builds have ended, disk~5.9GB; focused
independent native builds allowed, coordinate if substantial extra builds needed.

Separately actual intermediate Windows root CI has invalid shared conformance
fixture /trusted/owner (native Windows requires volume) plus stale Generation
inventory, and UI crossface classification omissions. These are outside native
BML scope. Root fixes retain production binding guards and will rerun Windows
on later whole candidate; they cannot be used as native BML Windows evidence.
