package bml
import (
 "context"
 "testing"
)
func TestReviewerBMLTombstoneCannotBypassSecondTargetCAS(t *testing.T) {
 ctx:=context.Background();s:=openTestStore(t,machineMemoryScope)
 a:=issue58Create("target-a");oa,err:=s.MutateBound(ctx,issue58Owner,a);if err!=nil {t.Fatal(err)}
 b:=issue58Create("target-b");ob,err:=s.MutateBound(ctx,issue58Owner,b);if err!=nil {t.Fatal(err)}
 update:=b;update.Operation="update";update.OperationID="update-b";update.ExpectedRecordRevision=&ob.RecordRevision
 update.Record.Content="new corrected B content";update.Record.Provenance.ContentDigest=MemoryContentDigest([]byte(update.Record.Content))
 newer,err:=s.MutateBound(ctx,issue58Owner,update);if err!=nil {t.Fatal(err)}
 // Only A's version is supplied; B was independently updated to revision 2.
 marker:=tombstoneRecord("marker",machineMemoryScope,a.Record.ID);marker.Scope=machineScope(nil)
 marker.Supersedes=append(marker.Supersedes,b.Record.ID)
 req:=BoundMutation{Operation:"tombstone",OperationID:"delete-a",PayloadDigest:"delete-a-digest",Record:marker,ExpectedTargetRevision:&oa.RecordRevision}
 out,err:=s.MutateBound(ctx,issue58Owner,req)
 if err!=nil {t.Logf("extra unguarded target rejected: %v",err);return}
 if _,err=s.GetBound(ctx,issue58Owner,b.Record.ID,newer.RecordRevision);err!=nil {t.Fatalf("single-target CAS tombstone deleted independently updated B without B CAS: outcome_target=%s A_revision=%d B_revision=%d error=%v",out.TargetID,oa.RecordRevision,newer.RecordRevision,err)}
}
