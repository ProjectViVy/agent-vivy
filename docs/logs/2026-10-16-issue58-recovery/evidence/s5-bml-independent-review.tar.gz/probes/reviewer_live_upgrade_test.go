package bml
import (
 "context"
 "path/filepath"
 "testing"
)
// Hold an actual public schema-1 read-only handle across the supported mutable
// upgrade; this is not an old binary, an altered DB, or an untrusted table shape.
func TestReviewerBMLReadOnlyHandleAcrossUpgrade(t *testing.T) {
 ctx:=context.Background(); dir:=t.TempDir()
 issue58SchemaOne(t,filepath.Join(dir,storeFileName),machineMemoryScope)
 ro,err:=OpenExisting(ctx,dir,machineMemoryScope);if err!=nil {t.Fatal(err)};defer ro.Close()
 if caps:=ro.BoundCapabilities();caps.Search||caps.Export||caps.Mutate||caps.MutationLookup {t.Fatalf("v1 unexpectedly bound-capable: %+v",caps)}
 if got,e:=ro.Get(ctx,"legacy");e!=nil||got==nil {t.Fatalf("legacy control unavailable: %+v %v",got,e)}
 rw,err:=Open(ctx,dir,machineMemoryScope);if err!=nil {t.Fatal(err)};defer rw.Close()
 req:=issue58Create("new-private-row")
 out,err:=rw.MutateBound(ctx,issue58Owner,req);if err!=nil {t.Fatal(err)}
 if got,e:=rw.GetBound(ctx,issue58Owner,req.Record.ID,out.RecordRevision);e!=nil||got.Record.Content!=req.Record.Content {t.Fatalf("native bound control failed: %+v %v",got,e)}
 if got,e:=ro.Get(ctx,req.Record.ID);e==nil&&got!=nil {t.Errorf("schema-1 readonly handle leaked owned row via legacy Get: id=%s content=%q",got.Record.ID,got.Record.Content)}
 if rows,e:=ro.List(ctx,100);e==nil {for _,row:=range rows {if row.Record.ID==req.Record.ID {t.Errorf("schema-1 readonly handle leaked owned row via legacy List")}}}
 q:=SearchQuery{Text:"continuity needle",Scope:machineScope(nil),Limit:1}
 if rows,e:=ro.Search(ctx,q);e==nil&&len(rows)>0 {t.Errorf("schema-1 readonly handle leaked owned FTS via legacy Search: %+v",rows)}
 if rows,e:=ro.SearchVisible(ctx,q);e==nil&&len(rows)>0 {t.Errorf("schema-1 readonly handle leaked owned FTS via legacy SearchVisible: %+v",rows)}
}
