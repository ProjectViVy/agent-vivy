package bml
import (
 "context"
 "database/sql/driver"
 "testing"
 "modernc.org/sqlite"
)
func TestReviewerBMLCancelDuringReceiptRollsBackEverything(t *testing.T) {
 ctx,cancel:=context.WithCancel(context.Background());defer cancel()
 sqlite.MustRegisterScalarFunction("reviewer_cancel_native_receipt",0,func(_ *sqlite.FunctionContext,_ []driver.Value)(driver.Value,error){cancel();return int64(1),nil})
 s:=openTestStore(t,machineMemoryScope)
 if _,err:=s.db.Exec(`CREATE TRIGGER reviewer_cancel_receipt BEFORE INSERT ON memory_operations BEGIN SELECT reviewer_cancel_native_receipt(); END`);err!=nil {t.Fatal(err)}
 req:=issue58Create("cancel-at-receipt")
 if out,err:=s.MutateBound(ctx,issue58Owner,req);err==nil {t.Fatalf("canceled in-transaction receipt returned success: %+v",out)}
 bg:=context.Background()
 if got,err:=s.LookupBoundMutation(bg,issue58Owner,req.OperationID,req.PayloadDigest);err!=nil||got!=nil {t.Fatalf("cancellation fabricated retained outcome: %+v %v",got,err)}
 if meta,err:=s.Metadata(bg);err!=nil||meta.StoreRevision!=0||meta.RecordCount!=0||meta.ContentBytes!=0 {t.Fatalf("cancellation left counters/CAS: %+v %v",meta,err)}
 for _,table:=range []string{"memory_records","memory_ownership","memory_operations","memory_fts","memory_supersedes"} {if n:=countTableRows(t,s,table);n!=0 {t.Fatalf("cancellation left %s=%d",table,n)}}
 if _,err:=s.db.Exec(`DROP TRIGGER reviewer_cancel_receipt`);err!=nil {t.Fatal(err)}
 if out,err:=s.MutateBound(bg,issue58Owner,req);err!=nil||out.RecordRevision!=1||out.StoreRevision!=1 {t.Fatalf("exact canceled request could not retry once: %+v %v",out,err)}
}
