# Issue58 S5 Task1a independent source review

Candidate: `f6bcae7df73cd192e352480762621b8bb84ae711`  
Tree: `28c871b5da28c48f14157b05f12fff6f440c0e70`  
Base: `22a137c68e53a5ba9b46b73fecb8ab019aa2e523`  
Pinned sibling Laputa: `249a756e04c5f28af781e4dadea9e9086689bde0`

## Findings

### Important I1 — Reject negative expansion budgets before slicing

Location: `internal/modules/memory/backend.go:175–192` (`BoundBackend.Expand`).

The adapter rejects budgets above 4000 but accepts negative budgets. Its preceding `req.Validate()` does not close this gap: the pinned Garden `AuthorizedExpansion.Validate` in `garden/memory/contract.go:82–97` validates scopes, card identity and positive revision only. With a live backend, an authorized visible card, its matching revision, and `BudgetChars: -1`, native export succeeds, `end := min(len(runes), budget)` becomes -1, and `string(runes[:end])` panics. This occurs even for an empty content string. It violates the bounded backend's explicit-error contract and can terminate a caller goroutine/process in the absence of an outer panic recovery. The prepared adapter is not yet exposed as activated LIFE projection; no public exploit or deployed incident is claimed.

Smallest correction: include `req.BudgetChars < 0` in the adapter's bounds rejection, preserving zero's existing default and the 4000 upper bound. Add an ordinary local regression fixture with a real native matching record/revision that asserts a negative budget returns `ErrInvalidSchema` without panic; keep zero and positive-budget controls. No Garden API change or product redesign is needed.

Evidence status: source-substantiated, not executed by this reviewer. The lead was notified to reproduce this exact case using its ordinary local fixtures.

### Critical

None substantiated.

### Minor

None substantiated.

## Other reviewed behavior

The operation-only status path compares the complete canonical ownership binding before decoding the saved result. Digest-free lookup is isolated by a nil digest pointer; strict lookup still validates and supplies its digest, and mutation replay still supplies both digest and complete native request fingerprint. The shared decoder compares the outcome digest to the saved digest. No schema or transaction/CAS rewrite appears in this increment. Existing native controls were read for immutable results after update/tombstone/reopen, exact identity/fingerprint conflicts, atomic failures, concurrent replay, and post-commit L1 refresh failure.

The adapter validates the current DTOs' raw string fields before JSON/base64 conversion, preserves typed source references in encoded evidence, and includes the complete Garden request hash in native provenance. CRUD and status translate native IDs/revisions/statuses; tombstone results retain the native marker identity. Native search applies binding before rank/LIMIT and remains capped at 100 hits. The adapter's cursor authenticates the request with its own per-instance key. Search cards omit bodies; expansion asks the native owner for an exact visible revision. I1 is the substantiated bounds exception.

App construction acquires under both normalized Home root and actual storage lease owner. The lifecycle mutex serializes registry acquisition/release, and exact Service release cannot detach a replacement. Selected provider slices/action sets and provider objects are copied before binding; the caller Assembly retains its own original objects. Closed App providers retain their old Service and cannot resolve a later ambient Active service. Normal Close and Run cancellation place Home release after their consumer shutdown sequence and before storage close. Early listener returns and timeout behavior are explicitly outside this increment's complete-drain claim; no stronger lifecycle certification is made here.

The trusted Recap callback prepares a borrowed subject backend while preserving ProfileID `diva`, the legacy scope/raw route, and existing subscriptions. No projection activation, backend-map replacement or profile alias was added. A no-BML composition remains an explicit later admission-qualification task.

## Requirements and review boundaries

Reviewed the repository AGENTS instructions; the Task1a summary, verification and acceptance records; the S5 recovery routing ruling; relevant revision-3 design identity/C5/Eino sections; and the module/plugin review guidance. The requesting-code-review skill and repository vivy-plugin/vivy-kernel-ci instructions were consulted. This assignment expressly restricted execution to source reading and review documentation, so their implementation/test commands were not run.

Eino capability check: the approved design identifies `adk/middlewares/summarization` (`New`, `Summarize`, `GenModelInput`, `Finalize`, `Callback`) and ADK rewrite/resume hooks, with the current native-fix amendment on v0.9.20. This increment changes native persistence adaptation and composition lifetime; it introduces no summarizer, agent loop, checkpoint mechanism, Eino import or alternate inference path. No additional Eino implementation was warranted by this diff.

The 24 changed paths were compared with the base, with selective unchanged source/test controls and the pinned Garden semantic contract. The companion manifest hashes the candidate paths and reviewed controls; hashes are provenance, not runtime verification. Author reports/manifests were read as supplied evidence. Their normal/race/native/vet results, and the lead's fixed-candidate normal result, are attributed evidence rather than reviewer executions. Pending lead checks are not declared passed by this report.

No application, test suite, executable fixture or network request was run by this reviewer. No production/test source, git index, or sibling library was modified; only this report and its manifest were written in the assigned review directory. The reviewed worktree was clean when inspected.

Task1b historical C2 source navigation, Task2 projection/recall qualification and no-sink admission, installed DIVA, Windows/UI, full CI and final product acceptance remain unfinished and are not accepted by this review. Task1a should not receive an unqualified pass until I1 is corrected and the lead verifies the fixed candidate. This is not whole-Issue58 acceptance.
