# Read-only Windows Recap browser setup diagnosis

Outcome: the new Recap browser test did not start. Its second webServer command failed while launching pnpm; no rendered Recap assertion executed. Existing selected-full-UI acceptance remains a separate positive: both old browser smoke tests passed, and the selected process Stop/Wait step succeeded before the new split command began.

## Exact evidence and boundary

Actual run: 38825120165, browser job 116730972962, PR merge checkout `267a0151acc09c533ace5767001ce5a9e2424df5` (log says branch `554c668391852ad6cf2b9fc189c56be18b76e1a6` into main `5715950ddfc87e05cf60e3d2a0ca54983bef05eb`). The source configuration studied is frozen Vivy `2e6273d8b4a6a58d5154633b1805137a633a59b9`, tree `89dbbe29a3fd08f7d116ff44b7e0a7c8c11e4093`. The designated local validation clone initially had that HEAD and was later advanced by root to `46a10b3f299c00b3efe6b8328a42967bf537ce30`; relevant inspected CI/config/package/staging files remain byte-identical to `git show 2e6273d8:<path>`. Manifest hashes use the frozen objects, not a later BML/doc checkpoint.

The original full job log is retained as `issue58-browser-windows-116730972962.log`:

- Lines 121–166: pnpm/action-setup installs pnpm 11.19.0 under `C:\Users\runneradmin\setup-pnpm`; PNPM_HOME is `C:\Users\runneradmin\setup-pnpm\node_modules\.bin`. Setup-node successfully invokes the absolute `pnpm.CMD store path --silent` through cmd.exe. Node is 24.21.0.
- Lines 265–395: dependency installation, normal prebuild staging/build and supported Chromium installation complete. This is not an absent pnpm dependency or missing browser-install step.
- Lines 500–506: both existing full-UI browser tests pass (2 tests, 19.8 seconds).
- Lines 507–518: selected-full-UI Stop-Process/Wait-Process step passes.
- Lines 519–534: new split invocation is `pnpm --dir ui exec playwright test --config playwright.issue58.config.ts`; GO_EXE is set to actual Go. PNPM_EXE is not set.
- Lines 535–553: after the first Go webServer startup period, the second webServer fails with `Cannot find module 'D:\a\agent-vivy\pnpm\bin\pnpm.mjs'`, `requireStack: []`, Node exit 1, then `Process from config.webServer was not able to start`.
- Lines 554–569: workflow fails, and always-upload warns that `ui/test-results/` has no files. There are no new Recap screenshots/traces to inspect. This is a setup failure before browser rendering, not a failed Recap UI assertion.

## Root cause and confidence

**High-confidence mechanism, explicitly an inference:** the dedicated config quotes the default PATH-only command name into `"pnpm" --dir ui dev --host 127.0.0.1`. The pinned installed Playwright 1.62.1 webServer implementation calls its launcher with `shell: true`; its core launcher passes that to Node child_process.spawn. On Windows this uses cmd.exe rather than the outer workflow's successful PowerShell command resolution. A relative batch shim then resolves its pnpm JS entry against the working directory instead of its installation directory when invoked as the quoted bare name.

The diagnostic path is exact: the job CWD is `D:\a\agent-vivy\agent-vivy`, and resolving the expected shim-relative `..\pnpm\bin\pnpm.mjs` from that wrong base yields precisely `D:\a\agent-vivy\pnpm\bin\pnpm.mjs`. The installed path should be under setup-pnpm's node_modules, not the checkout parent. This explains why outer pnpm commands and the earlier absolute pnpm.CMD command work, while this nested quoted lookup fails. Environment/cwd changes from package scripts are not needed to explain the failure. The read-only `ui/.npmrc` only chooses a registry; it does not configure a launcher path. No package file declares a different package manager or executable override.

The actual Windows pnpm.cmd bytes and a same-run quoted/unquoted/absolute comparison were not captured, and native Windows is unavailable here. Therefore the precise `%~dp0` expansion behavior is not claimed as directly reproduced. The local runtime's pnpm 11.25.0 cmd-shim generator was inspected only as corroborating family behavior; it is not represented as the CI pnpm 11.19.0 shim. External retrieval of exact upstream primary source pages was unavailable; no external issue summary is treated as proof. The retained `readonlyprobe.mjs` can compare those three command forms and preserve the actual shim text on a future native Windows execution; those Windows branches were NOT RUN.

## Selected minimal proposal — do not implement yet

Root selected the existing explicit executable seam. In the existing workflow's new Recap browser step, after resolving GO_EXE and before the unchanged Playwright command, set:

```powershell
$env:PNPM_EXE = (Get-Command pnpm.cmd -CommandType Application).Source
```

This changes the nested command from quoted bare `pnpm` to the actual absolute .cmd path. It retains the existing `pnpm --dir ui dev` script, predev/stage-ui hook, Vite config, proxy, ports, startup order, readiness checks, no-reuse policy and all existing test assertions. The CI log already proves the absolute setup-pnpm pnpm.CMD launcher is installed and runs through cmd.exe for store-path setup; the new nested invocation still requires an actual supported Windows rerun and can disprove the inference. Do not hard-code a runner drive/user path, change permissions, increase timeouts, reuse servers, or weaken assertions.

Document the same invocation for native Windows users of this dedicated fixture:

```powershell
$env:GO_EXE = (Get-Command go -CommandType Application).Source
$env:PNPM_EXE = (Get-Command pnpm.cmd -CommandType Application).Source
pnpm --dir ui exec playwright test --config playwright.issue58.config.ts
```

No source/index edit has been made; S5 owns the active writer/index lane. Root will sequence the bounded remediation after the S5 freeze.

If the explicit absolute command rerun still fails, the fallback proposal is to launch the existing stage-ui-assembly.mjs with absolute `process.execPath`, require successful staging, then launch the installed Vite CLI resolved from its package.json bin using the same Node executable, ui cwd, port 3015/strictPort/loopback and current Vite proxy config. This avoids all nested package-manager shims but adds startup composition; retain it only as a deferred alternative, not the first fix. No new launcher or parallel staging implementation is warranted now.

## Local read-only check

The unchanged local-only runner executed `node readonlyprobe.mjs` from the designated clone. It resolves the actual installed Vite 7.3.6 CLI from package metadata and invokes only `--version` with absolute Node and `shell:false`; status 0. It also performs Windows path arithmetic matching the failure. Linux Node is 24.19.0. Raw logs and runner metadata record zero forwarded/rejected external requests and credential stripping. This establishes Linux CLI resolution/version and path arithmetic only: no Vite server, staging, Go test/build, browser, Windows command execution or product acceptance. No full CI or source builds were started.

Source and evidence hashes are in manifest.json. No native Windows owner-test failures were investigated; that separate diagnosis remains with its assigned agent. No source/index/commit/push changes were performed.
