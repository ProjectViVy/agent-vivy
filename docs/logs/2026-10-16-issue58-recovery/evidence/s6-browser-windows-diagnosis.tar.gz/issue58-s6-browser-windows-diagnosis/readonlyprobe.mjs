import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
const repo=process.cwd();
const ui=path.join(repo,'ui');
const require=createRequire(path.join(ui,'package.json'));
const pkgFile=require.resolve('vite/package.json');
const pkg=JSON.parse(fs.readFileSync(pkgFile,'utf8'));
const cli=path.resolve(path.dirname(pkgFile),pkg.bin.vite);
const stage=path.join(ui,'scripts/stage-ui-assembly.mjs');
assert(fs.existsSync(cli)&&fs.existsSync(stage));
const version=spawnSync(process.execPath,[cli,'--version'],{cwd:ui,encoding:'utf8',shell:false});
assert.equal(version.status,0,version.stderr);
// This is arithmetic under the suspected wrong Windows batch directory,
// not an execution of cmd.exe or a claim about the actual uncollected shim.
const cwd=String.raw`D:\a\agent-vivy\agent-vivy`;
const suspected=path.win32.resolve(cwd,'..','pnpm','bin','pnpm.mjs');
assert.equal(suspected,String.raw`D:\a\agent-vivy\pnpm\bin\pnpm.mjs`);
let windows={qualification:'NOT RUN: this process is not native Windows'};
if (process.platform==='win32') {
 const located=spawnSync('where.exe',['pnpm.cmd'],{cwd:repo,encoding:'utf8',shell:false});
 const shim=located.stdout?.split(/\r?\n/).find(value=>value.trim()&&fs.existsSync(value.trim()))?.trim();
 const commands=['"pnpm" --version','pnpm --version',...(shim?[`"${shim}" --version`]:[])];
 windows={qualification:'Native Windows command-only read probe; no server/test/build',whereStatus:located.status,shimPath:shim,shimText:shim?fs.readFileSync(shim,'utf8'):null,cases:commands.map(command=>{const result=spawnSync(command,[],{cwd:repo,encoding:'utf8',shell:true,timeout:15000});return {command,status:result.status,signal:result.signal,error:result.error?.message,stdout:result.stdout,stderr:result.stderr}})};
}
console.log(JSON.stringify({windows,platform:process.platform,node:process.version,nodeExecutable:process.execPath,viteVersion:pkg.version,vitePackage:pkgFile,viteCLI:cli,existingStageScript:stage,cliVersionInvocation:{shell:false,status:version.status,stdout:version.stdout.trim(),stderr:version.stderr.trim()},windowsPathArithmetic:{assumedBatchDirectory:cwd,relativeEntry:'..\\pnpm\\bin\\pnpm.mjs',result:suspected},qualification:'Linux CLI resolution/version and Windows path arithmetic only; no source edits, staging, Vite server, Go test/build, Windows execution or browser rendering'},null,2));
