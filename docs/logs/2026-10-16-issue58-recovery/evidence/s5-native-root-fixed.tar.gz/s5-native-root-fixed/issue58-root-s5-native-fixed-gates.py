from pathlib import Path
import subprocess,json,sys
root=Path('/workspace/scratch/5dda642e718d/laputa-issue58-native-fixed-validation')
assert subprocess.check_output(['git','-C',str(root),'rev-parse','HEAD'],text=True).strip()=='a99c25feea48e151c847cea81015bec0fdfe80bf'
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True).strip()
results=[]
for module,group in [('garden',['./internal/ingest','./internal/runtimecore','./agentapi']),('laputa',['./actmem'])]:
 for race in [False,True]:
  label='issue58-root-s5-native-fixed-'+module+('-race' if race else '-normal')
  cmd=['go','test','-json','-p=1']+(['-race'] if race else [])+group+['-count=1','-timeout=6m']
  r=subprocess.run([sys.executable,'/tmp/issue58-localonly-runner.py',str(root/module),label,*cmd])
  results.append(json.loads(Path('/tmp',label+'.json').read_text()))
  Path('/tmp/issue58-root-s5-native-fixed-gates-results.json').write_text(json.dumps(results,indent=2)+'\n')
  if r.returncode:sys.exit(r.returncode)
subprocess.run(['git','-C',str(root),'diff','--check'],check=True)
assert not subprocess.check_output(['git','-C',str(root),'status','--porcelain'],text=True).strip()
