# The dev entry must prepare Laputa without inheriting setup's checkout.
Move-Item ../laputa ../laputa-setup-checked
if (Test-Path ui/dist) { throw 'cold dev smoke must start without ui/dist' }
New-Item -ItemType Directory -Force .workspace | Out-Null
$dev = Start-Process just -ArgumentList @('dev', '-NoBrowser') -PassThru `
  -RedirectStandardOutput .workspace/cold-dev.stdout.log `
  -RedirectStandardError .workspace/cold-dev.stderr.log
try {
  $ready = $false
  $deadline = (Get-Date).AddMinutes(8)
  while ((Get-Date) -lt $deadline) {
    if ($dev.HasExited) { throw "just dev exited with $($dev.ExitCode)" }
    try {
      $backend = Invoke-WebRequest http://127.0.0.1:8787/healthz -TimeoutSec 2
      $ui = Invoke-WebRequest http://127.0.0.1:3015/ -TimeoutSec 2
      if ($backend.StatusCode -eq 200 -and $ui.StatusCode -eq 200) {
        $ready = $true
        break
      }
    } catch { }
    Start-Sleep -Milliseconds 500
  }
  if (-not $ready) { throw 'fresh-clone just dev did not become ready' }
} finally {
  Get-Content .workspace/cold-dev.stdout.log -ErrorAction SilentlyContinue
  Get-Content .workspace/cold-dev.stderr.log -ErrorAction SilentlyContinue
  if (-not $dev.HasExited) {
    # taskkill exits 1 when a tree member already exited on its own;
    # that teardown noise must not fail a green smoke.
    taskkill.exe /T /F /PID $dev.Id
    $global:LASTEXITCODE = 0
  }
}
