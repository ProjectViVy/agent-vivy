New-Item -ItemType Directory -Force -Path .workspace/p9-browser-home | Out-Null
go run ./sdk pack --recipe sdk/internal/testdata/full-ui.vivy.yml --source sdk/internal/testdata/full-ui-module --output .workspace/p9-full-ui
$savedAddr = $env:VIVY_ADDR
$savedHome = $env:VIVY_USER_HOME
try {
  $env:VIVY_ADDR = '127.0.0.1:3015'
  $env:VIVY_USER_HOME = (Resolve-Path '.workspace/p9-browser-home').Path
  $process = Start-Process -FilePath (Resolve-Path '.workspace/p9-full-ui/vivy.exe') -WorkingDirectory $PWD -PassThru -RedirectStandardOutput '.workspace/p9-full-ui.stdout.log' -RedirectStandardError '.workspace/p9-full-ui.stderr.log'
  Set-Content -Path '.workspace/p9-full-ui.pid' -Value $process.Id
} finally {
  $env:VIVY_ADDR = $savedAddr
  $env:VIVY_USER_HOME = $savedHome
}
$healthy = $false
for ($attempt = 0; $attempt -lt 60; $attempt++) {
  try {
    $response = Invoke-WebRequest -UseBasicParsing -TimeoutSec 2 'http://127.0.0.1:3015/healthz'
    if ($response.StatusCode -eq 200) {
      $healthy = $true
      break
    }
  } catch {
    Start-Sleep -Milliseconds 500
  }
}
if (-not $healthy) {
  Get-Content '.workspace/p9-full-ui.stdout.log' -ErrorAction SilentlyContinue
  Get-Content '.workspace/p9-full-ui.stderr.log' -ErrorAction SilentlyContinue
  throw 'selected full-UI server did not become healthy'
}
$env:GO_EXE = (Get-Command go).Source
Push-Location ui
try {
  pnpm exec playwright test e2e/plugin-full-ui.spec.ts
  if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
  }
} finally {
  Pop-Location
}
