if (Test-Path '.workspace/p9-full-ui.pid') {
  $selected = Get-Process -Id (Get-Content '.workspace/p9-full-ui.pid') -ErrorAction SilentlyContinue
  if ($selected) {
    $selected | Stop-Process -Force -ErrorAction Stop
    $selected | Wait-Process -Timeout 30 -ErrorAction Stop
  }
}
