$ErrorActionPreference = 'Stop'
$PSNativeCommandUseErrorActionPreference = $false
$evidence = Join-Path $env:GITHUB_WORKSPACE 'test-evidence/native'
New-Item -ItemType Directory -Force $evidence | Out-Null
$go = (Get-Command go).Source
$lock = Get-Content laputa-source.lock.json -Raw | ConvertFrom-Json
$nativeHead = (& git -C ../laputa rev-parse HEAD).Trim()
if ($LASTEXITCODE -ne 0 -or $nativeHead -ne $lock.commit) { throw 'native checkout does not match the published source lock' }
$identity = [ordered]@{
  vivy_commit = (& git rev-parse HEAD).Trim()
  laputa_lock = $lock
  laputa_head = $nativeHead
  go_version = (& $go version) -join "`n"
  go_os = (& $go env GOOS).Trim()
  go_arch = (& $go env GOARCH).Trim()
  runner_os = $env:RUNNER_OS
  host_os = [System.Runtime.InteropServices.RuntimeInformation]::OSDescription
  run_url = "$env:GITHUB_SERVER_URL/$env:GITHUB_REPOSITORY/actions/runs/$env:GITHUB_RUN_ID"
  qualification = 'Native Windows tests; no PostgreSQL DSN or live-provider acceptance claim'
}
$identity | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $evidence 'identity.json') -Encoding utf8
if ($identity.go_os -ne 'windows') { throw 'native Windows lane must execute on Windows, not cross-compile' }
$lanes = @(
  @{ name = 'bml'; root = 'bml'; packages = @('./...') },
  @{ name = 'actmem'; root = '../laputa/laputa'; packages = @('./actmem') },
  @{ name = 'garden'; root = '../laputa/garden'; packages = @('./internal/ingest', './internal/runtimecore', './agentapi') }
)
$results = @()
$failed = $false
foreach ($lane in $lanes) {
  Push-Location $lane.root
  try {
    & $go mod edit -json 1> (Join-Path $evidence "$($lane.name)-declared-module.json") 2> (Join-Path $evidence "$($lane.name)-module.stderr.log")
    if ($LASTEXITCODE -ne 0) { throw "cannot record declared module for $($lane.name)" }
    $arguments = @('test', '-json', '-p=1', '-count=1', '-timeout=5m') + $lane.packages
    @{ lane = $lane.name; module_root = $lane.root; command = @($go) + $arguments } | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $evidence "$($lane.name)-command.json") -Encoding utf8
    Write-Host "Native $($lane.name): $go $($arguments -join ' ')"
    $started = Get-Date
    & $go @arguments 1> (Join-Path $evidence "$($lane.name).jsonl") 2> (Join-Path $evidence "$($lane.name).stderr.log")
    $code = $LASTEXITCODE
    $counts = [ordered]@{ tests_passed = 0; tests_failed = 0; tests_skipped = 0; packages_passed = 0; packages_failed = 0; packages_skipped = 0 }
    foreach ($line in Get-Content (Join-Path $evidence "$($lane.name).jsonl")) {
      if ([string]::IsNullOrWhiteSpace($line)) { continue }
      $event = $line | ConvertFrom-Json
      $kind = if ($event.Test) { 'tests' } else { 'packages' }
      switch ($event.Action) {
        'pass' { $counts["${kind}_passed"]++ }
        'fail' { $counts["${kind}_failed"]++ }
        'skip' { $counts["${kind}_skipped"]++ }
      }
    }
    $results += [ordered]@{ lane = $lane.name; module_root = $lane.root; command = @($go) + $arguments; exit_code = $code; elapsed_seconds = ((Get-Date) - $started).TotalSeconds; counts = $counts }
    $results | ConvertTo-Json -Depth 10 | Set-Content (Join-Path $evidence 'results.json') -Encoding utf8
    Write-Host "$($lane.name): exit=$code $($counts | ConvertTo-Json -Compress)"
    if ($code -ne 0 -or $counts.tests_failed -gt 0 -or $counts.packages_failed -gt 0) { $failed = $true }
  } finally {
    Pop-Location
  }
}
if ($failed) { throw 'a required native memory-owner suite failed; see preserved test-evidence/native' }
