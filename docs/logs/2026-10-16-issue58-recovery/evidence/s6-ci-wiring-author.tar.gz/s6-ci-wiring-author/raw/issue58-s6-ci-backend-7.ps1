$proxy = go env GOPROXY
try {
  just setup
  if ($LASTEXITCODE) { throw "just setup failed: $LASTEXITCODE" }
} finally {
  # setup's developer mirror must not change the runner's later gates.
  go env -w "GOPROXY=$proxy"
}
