$env:GO_EXE = (Get-Command go).Source
pnpm --dir ui exec playwright test --config playwright.issue58.config.ts
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
