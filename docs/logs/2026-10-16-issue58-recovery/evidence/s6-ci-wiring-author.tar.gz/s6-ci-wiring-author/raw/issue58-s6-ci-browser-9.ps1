if (Test-Path '.workspace/p9-full-ui.stdout.log') {
  Write-Host '--- selected full UI stdout ---'
  Get-Content '.workspace/p9-full-ui.stdout.log'
}
if (Test-Path '.workspace/p9-full-ui.stderr.log') {
  Write-Host '--- selected full UI stderr ---'
  Get-Content '.workspace/p9-full-ui.stderr.log'
}
