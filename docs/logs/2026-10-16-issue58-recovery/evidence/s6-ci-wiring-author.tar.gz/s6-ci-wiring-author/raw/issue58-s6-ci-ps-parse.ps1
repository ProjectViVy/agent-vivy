$ErrorActionPreference = 'Stop'
$files = Get-ChildItem /tmp/issue58-s6-ci-*.ps1 | Where-Object { $_.Name -ne 'issue58-s6-ci-ps-parse.ps1' }
foreach ($file in $files) {
 $tokens = $null; $problems = $null
 [void][System.Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$problems)
 if ($problems.Count) { $problems | Format-List; throw "PowerShell parse failed: $($file.Name)" }
 Write-Output "PARSE PASS $($file.Name)"
}
