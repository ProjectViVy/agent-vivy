import json, pathlib, subprocess, yaml
root=pathlib.Path.cwd()
workflow=yaml.safe_load((root/'.github/workflows/ci.yml').read_text())
jobs=workflow['jobs']; pin='cf430e030ddbb5b0abf93d22962f4752f3646cd9'
assert workflow['permissions']=={'contents':'read'}
assert jobs['native']['runs-on']=='windows-latest' and jobs['native']['timeout-minutes']==20
assert set(jobs['aggregate']['needs'])=={'backend','ui','browser','native'}
assert '${{ needs.native.result }}'==jobs['aggregate']['steps'][0]['env']['NATIVE_RESULT']
assert 'test "$NATIVE_RESULT" = "success"' in jobs['aggregate']['steps'][0]['run']
steps=jobs['browser']['steps']; names=[s['name'] for s in steps]
assert names.index('Run actual Recap split browser test')>names.index('Stop selected full UI')
assert steps[names.index('Stop selected full UI')]['if']=='always()'
assert 'Wait-Process -Timeout 30 -ErrorAction Stop' in steps[names.index('Stop selected full UI')]['run']
assert 'playwright test --config playwright.issue58.config.ts' in steps[names.index('Run actual Recap split browser test')]['run']
for lane in ('native','browser'):
 upload=[s for s in jobs[lane]['steps'] if s.get('uses','').startswith('actions/upload-artifact@')]
 assert len(upload)==1 and upload[0]['uses']=='actions/upload-artifact@'+pin and upload[0]['if']=='always()'
 assert upload[0]['with']['if-no-files-found']=='warn'
native=next(s['run'] for s in jobs['native']['steps'] if s['name']=='Execute native BML and ACTMEM Garden suites')
for fragment in ["root = 'bml'", "root = '../laputa/laputa'", "root = '../laputa/garden'", "'./actmem'", "'./internal/ingest'", "'./internal/runtimecore'", "'./agentapi'", "'-count=1'", "'-timeout=5m'", "go_os -ne 'windows'", "if ($failed) { throw"]: assert fragment in native, fragment
assert '-run' not in native and '-race' not in native
for job, definition in jobs.items():
 if job=='aggregate': continue
 for i,step in enumerate(definition['steps']):
  if 'run' in step:
   (pathlib.Path('/tmp')/f'issue58-s6-ci-{job}-{i}.ps1').write_text(step['run'])
just=(root/'justfile').read_text(); before=subprocess.check_output(['git','show','HEAD:justfile'],text=True)
for task in ('ci','backend-ci'):
 prior=next(l for l in before.splitlines() if l.startswith(task+':'))
 current=next(l for l in just.splitlines() if l.startswith(task+':'))
 assert current==prior+' bml-ci'
assert '& "{{go}}" vet -p=1 ./...; if ($LASTEXITCODE) { exit $LASTEXITCODE }' in just
assert '& "{{go}}" test -p=1 -count=1 -timeout=5m ./...; if ($LASTEXITCODE) { exit $LASTEXITCODE }' in just
assert 'go test -p 1 -timeout 35m' not in just or '-timeout 35m' in just
# Existing entire recipes remain verbatim apart from the two dependency lists.
without=just[0:just.index('# Root ./... excludes this independently declared nested module.')]+just[just.index('# Build the assets required by go:embed'):]
assert without.replace(' plugin-ci bml-ci',' plugin-ci')==before
config=(root/'ui/playwright.issue58.config.ts').read_text()
assert "outputDir: './test-results/issue58-recap'" in config and "screenshot: 'on'" in config and "trace: 'retain-on-failure'" in config
print(json.dumps({'yaml':'valid','required_native_lane':True,'unchanged_prior_gates':True,'browser_serial_shutdown':True,'immutable_artifacts':True,'powershell_scripts_emitted':True}))
