# Existing S6 CI gates: bounded preparatory implementation

Assigned GPT-6.1 Sol High. One source writer/exclusive active Vivy Git index:
you, after explicit root assignment. No subagents. Read root AGENTS, existing
S6.md/S6-reimplementation/ci-prep.md (incl verified upstream artifact pin),
revision3 C5/S6 validation boundaries and existing justfile/workflow/config.
Do not reopen product design or request new permission for these authorized gates.
Current HEAD6e4096e8444b89713a2857b061e63fa1c2e4be01/tree6dba288a.
NativeBML fixed7993302, independently reviewed+onefix+root immutable3probes,
nativeSQLite1.56 normal/race159, rootMVS1.59normal159, vet PASS. No consumer
activation. Actual nativeWindows NOTRUN. NativeLaputa published249 pin unchanged.
Root owns later actual CI observation, qualification and final whole-candidate
independent review. Native producer greens do not accept S5 or this CI wiring.

## Deliverable/files

Modify justfile, .github/workflows/ci.yml, ui/playwright.issue58.config.ts and
minimal English durable recovery CI record (existing S6 plan/logs). No runtime/
App/BML/adapter/Recipe/generated/nativeLaputa/dependency edits. Existing S5
implementer is READONLY consumer-seam preparation; no other source writer.

1. Add bounded bml-ci using declared Go: in nested bml, go vet -p1 ./... then
   go test -p1 -timeout5m ./..., explicit failure propagation. Wire into both
   ci and backend-ci, preserving all old gates/order/35m default suite/separate
   unmodified MemoryLoop/DIVA recall/headless/plugin checks. Root ./... does not
   execute nested BML tests. Do not add race/C compiler prerequisite to ordinary
   justci; root fixed race remains separately qualified.
2. Add independent REQUIRED Windows job (id native) using existing immutable
   checkout/setup-go pins, Go version-file and normal ensure-laputa.ps1. Run
   native ./bml declared1.56 plus native published ../laputa/laputa ./actmem and
   ../laputa/garden ./internal/ingest ./internal/runtimecore ./agentapi actual
   tests (-p1,count1,bounded nativeGo package timeout). No -run narrowing or
   cross-compile qualification. Record actual Vivy checkout/native lock+HEAD,
   Go/OS and declared module versions, per-lane commands/exit/counts/raw JSON/
   stderr in a test-evidence folder only. Any fail makes job/aggregate fail.
   Preserve original logs; no DSN/liveprovider claims. Prefer native job20m,
   isolated from current backend60m. Add native dependency/result to aggregate.
3. Existing browser job holds3015 until always Stop selected full UI. AFTER
   that shutdown, set GO_EXE to actual installed Go, run existing
   pnpm --dir ui exec playwright test --config playwright.issue58.config.ts.
   Do not overlap old fullUI with splitfixture8787/3015; no existing server reuse.
   NewRecap test is required for browser job success; collection is not execution.
   Config uses dedicated outputDir ./test-results/issue58-recap and screenshot on
   (pass/fail visual artifact for later manual QA); keep failure trace retention.
   Do not alter assertions/fixtures/runtime or production source to satisfy CI.
4. Preserve new browser output/screenshots/traces and native test-evidence via
   official immutable actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9
   (v7.0.2/node24), verified root from official latest tag+action.yml. Always
   upload relevant test outputs, no user/temp App data roots/credentials. Warn
   if no output due earlier setup failure; never turn failed/skipped gate green.
   No permission expansion, deploy, tenant migration or secrets.

## Verification and handoff

Use unchanged /tmp/issue58-localonly-runner.py, cachedGo/Node/pnpm/just/pwsh under
root toolchain; offline/credentialstripped/nonforwardingexternaldeny, no change
to runner. Check baseline just formatting before changing, validate exact YAML
structure/required lane and PowerShell embedded-script parse using installed
pwsh. Run actual just bml-ci locally plus dedicated Playwright --list/config
and TypeScript appropriate check if needed (normal staging hooks). Original
local pinned Chromium install failed, so full new rendered browser cannot be
called passing unless it actually runs. Do NOT run full justci now; final S5/S6
source is unfinished. Real Windows/native job and new rendered E2E remain NOTRUN
until actual CI. Keep commands/working vs fixed candidate qualifiers and every
failed attempt in NEW S6-ci-wiring raw/report/hash manifest. Configuration checks
need not gain mirror-only unit tests; required original gates remain unchanged.

Preserve all frozen author/review manifests. Source checkpoint with explicit
changed paths only and human identity; freeze/indexrelease/report full SHA/tree.
Root publishes exact tree, runs necessary fixed config/task checks, then releases
consumer source lane. Do not continue into App/adapter/S6 product tests.
