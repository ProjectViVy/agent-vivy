# Native BML consolidated review fix

Assigned implementer GPT-6.1 Sol High, sole source writer and exclusive Vivy
Git index after root explicitly releases this brief. No subagents. Root owns
docs/evidence integration/publication and later unchanged-probe fixed qualification.
Current active HEAD58943da5cd3a41b5adcd976a402c5c04f43898ed; its only product
changes since BML92048 are three separately scoped CI fixture/classification/
expected-inventory corrections7f10, with fixed Linux269/1opt-in skip PASS. Preserve
those files and all root docs; main571 and native published249 pins unchanged.

Read full frozen independent report/probes/raw in .superpowers/sdd/S5-bml-review.
Root verified23 artifact and25source hashes.0Critical/2Important/0Minor; both
original REDs preserved. Independent99focused+1cancel pass do not override REDs.
Do ONE consolidated TDD pass for I1/I2 only, normal supported native BML APIs.

I1: schema1 readonly handle must never use stale cached schema to select an
unfiltered view after another handle normally upgrades to2/writes owned records.
Preserve genuinely schema1 readonly legacy availability and unchanged file bytes.
Supported choices per review: actual stable schema1 snapshot, safely adopt2
exclusion, or explicit failclosed on upgrade. Read query and schema determination
must share consistent SQLite snapshot/fence; separate precheck followed by
unprotected read is a TOCTOU bug. Cover original Get/List/Search/SearchVisible,
limits/ranking, actual upgrade overlap/concurrent reads and reopened Home behavior.
No new global handle registry or ownership inference. Preserve explicit native
read-only capabilities and no mutating migration in readonly opens.

I2: new bound tombstone exposes exactly one TargetRecordID/ExpectedTargetRevision/
receipt.TargetID. Reject any extra Supersedes target that could suppress another
row without its CAS. Preserve native record validation, positive target CAS and
legacy unbound multi-supersedes semantics. No bulk API/target-list CAS extension.

Original reviewer Go files stay immutable; author may copy regression cases into
normal BML tests with proper source attribution, but never weaken/modify original
probes. Include positive old-schema1/ordinary unbound controls, valid single-target
tombstone behavior, failure preserving all rows/FTS/counters/receipts. Deterministic
independent cancellation probe should remain passing. No consumer/UI/App/native
Laputa/Recipe/generated/dependency edits or additional design.

Use unchanged local-only runner, Go1.26.4, nativeSQLite1.56 normal+race and root
MVS1.59 package tests plus vet. All dependencies cached. Retain every RED/failed/
compile/interrupted attempt in NEW S5-bml-fix folder, never change frozen native
author/review manifest contents. Track minimal English fix record inside bml/
existing native iteration docs. Commit only explicit BML source/tests/docs paths
with human identity; stop/freeze/indexrelease after coherent checkpoint. Return
full SHA/tree, original source probes/result scope, exact commands/counts, complete
raw/artifact/source hashes. Root runs unchanged originals on fixed clean clone,
then fixed normal/race/rootMVS and publishes; no redundant second fix-diff review.
Windows remains NOT RUN until actual CI; no consumer activation or whole S5 claim.
