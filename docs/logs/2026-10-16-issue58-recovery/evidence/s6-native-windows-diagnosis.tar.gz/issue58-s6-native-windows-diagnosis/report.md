# Native Windows module failures — read-only diagnosis

The actual run has three separate causes: **BML test lifecycle leaks, ACTMEM snapshot-helper access to an intentionally locked coordination file, and a Garden declared dependency graph that cannot compile on Windows.** None justifies weakening owner locking, source/history invariance or persistence assertions.

Evidence: run 38825120165/job 116730972723, actual Vivy PR merge `267a0151acc09c533ace5767001ce5a9e2424df5` (branch `554c668391852ad6cf2b9fc189c56be18b76e1a6`, root-supplied local source counterpart `2e627`), Laputa `249a756e04c5f28af781e4dadea9e9086689bde0`. Artifact identity records actual Go 1.26.4 windows/amd64 on Windows 10.0.26100. Original ZIP SHA256 `d6b2bbc3ba372572b6d55fcbf9ba99700a5f029a723e691313efc396b77f8f09`; originals remain in `/tmp/issue58-native-windows-38825120165/` and decoded job log `/tmp/issue58-native-windows-116730972723.log`. `manifest.json` lists hashes for every original artifact and inspected source file, actual counts and selected raw events. No source/index/mod/sum changes, builds or tests were performed here. Existing systematic-debugging phases 1–3 only; no new Windows PASS claim.

| Actual lane | Recorded outcome | Classification |
|---|---|---|
| BML full suite | 153 test passes, 6 failures, 0 skips; exit 1 | Six old Home test cleanup failures after their assertions |
| ACTMEM | 88 passes, 25 fail events including parent/subtest headings, 1 skip; exit 1 | Shared snapshot-helper failure; one associated fatal-path owner leak |
| Garden ingest/runtimecore/agentapi | 0 tests executed, 3 packages BUILDFAIL; exit 1 | Production dependency/platform support gap, not a failed assertion |

## BML: missing Home.Close in exactly the six failed tests

Inspected immutable root `2e627:bml/home_test.go`, SHA256 `f8878431231d2c4af885666caba8ab704695a0a11ac9f1fdcdd87d6530c7853d`. Each failing function below constructs a Home, opens its SQLite Store via a write/read path, and has **zero Close calls**:

| Test | Function / constructor lines | Open-producing operation |
|---|---|---|
| TestHomePathsAndLazyStore | 65 /70 | AddRecord after absent-store assertions |
| TestHomeLongTermCRUDIsRevisionedAndTombstoned | 134 /136 | AddRecord, then revision/CAS/tombstone checks |
| TestHomeStartupGCAndClearSessionCheckpoint | 288 /290 | putSessionRecord/writableStore and GC |
| TestHomeListFiltersToVisibleLongTerm | 336 /338 | AddRecord and session-record insertion |
| TestHomeStartupIndexTracksAuthority | 357 /359 | AddRecord, index revision/update checks |
| TestHomeL1BudgetCapsIndexLines | 400 /402 | NewHomeWithL1Budget + AddRecord |

All six actual JSONL failures are `testing.go:1464: TempDir RemoveAll cleanup ... memory.sqlite3 ... being used by another process`; no preceding assertion failure appears for them. `Home.existingStore/writableStore` intentionally cache the handle; `Home.Close` (`home.go:236`) closes it and clears the cache; Store.Close closes the database. This is fixture lifetime ownership, not evidence that Close is broken. Positive control in the same native run: `TestHomeAddsIdenticalContentAtSameTime` uses `defer h.Close()` immediately after NewHome and passes.

Smallest proposed fix: register error-reporting Home cleanup immediately after each constructor, before any Fatal-capable assertion; run it before TempDir cleanup. Close only the Home-owned cached handle, not unrelated databases or a second owner. Keep every lazy-open, revision/CAS, tombstone, GC, startup-authority and L1 bound assertion unchanged. No production lifecycle or permission change is needed to explain these six failures.

## ACTMEM: snapshot helper reads the lock it is testing

At immutable Laputa 249, `laputa/actmem/recap_test.go:309–331`, `issue58Files` walks the entire owner directory and calls os.ReadFile on every non-directory, including root `.owner.lock`. `recap_owner.go:31` holds that file for the lifetime of the Store using flock.TryLock. Pinned `gofrs/flock@v0.13.0/flock_windows.go` uses native LockFileEx with LOCKFILE_EXCLUSIVE_LOCK over the first byte. The actual errors are read/locked-portion errors on `.owner.lock`, before the intended data-invariance comparison. Linux advisory-read behavior cannot qualify that test helper for Windows.

Affected test families in actual JSONL: RecapReconcile, ReconcileValidationReplay, ReconcileRecovery (both initial-coverage variants and all six fault cuts), RecoveryReopenMustConfirmExactReceipt, LegacyWriterRejectsV3, RejectsCorruptHeadAndHistory and InvalidPayloadPreservesFiles. The 25 fail-event count includes parents, not 25 independent production defects.

Keep **all owner data/history bytes** in `issue58Files`: head text/metadata, revisions, scope/authority material and other files. The narrow fix is special handling for exactly the root-relative `.owner.lock` coordination entry: record/assert its existence and regular-file identity/type without reading locked bytes; do not ignore all dotfiles, subdirectories or read errors. Leave every other entry's byte snapshot/comparison intact, including unexpected files. Do not release/disable the owner lock to take a snapshot, shorten lock lifetime, or weaken failure assertions. A distinct owner-exclusive/subprocess test remains the positive guard for lock behavior.

Fatal-path cleanup is also concrete: `recap_recovery_test.go:103ff` opens initial `s`, calls `issue58Files` at 110, then manually closes at 111ff; the helper Fatal prevents that close. Loop-opened `recovering` handles similarly rely on a later explicit Close. Register cleanup immediately after each successful Open, retaining explicit Close where reopen ordering itself is asserted. The final `recovered` already has a defer. No production hot restart or second Store is indicated.

Actual positive controls to retain unchanged: RecapOwnerExclusive, RecapOwnerAliasAndProcess (including subprocess), LazyOwnerFencesLegacyMutators, native process-crash boundaries, RecoveryWindowsInitialViewAndPositiveCommit and RecoveryWindowsOrphanDoesNotResolveMissingHead all pass. The one generic missing-head test explicitly skips on Windows in favor of its dedicated platform tests; preserve that skip as a skip, not an executed green row.

## Garden: root workaround is absent from declared native graph

The captured native Garden module declares hnsw v0.6.1 and renameio v1.0.1, with only local Laputa/Mentle replacements. Actual build output names `...hnsw@v0.6.1/encode.go:304:23: undefined: renameio.TempFile`; no Garden test body ran. The native stderr also records downloading those exact versions. Mentle declares the same pair and no renameio replacement.

Root `2e627:go.mod` instead requires hnsw `v0.6.2-0.20250701161932-41f4a3674f5b` **and** replaces renameio with the existing `./third_party/renameio`. That single shipped tree includes `renameio_windows.go`. A replace in a different main module does not silently apply when running Garden as its own module. Both cached hnsw versions' SavedGraph.Save still call renameio.TempFile; merely bumping to root's hnsw pseudo-version does not fix Windows. Upstream renameio deliberately exports no Windows implementation (official [README](https://github.com/google/renameio)); v2/latest cannot be assumed to add one. Public hnsw main source still uses renameio; an upstream compatibility PR's CI title is not an accepted release or a qualified pin.

This is a real **declared native-module support gap**. It must remain separately visible from root-product Windows compilation and from the two test-harness fixes above.

### Concrete option assessment for root's ruling

1. **Explicit artifact-compatibility lane using the one existing shipped implementation — coherent and smallest bounded diagnostic/qualification option.** Copy exact native Garden go.mod+go.sum to temporary -modfile/.sum inputs; change only the renameio replacement to an absolute path in the source-pinned Vivy `third_party/renameio`; run unchanged native tests under actual Windows. Force GOWORK=off and record GOENV/GOFLAGS/explicit flags so no ambient workspace override supplies success. Preserve native Eino/SQLite/hnsw and all other declarations/replacements. Record original/effective module files, diff, resolved graph, compat-tree hashes, actual working directory, commands and raw outcomes. Keep the compatibility source read-only and the declared files unchanged. Go 1.26.4 modload source resolves relative replacements against the main module root when workspace mode is off; nevertheless record/verify their actual resolved paths. A moved alternate sum must accompany its alternate mod file.

   Correct label: **Garden-with-Vivy-shipped-Windows-compatibility**, not untouched/standalone-native Garden. This matches an implementation already shipped by the selected Vivy product and avoids a second maintained vendored patch, but the result is an artifact graph, not proof that Garden's declared graph supports Windows. The original declared BUILDFAIL remains in the manifest. If this becomes a selected required gate, any compatibility-lane failure still fails that gate; do not turn it into a skip. Passing compilation/tests alone also does not prove the shim's crash/atomicity guarantees: upstream's explicit Windows caveat and the shipped shim's semantics need the applicable real filesystem/persistence tests. C1 owner durability remains its separately qualified native implementation.

2. **True standalone native Garden support — a separate reviewed upstream dependency/platform change.** Select a pinned, inspected upstream solution that removes the unsupported Windows call or supplies a supported platform implementation, preserving SavedGraph Export/flush/error/cleanup/replace behavior and native save/reload/failure tests. No verified fixed release was established in this diagnosis. Do not invent a latest-version fix, fork/vendor another renameio/hnsw tree, make permanent cross-repository relative replacements, or borrow a compile-only graph and call it standalone. Until an approved change and actual native rerun, declared standalone support is explicitly unavailable/failed.

No better existing module-level compatibility seam was found: the reusable code is already root-owned; native Garden/Mentle have no corresponding replacement. Root decides whether option 1 is a separately reported artifact acceptance lane while option 2 remains blocked. Neither option waives the original required native job or converts its BUILDFAIL into PASS. No option was implemented here.

## Source correspondence and next evidence

Laputa source was read from immutable git 249, identical to artifact lock/head identity. BML/root files were read from immutable local 2e627 named by root, not the active S5 working tree. The actual CI merge's source files were not fetched byte-for-byte in this diagnosis; manifest hashes make a root-side remote comparison straightforward if needed. Original ZIP/results/JSONL identity, exact failure locations and matching declared module metadata provide the current causal evidence. Do not aggregate a later remediation SHA with these raw results as one green candidate.

Next authorized writer should preserve all original RED/BUILDFAIL/SKIP, make the two narrow harness fixes with regression proof, then apply only root's chosen dependency ruling. Re-run actual Windows lanes on frozen Vivy/Laputa/override identities and report counts separately. No new build/test execution or native-pin change was made by this read-only task.
